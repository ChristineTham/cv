# Crypt

Cryptography and cryptanalysis coursework and tools, CS Honours, Basser
Department of Computer Science, University of Sydney. This is the working
material behind the USENIX 1991 crypt paper.

Recovered from `CHRISTIE.ARJ`, a December 1992 archive wrapping a May 1990
snapshot; the verbatim extraction is in `../christie/`.

## Layout

| Here | From | What it is |
| :-- | :-- | :-- |
| `src/` | `christie/crypt/` | classical cipher and cryptanalysis programs in C |
| `doc/sol1.mm` | `christie/crypt/` | assignment solution, troff `-mm` |
| `doc/eft.mm` | `christie/work/misc/eft.mm` | report on the seminar on security of EFT |
| `data/` | `christie/crypt/` | worked material: `plain`, `cipher`, `sample`, `ass1`, `ass2` |
| `ref/` | `christie/stuff/krypto.c` | third-party reference tool, see below |

Both documents declare the same course in their troff headers — `sol1.mm` is
titled for CS3 Cryptography and Computer Security, and `eft.mm` reports on a
seminar in the same subject — which is what puts `eft.mm` here rather than
leaving it among the miscellany it was archived with.

## The programs

`src/` implements the classical ciphers and the standard attacks on them:

- `caesar.c`, `vigenere.c`, `beauford.c`, `vbeaufor.c` — the ciphers
- `kasiski.c` — Kasiski examination, for recovering key length
- `fcount.c` — frequency counting
- `calcic.c` — index of coincidence
- `whichkey.c`, `breakt.c` — key recovery

## Third-party material

`ref/krypto.c` is **not** the author's work. Its header identifies it as "A
Cryptanalytic Workbench", written by Michael Coyne in July 1985. It is kept
because it was part of the working toolkit, but it is someone else's code.
