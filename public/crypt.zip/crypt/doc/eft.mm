.ND "9th July, 1987"
.TL
Report on the CS3 Cryptography and Computer Security
.br
Seminar on Security of EFT
(Electronic Funds Transfer) Systems
.br
organized by Dr. J. Seberry
.ds Ba "Basser Department of Computer Science
.AF "University of Sydney"
.AU "Chris Tham (8444828)" CT Ba 8444828 3423 B29 Hons
.MT 4
.P
The seminar began with an introduction to the three speakers and their
backgrounds by Dr. Seberry.
.P
The first speaker was Mr. Lal Fernando who is the Executive Officer of the
Standards Association of Australia's (SAA) committee on EFT (Electronic Funds
Transfer).
.P
Mr. Fernando described the role of SAA in guiding government and industry
towards standardization in many diverse areas.  The SAA's published standards
are intended as guidelines for implementation rather than legislated laws
which must be adhered to.  This, explained Mr. Fernando, will encourage
standards published to be practically oriented as well as useful.  Most SAA
standards are simply international standards which may be modified for local
use.  However, sometimes the SAA will pioneer research work on standardization
in areas where no
.I "de facto"
or international standards exist.
A prime example is the current work on the proposed Australian EFT standard.
.P
The next speaker was Mr. Rob Davids who is the Manager of Technical Research
in the Information Systems Department of WESTPAC Banking Corporation.  He is
involved in the research of security related systems and is one of the
founding members of the SAA subcommittee on EFT Security.
.P
Mr. Davids described the security arrangements concerning the automatic
teller machines installed in WESTPAC banks as well as within commercial
retailer premises.  He described how the DES (Data Encryption System) is used
for generating Message Authentication Codes (MAC) which are used by WESTPAC
to authenticate automatic teller transactions.  He also described the
standardization of MACs in his capacity as a member of the SAA standardization
committee.
.P
The last speaker was Mr Chris Reilly who is the Technical Director of AUSTNET
and managing director of EFTEL.  EFTEL is the Research and Development offshoot
of AUSTNET which is an Australia wide EFT network.  He is also the Chairman
of the SAA Subcommittee on EFT Security.
.P
Mr. Reilly first gave an overview of issues in EFT interspersed with some
rather funny anecdotes.  The current state and future of EFT and EFT security
was covered.  Topics covered included the nature of money and credit cards as
well as security issues concerning verification of transactions.  The
data processing and telecommunication
requirements of EFT networks were also covered.  Finally, Mr. Reilly described
MERCURY, which is EFTEL's EFT switching and authorization system.  The
MERCURY architecture and implementation was described in detail.
.P
As it was now half an hour past the advertised end of the seminar, not many
questions were raised in the discussion that followed and
the seminar was thus concluded.
