.ds Ba "Basser Department of Computer Science
.SA 1
.TL
CS3 Cryptography and Computer Security
.br
Solution to Assignment 1
.AF "University of Sydney"
.AU "Chris Tham" CT Ba
.AT "CS Honours" "Department of Computer Science"
.MT 4 1
.AS
.nf
A solution for the following assignment is presented:

Decipher the following, using the Vigenere method.

 lusnc iafeb jakqn gsghd cetnl vcjda rgzrk kpphn vcooq qdnjb ijbfh nlgva
 aalgx ecimx dewtf artaq ybhwu mynfq vwbvo vfrrp fqwvd qpqqt hbjfs ofqwn
 kjcnr tagzb ioyzd cghbz qeond yhdco rnuxg dypgn lusnc ptblu sbpmy ndyhd
 cfrvw qojbz ogwqf ebqrf xecir tefln hemzs awnfw lpfnj uozkg sgwes zyftu
 wucic etrsq crcdn vyuhb mdtuw oiofy eadbj afmrq jvrel swuwe spfqw vdqpq
 qthbj fsoyd enfqh dcetb uxawl enhxs gpfqb nlgza uutuv rzeet tosax knmtr
 jfcj
.fi
.AE
.H 1 "Introduction"
A set of tools were written in C to help break the ciphertext.  These tools
all read from standard input and write their results to standard output.
Interesting statistics and error messages may be produced on the standard
error stream.  Hence the set of utilities integrate very well with the Unix
environment.
.P 1
The tools are:
.VL 10
.LI Vigenere
Performs Vigenere Polyalphabetic Substitution on standard input and write to
standard output
.LI VBeauford
Performs Variant Beauford Polyalphabetic Subsitution (Inverse Vigenere) on
standard input and write to standard output
.LI Kasiski
Find repeated substrings in standard input
.LI Fcount
Generate frequency count and letter count of standard input, useful for
further analysis as well as calculating the Index of Coincedence (IC).
.LI CalcIC
Calculate IC based on the output generated from Fcount
.LI BreakT
Break up ciphertext into n parts (in files `brk00' up to `brknn') so that the
indivual parts all belong to the same subsitution key.
.LI Caesar
Perform simple substitution on standard input
.LE
.H 1 "Guessing the Period"
.P 1
Our first approach is to use the Kasiski method on repetitions in the
ciphertext.  The
.B Kasiski
program takes two command line parameters,
.I size
and
.I cycle-length ,
in that order, and finds all occurences of repetitions of substrings of length
.I cycle-length in a ciphertext of size less than
.I size .
The following results are obtained:
.DS I
$ kasiski 10000 4 < text | sort | uniq
`bjfs' spaced 192
`dcet' spaced 296
`dqpq' spaced 192
`dyhd' spaced 32
`fqwv' spaced 192
`hbjf' spaced 192
`hdce' spaced 296
`jfso' spaced 192
`lusn' spaced 160
`ndyh' spaced 32
`pfqw' spaced 192
`pqqt' spaced 192
`qpqq' spaced 192
`qqth' spaced 192
`qthb' spaced 192
`qwvd' spaced 192
`thbj' spaced 192
`usnc' spaced 160
`vdqp' spaced 192
`wvdq' spaced 192
`xeci' spaced 136
`yhdc' spaced 32
.FG "Repeated substrings of length 4"
.DE
.DS I
$ kasiski 10000 4 < text | sort | uniq
`bja' spaced 264
`bjf' spaced 192
`cet' spaced 224
`cet' spaced 72
`dce' spaced 296
`dqp' spaced 192
`dyh' spaced 32
`eci' spaced 136
`feb' spaced 187
`fqw' spaced 16
`fqw' spaced 176
`fso' spaced 192
`gsg' spaced 214
`hbj' spaced 192
`hdc' spaced 128
`hdc' spaced 136
`hdc' spaced 32
`jfs' spaced 192
`lus' spaced 160
`lus' spaced 8
`myn' spaced 88
`ndy' spaced 32
`nfq' spaced 224
`nlg' spaced 280
`pfq' spaced 192
`pfq' spaced 40
`pqq' spaced 192
`qpq' spaced 192
`qqt' spaced 192
`qth' spaced 192
`qwv' spaced 192
`rta' spaced 48
`snc' spaced 160
`thb' spaced 192
`tuw' spaced 24
`usn' spaced 160
`vdq' spaced 192
`wes' spaced 56
`wvd' spaced 192
`xec' spaced 136
`yhd' spaced 32
.DE
.P 1
As can be seen from running the
.B Kasiski
program, repeated substrings in the ciphertext are spaced a multiple of 8
characters apart, with the substring `lus' occuring three times in the text
spaced in one instance at 8 apart.  Our most likely guess for the key period
is then 8.
.P 1
The index of coincedence can be calculated by running the
.B Fcount
program with its output piped through the
.B CalcIC
program.  Running
.B Fcount
by itself with the argument
.I verbose
gives a human readable frequency analysis of the ciphertext:
.DS I
$ fcount verbose < text
Length of text = 364
`a' = 15
`b' = 17
`c' = 17
`d' = 17
`e' = 19
`f' = 22
`g' = 14
`h' = 13
`i' = 7
`j' = 13
`k' = 6
`l' = 11
`m' = 7
`n' = 22
`o' = 14
`p' = 11
`q' = 22
`r' = 16
`s' = 14
`t' = 16
`u' = 15
`v' = 12
`w' = 16
`x' = 7
`y' = 11
`z' = 10
.FG "Frequency analysis of ciphertext"
.DE
.DS I
$ fcount < text | calcic
0.039733
.FG "IC of ciphertext"
.DE
.P 1
From the IC computed, it appears more likely that the period of the key was
16 rather than 8, but we will proceed with the assumption of 8.
.H 1 "Frequency analysis of the individual sections"
We use the
.B BreakT
program to split the ciphertext into 8 sections from text positions
.I i " + 8" n
where
.I i
ranges from 0 to 7:
.DS I
$ breakt 8 < text
.DE
.P 1
This produces 8 files
.I brk00
through to
.I brk07 .
The contents of the files are:
.DS I
brk00:
leslzvjlxwyffdjkzgdulldwwxlwjwwsywdjwdjfuxlvsj
brk01:
ubgvrcbgetbqrqfjbhyxuuyqqennueuquobveqfqxsgraf
brk02:
sjhckoivcfhvrpscibhgsshofchfoscchijrspshagzzxc
brk03:
nadjkojaiawwpqonozddnbdjeiewzzirboaepqodwpaekj
brk04:
ckcdpqbamrubfqfryqcycpcbbrmlkyccmfflfqyclfuen
brk05:
iqeapqfaxtmvqtqtzeoppmfzqtzpgfeddymsqtdeequtm
brk06:
antrhdhldayowhwadorgtyroresfsttnterwwhetnbttt
brk07:
fgngnnngeqnvvbngcnnnbnvgffangurvuaquvbnbhnuor
.FG "Contents of splitted sections"
.DE
.P 1
We can run individual frequency analysis for each section:
.DS I
$ fcount verbose < brk00
Length of text = 46
`a' = 0
`b' = 0
`c' = 0
`d' = 5
`e' = 1
`f' = 3
`g' = 1
`h' = 0
`i' = 0
`j' = 6
`k' = 1
`l' = 7
`m' = 0
`n' = 0
`o' = 0
`p' = 0
`q' = 0
`r' = 0
`s' = 3
`t' = 0
`u' = 2
`v' = 2
`w' = 8
`x' = 3
`y' = 2
`z' = 2
$ fcount < brk00 | calcic
0.084058
.FG "Frequency analysis of brk00"
.DE
.DS I
$ fcount verbose < brk01
Length of text = 46
'a' = 1
'b' = 5
'c' = 1
'd' = 0
'e' = 4
'f' = 3
'g' = 3
'h' = 1
'i' = 0
'j' = 1
'k' = 0
'l' = 0
'm' = 0
'n' = 2
'o' = 1
'p' = 0
'q' = 7
'r' = 3
's' = 1
't' = 1
'u' = 6
'v' = 2
'w' = 0
'x' = 2
'y' = 2
'z' = 0
$ fcount < brk01 | calcic
0.062802
.FG "Frequency analysis of brk01"
.DE
.DS I
$ fcount verbose < brk02
Length of text = 46
'a' = 1
'b' = 1
'c' = 7
'd' = 0
'e' = 0
'f' = 3
'g' = 2
'h' = 7
'i' = 3
'j' = 2
'k' = 1
'l' = 0
'm' = 0
'n' = 0
'o' = 3
'p' = 2
'q' = 0
'r' = 2
's' = 7
't' = 0
'u' = 0
'v' = 2
'w' = 0
'x' = 1
'y' = 0
'z' = 2
$ fcount < brk02 | calcic
0.075362
.FG "Frequency analysis of brk02"
.DE
.DS I
$ fcount verbose < brk03
Length of text = 46
'a' = 5
'b' = 2
'c' = 0
'd' = 5
'e' = 4
'f' = 0
'g' = 0
'h' = 0
'i' = 3
'j' = 4
'k' = 2
'l' = 0
'm' = 0
'n' = 3
'o' = 5
'p' = 3
'q' = 2
'r' = 1
's' = 0
't' = 0
'u' = 0
'v' = 0
'w' = 4
'x' = 0
'y' = 0
'z' = 3
$ fcount < brk03 | calcic
0.060870
.FG "Frequency analysis of brk03"
.DE
.DS I
$ fcount verbose < brk04
Length of text = 45
'a' = 1
'b' = 4
'c' = 8
'd' = 1
'e' = 1
'f' = 6
'g' = 0
'h' = 0
'i' = 0
'j' = 0
'k' = 2
'l' = 3
'm' = 3
'n' = 1
'o' = 0
'p' = 2
'q' = 4
'r' = 3
's' = 0
't' = 0
'u' = 2
'v' = 0
'w' = 0
'x' = 0
'y' = 4
'z' = 0
$ fcount < brk04 | calcic
0.073737
.FG "Frequency analysis of brk04"
.DE
.DS I
$ fcount verbose < brk05
Length of text = 45
'a' = 2
'b' = 0
'c' = 0
'd' = 3
'e' = 5
'f' = 3
'g' = 1
'h' = 0
'i' = 1
'j' = 0
'k' = 0
'l' = 0
'm' = 4
'n' = 0
'o' = 1
'p' = 4
'q' = 7
'r' = 0
's' = 1
't' = 6
'u' = 1
'v' = 1
'w' = 0
'x' = 1
'y' = 1
'z' = 3
$ fcount < brk05 | calcic
0.068687
.FG "Frequency analysis of brk05"
.DE
.DS I
$ fcount verbose < brk06
Length of text = 45
'a' = 3
'b' = 1
'c' = 0
'd' = 3
'e' = 3
'f' = 1
'g' = 1
'h' = 4
'i' = 0
'j' = 0
'k' = 0
'l' = 1
'm' = 0
'n' = 3
'o' = 3
'p' = 0
'q' = 0
'r' = 5
's' = 2
't' = 9
'u' = 0
'v' = 0
'w' = 4
'x' = 0
'y' = 2
'z' = 0
$ fcount < brk06 | calcic
0.075758
.FG "Frequency analysis of brk06"
.DE
.DS I
$ fcount verbose < brk07
Length of text = 45
'a' = 2
'b' = 4
'c' = 1
'd' = 0
'e' = 1
'f' = 3
'g' = 6
'h' = 1
'i' = 0
'j' = 0
'k' = 0
'l' = 0
'm' = 0
'n' = 13
'o' = 1
'p' = 0
'q' = 2
'r' = 2
's' = 0
't' = 0
'u' = 4
'v' = 5
'w' = 0
'x' = 0
'y' = 0
'z' = 0
$ fcount < brk07 | calcic
0.122222
.FG "Frequency analysis of brk07"
.DE
.H 1 "Breaking the cipher"
We use the fact that `THE' is the most common three-letter English word to
guess that the letters `LUS' may stand for `THE' as it occurs three times
within the text.  Hence, in
.I brk00 ,
`T'is subsituted to `L', in
.I brk01 ,
`H'is subsituted to `U', and in
.I brk02 ,
`E'is subsituted to `S'.  We use the
.B Caesar
program to reverse the subsitutions:
.DS I
$ caesar l t < brk00 > p00
Key is 'i'
$ caesar u h < brk01 > p01
Key is 'n'
$ caesar s e < brk02 > p02
Key is 'm'
$ cat p0?
tmathdrtfegnnlrsholcttleeftereeagelrelrncftdar
hotiepotrgodedswoulkhhlddraahrhdhboirdsdkftens
evtowauhorthdbeountseetarotraeootuvdebetmslljo
.FG "Subsitute THE for LUS"
.DE
.P 1
Looking at the resulting output, we can see the word `THE' down the first
column, as anticipated, but some of the other columns look interesting.
The second column is `MOV' which could stand for `MOVE' and the 9th column is
`FRO' which could stand for `FROM'.  Hence we guess `M' has been substituted to
`I'.
.DS I
$ cat
$ caesar i m < brk03 > p03
Key is 'e'
$ cat p0?
tmathdrtfegnnlrsholcttleeftereeagelrelrncftdar
hotiepotrgodedswoulkhhlddraahrhdhboirdsdkftens
evtowauhorthdbeountseetarotraeootuvdebetmslljo
rehnosnemeaatusrsdhhrfhnimiaddmvfseitushateion
