/* perform simple substitution on standard input */

#include <stdio.h>
#include <ctype.h>
#include "constants.h"

extern char	*malloc();

int
main(argc, argv)
int	argc;
char	*argv[];
{
	int	k, newk, ch;

	if (argc != 3)
	{
		fprintf(stderr, "Usage: %s char newchar\n", *argv);
		return 1;
	}

	k = **++argv;
	if (isupper(k))
		k -= 'A';
	else if (islower(k))
		k -= 'a';

	newk = **++argv;
	if (isupper(newk))
		newk -= 'A';
	else if (islower(newk))
		newk -= 'a';

	k = (newk - k + MAXLETTER) % MAXLETTER;
	fprintf(stderr, "Key is '%c'\n", k + 'a');

	while ((ch = getchar()) != EOF)
	{
		if (isupper(ch))
			putchar((ch + k - 'A') % MAXLETTER + 'A');
		else if (islower(ch))
			putchar((ch + k - 'a') % MAXLETTER + 'a');
		else
			putchar(ch);
	}

	return 0;
}
