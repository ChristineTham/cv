/* Given sample of cipher text and plain text, find key used if the
 * Vigenere, Beauford or Variant Beauford methods have been used to
 * encipher the plain text into cipher.
 *
 * Usage: whichkey plain cipher
 *	plain and cipher are strings of key length
 */

#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include "constants.h"

extern char	*malloc();

int
main(argc, argv)
int	argc;
char	*argv[];
{
	char		*plain, *cipher;
	char		*vigenere, *beauford, *vbeauford;
	char		*vigptr, *beauptr, *vbeauptr;
	unsigned int	keylen;
	register int	i;
	register char	c, p;

	if (argc != 3)
	{
		fprintf(stderr, "usage: %s plain cipher\n", *argv);
		return 1;
	}

	plain = *++argv;
	cipher = *++argv;

	if ((keylen = strlen(plain)) != strlen(cipher))
	{
		fprintf(stderr, "plain and cipher strings must be of equal length\n");
		return 1;
	}

	if
	(
		(vigptr = vigenere = malloc(keylen * sizeof(char))) == NULL ||
		(beauptr = beauford = malloc(keylen * sizeof(char))) == NULL ||
		(vbeauptr = vbeauford = malloc(keylen * sizeof(char))) == NULL
	)
	{
		fprintf(stderr, "cannot allocate memory\n");
		return 1;
	}

	for (i = 0; i < keylen; ++i)
	{
		p = *plain++;
		if (islower(p))
			p -= 'a';
		if (isupper(p))
			p -= 'A';

		c = *cipher++;
		if (islower(c))
			c -= 'a';
		if (isupper(c))
			c -= 'A';

		*vigptr++ = (c - p + MAXLETTER) % MAXLETTER + 'a';
		*beauptr++ = (c + p) % MAXLETTER + 'a';
		*vbeauptr++ = (p - c + MAXLETTER) % MAXLETTER + 'a';
	}

	*vigptr = *beauptr = *vbeauptr = 0;

	printf("Vigenere=%s\nBeauford=%s\nVariant Beauford=%s\n",
		vigenere, beauford, vbeauford);

	return 0;
}
