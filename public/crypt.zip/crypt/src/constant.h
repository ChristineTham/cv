#define MAXLETTER	26
#define MAXFILES	16
