/* calculate IC given frequency count */

#include <stdio.h>

main()
{
	int	f;
	int	n;
	int	ic;

	if (scanf("%d", &n) != 1)
		return 1;

	ic = 0;
	while (scanf("%d", &f) == 1)
		ic += f * ( f - 1);

	printf("%lf\n", (double) ic / n / (n - 1));

	return 0;
}
