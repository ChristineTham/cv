/* Kasiski method, find repetitions in ciphertext size s of cycle n */
#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include "constants.h"

extern char	*malloc();
char		*instr();

main(argc, argv)
int	argc;
char	*argv[];
{
	int	size, cycle;
	char	*buffer, *bufptr, *str, *sptr;
	int	i, ch;
	int	bufcnt, bufind;

	if (argc != 3)
	{
		fprintf(stderr, "Usage: %s size cycle\n", *argv);
		return 1;
	}

	if (!(size = atoi(*++argv)))
	{
		fprintf(stderr, "error: size must be a positive number\n");
		return 1;
	}

	if (!(cycle = atoi(*++argv)))
	{
		fprintf(stderr, "error: cycle must be a positive number\n");
		return 1;
	}


	if (cycle > size)
	{
		fprintf(stderr, "error: cycle must be <= size\n");
		return 1;
	}
	if
	(
		(buffer = malloc((unsigned int)size * sizeof(char))) == NULL ||
		(str = malloc
			(
				(unsigned int)(cycle + 1) *
				sizeof(char)
			)
		) == NULL
	)
	{
		fprintf(stderr, "error: cannot allocate memory\n");
		return 1;
	}

	bufcnt = 0;
	bufptr = buffer;
	while (bufcnt < size && (ch = getchar()) != EOF)
	{
		if (isupper(ch))
		{
			*bufptr++ = ch - 'A' + 'a';
			bufcnt++;
		}

		if (islower(ch))
		{
			*bufptr++ = ch;
			bufcnt++;
		}
	}
	*bufptr = '\0';

	for (bufind = 0; bufind <= bufcnt - cycle; bufind++)
	{
		/* get sequence of cycle length */
		bufptr = &buffer[bufind];
		sptr = str;
		for (i = 0; i < cycle; ++i)
			*sptr++ = *bufptr++;
		*sptr = '\0';

		/* see how many times if occurs in ciphertext */
		bufptr = buffer;
		i = 0;
		while ((sptr = instr(bufptr, str)) != NULL)
		{
			if (++i > 1)
				printf
				(
					"'%s' spaced %d\n",
					str,
					sptr - bufptr + 1
				);
			bufptr = sptr + 1;
		}
	}

	return 0;
}

char *
instr(s1, s2)
char	*s1, *s2;
{
	char	*s;
	int	len = strlen(s2);

	s = s1;
	while ((s = strchr(s, *s2)) != NULL)
		if (strncmp(s, s2, len))
			s++;
		else
			return s;

	return NULL;
}
