/* Break letters in stdin into n distinct parts */
#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include "constants.h"

extern char	*malloc();
void		text();

main(argc, argv)
int	argc;
char	*argv[];
{
	int	size;
	FILE	*files[MAXFILES];
	char	fname[16];
	int	i, ch;

	if (argc != 2)
	{
		fprintf(stderr, "Usage: %s size\n", *argv);
		return 1;
	}

	if ((size = atoi(*++argv)) <= 0 || size > MAXFILES)
	{
		fprintf(stderr, "error: size must integer <= %d\n", MAXFILES);
		return 1;
	}

	/* open files for writing */
	for (i = 0; i < size; ++i)
	{
		sprintf(fname, "brk%02d", i);
		if ((files[i] = fopen(fname, "w")) == NULL)
		{
			fprintf(stderr, "error: cannot open %s\n", fname);
			return 1;
		}
	}

	i = 0;
	while ((ch = getchar()) != EOF)
	{
		if (isupper(ch) || islower(ch))
		{
			fputc(ch, files[i]);
			if (++i >= size)
				i = 0;
		}
	}

	for (i = 0; i < size; ++i)
	{
		fputc('\n', files[i]);
		fclose(files[i]);
	}

	return 0;
}
