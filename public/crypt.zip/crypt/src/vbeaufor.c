/* perform variant beauford (inverse vigenere) encryption on standard input */

#include <stdio.h>
#include <ctype.h>
#include "constants.h"

extern char	*malloc();

int
main(argc, argv)
int	argc;
char	*argv[];
{
	char	*key, *aptr, *keyptr;
	register int	ch;
	unsigned int	keylen, kindex;

	if (argc != 2)
	{
		fprintf(stderr, "Usage: %s key\n", *argv);
		return 1;
	}

	aptr = argv[1];
	keylen = (unsigned int)strlen(aptr);
	if ((key = malloc(keylen * sizeof(char))) == NULL)
	{
		fprintf(stderr, "error: cannot allocate memory\n");
		return 1;
	}

	/* get key */
	keyptr = key;
	while (*aptr != '\0')
	{
		if (isupper(*aptr))
			*keyptr++ = *aptr++ - 'A';
		else if (islower(*aptr))
			*keyptr++ = *aptr++ - 'a';
		else
		{
			fprintf
			(
				stderr,
				"error: key %s must be alphabetic\n",
				argv[1]
			);
			return 1;
		}
	}

	kindex = 0;
	while ((ch = getchar()) != EOF)
	{
		if (isupper(ch))
		{
			putchar((ch - 'A' - key[kindex] + MAXLETTER)
				% MAXLETTER + 'A');
			if (++kindex >= keylen)
				kindex = 0;
		}
		else if (islower(ch))
		{
			putchar((ch - 'a' - key[kindex] + MAXLETTER)
				% MAXLETTER + 'a');
			if (++kindex >= keylen)
				kindex = 0;
		}
		else
			putchar(ch);
	}

	return 0;
}
