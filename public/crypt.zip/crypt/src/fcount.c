/* find the frequency count of letters in standard input */
/* output is lines each containing an integer in ASCII */
/* first line is the length of the ciphertext */
/* rest of lines are frequency counts of the letters, starting from 'A' */

#include <stdio.h>
#include <ctype.h>
#include "constants.h"

int
main(argc, argv)
int	argc;
char	*argv[];
{
	int		freq[MAXLETTER];
	int		n = 0;
	register int	ch;
	register int	*fptr;

	/* clear freq[] */
	for (ch = 0, fptr = freq; ch < MAXLETTER; ch++)
		*fptr++ = 0;

	n = 0;
	while ((ch = getchar()) != EOF)
	{
		if (isupper(ch))
		{
			freq[ch - 'A']++;
			n++;
		}

		if (islower(ch))
		{
			freq[ch - 'a']++;
			n++;
		}
	}

	if (argc > 1)
		printf("Length of text = %d\n", n);
	else
		printf("%d\n", n);
	for (ch = 0, fptr = freq; ch < MAXLETTER; ch++)
		if (argc > 1)
		{
			printf("`%c'=%d\t", ch + 'a', *fptr++);
			if (ch % 8 == 7) putchar('\n');
		}
		else
			printf("%d\n", *fptr++);

	if (argc > 1) putchar('\n');
	return 0;
}
