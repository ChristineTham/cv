#define UCB
/*
**			   A Cryptanalytic Workbench.
**			   ==========================
**
**		       Written by Michael Coyne on 10/7/85
**		( based on a program by	Mark Grundy and Mark Ellison )
**
**		This program provides an environment in which simple
**		substitution or transposition ciphers may be decrypted.
*/

/*
**	Compiler Options		Effect.
**
**	NOSIG			Disable signals for debugging.
**	DEBUG			Print diagnostic Statements.
*/

#ifndef NOSIG
#include	<signal.h>
#endif
#include	<fcntl.h>
#include	<stdio.h>
#include	<ctype.h>
#include	<setjmp.h>
#include	<sys/types.h>
#include	<sys/dir.h>
#include	<sys/stat.h>

#define	TRUE		1
#define	FALSE		0
#ifndef MAXNAMLEN
#define MAXNAMLEN	14	/* Default Maximum Name Length */
#endif
#ifndef SYSERROR
#define SYSERROR	(-1)	/* Return Code from failed system call */
#endif
#define CHEWSPACE(s)	while (*s && isspace(*s)) s++
#define ROWS 		22	/* The maximum size of the histogram */
#define COLS		60	/* The assumed width of the screen */
#define	SIZ		128	/* Size of alphabet */
#define MAX_PERM	12	/* The maximum period for random trans */
#define MAX_PERM_LENGTH 50	/* The maximum period for selected trans */
#define	TRANS_BLOCK_SIZE 5	/* The size of the transposed cipher blocks */
#define MAX_LETTS	16	/* Max string length for frequency counts */
#define MAX_DIFF_STRINGS 2000	/* The maximum number of different strings */
#define MAX_ALPHABETS	40	/* Maximum number of alphabets */

/* The different types of substitution which may be performed. */
#define INVALID		0	/* Method not specified   */
#define GENERAL		2	/* F (a) = K(a)           */
#define VIGENERE	3	/* Fi(a) = (Ki + a) mod n */
#define BEAUFORT	4	/* Fi(a) = (Ki - a) mod n */
#define VAR_BEAUFORT	5	/* Fi(a) = (a - Ki) mod n */

/* setjmp may return to the command level with the following values */
#define	FIRST_TIME	0	/* Initialisation - so read in file	*/
#define	INT_RETURN	1	/* Return from interrupt		*/
#define COMM_ERROR	2	/* Command error			*/
#define MEM_OVFLOW	3	/* Ran out of memory on file read	*/

extern char *	strcat();
extern int	strlen();
#ifdef UCB
#define strchr	index
#define strrchr	rindex
#endif
extern char *	strchr();
extern char *	strrchr();
extern char *	strcpy();
extern char *	mktemp();
extern char *	getenv();
extern char *	re_comp();
extern int	re_exec();
extern char *	gets();
extern char *	malloc();

struct lf	/* structure used to hold strings for digraph-trigraph counts */
{
	char	lett[MAX_LETTS+1];
	int	num;
};

typedef struct lf *	qtype;

char *	buf		= NULL;	/* A holding buffer */
char *	buf1		= NULL;	/* A holding buffer */
char	chars[SIZ];		/* The mapping where substitutions are stored */
char	lchars[SIZ];		/*     Backup Copy                            */
char	cbuf[SIZ];		/*     Buffer for mapping string              */
char *	string		= NULL;	/* The current string - after a transposition */
char *	lstring		= NULL;	/*     Backup Copy                            */
char *	oldstring	= NULL;	/* The string initially read in.	*/
char *	loldstring	= NULL;	/*     Backup Copy			*/
char *	alpha		= NULL;	/* Contains chars from str to be transposed */
char	iob[512];		/* Buffer used by write_to		*/
int	t[MAX_PERM_LENGTH];	/* Permutation of the text		*/
int	f[26];			/* Frequencies of chars A-Z, a-z	*/
char *	subarg[20];		/* Args for the Substitution program	*/
int	subargc;		/* The number of args in the above.	*/
int *	alph[MAX_ALPHABETS];	/* Pointers to each alphabet string	*/
int	alphs;			/* Number of alphabets used		*/
int	nels;			/* No. of els in string freq. table	*/
qtype	freq[MAX_DIFF_STRINGS];	/* The string frequency table		*/
jmp_buf	startenv;		/* Environment at command-line level	*/
int	(* intp)();		/* The saved interrupt vectors		*/
int	(* quitp)();
char	line[256];		/* The current command line		*/
char	expr_array[80];		/* The regular expression is stored here */
char *	expr;			/* Pointer to the above reg expression.	*/
char *	tmpfil;			/* Pointer to name of temporary file	*/
char *	editor;			/* Pointer to the name of the editor used */
char *	shell;			/* Pointer to the name of the shell used*/
char *	my_name;		/* This program's name			*/
char	cur_file[MAXNAMLEN];	/* Name of current file			*/
int	silent = FALSE;		/* TRUE if no prompt required		*/
int	making_area = FALSE;	/* TRUE if currently sallocing area	*/
char	c1;
char	c2;
int	n;
int	period;			/* Interval between selected characters	*/
int	disp;			/* Displacement of chars within interval*/
int	seqlen;			/* Length of strings to be printed	*/
int	num;			/* Number of strings to be printed	*/

static	int	fact[MAX_PERM+1] = {
/* Factorial table - a space/time tradeoff ... */
	1,
	1,
	2,
	6,
	24,
	120,
	720,
	5040,
	40320,
	362880,
	3628800,
	39916800,
 	479001600
};

char *	help_message =
"Command		   Meaning\n\
?		- this message.\n\
!		- execute a shell command.\n\
f [<seqlen> [n]]- print [the n most] frequent strings of length seqlen.\n\
g [<d> <p>]	- print the frequency distribution graph of letters.\n\
i [<p>]		- calculate the index of coincidence of the text.\n\
l [<b> <B>]	- list only the modified string. [b=blklength, B=blks/line]\n\
p		- print current code.\n\
q		- exit.\n\
s <ch1> <ch2>	- substitute ch2 for ch1.\n\
S [-] -[gvbB] {keys}\n\
		- Perform the substitution specified by the key.\n\
T [-] <perm>|key- Transpose text by perm or keyword. e.g. T 4,5,2,3,1\n\
t <n> [/regexp]	- look for transpositions of period n; [print only /regexp].\n\
B [-] <perm>|key- apply the specifed rectangular encryption to the text.\n\
b <n> [/regexp]	- look for block decryptions of size n; [print only /regexp].\n\
u		- undo previous modification.\n\
z		- reset the code to its initial state.\n\
r <file>	- enter code from file.\n\
w <file>	- write code to file.\n\
e		- edit code.\n\
";

/*
**	Signal Handler.
*/
#ifndef NOSIG
int
interrupt(sig)
	int	sig;	/* The number of the signal caught */
{
	/* Ignore any more signals now, so that we can clean up */
	(void)signal(SIGINT, SIG_IGN);
	(void)signal(SIGQUIT, SIG_IGN);

	switch (sig)
	{
	case SIGINT :
		(void)fprintf(stdout, "\nDEL\n");
		break;
	case SIGQUIT :
		(void)fprintf(stdout, "\nQUIT\n");
		break;
	default :
		(void)fprintf(stdout, "\nHUH??\n");
		break;
	}

	/* Free up any pointers which have been allocated for the string
	** frequency counts, or for the substitution alphabets, if the
	** interrupt occurred before they had been deallocated. */
	for (;alphs;)
		free ((char *) alph[--alphs]);

	for (;nels;)
		free ((char *) freq[--nels]);

	longjmp(startenv,INT_RETURN);
}
#endif

/*
**	My own strncpy.  The system one won't copy past a null char.
*/
char *
mstrncpy(dest, src, len)
	register char *	dest;
	register char *	src;
	register int	len;
{
	while (len--)
		dest[len]=src[len];

	return(dest);
}

/*
**	Backup the current state.
*/
backup()
{
	(void)strcpy(lstring, string);
	(void)strcpy(loldstring, oldstring);
	(void)mstrncpy(lchars, chars, SIZ);
}

/*
**	Restore copy's - used by 'undo' command.
*/
restore()
{
#ifndef NOSIG
	/* Disable interrupts as this is a critical section */
	intp = signal(SIGINT, SIG_IGN);
	quitp = signal(SIGQUIT, SIG_IGN);
#endif

	(void)strcpy(buf, oldstring);
	(void)strcpy(oldstring, loldstring);
	(void)strcpy(loldstring, buf);

	(void)strcpy(buf, string);
	(void)strcpy(string, lstring);
	(void)strcpy(lstring, buf);

	(void)mstrncpy(cbuf, chars, SIZ);
	(void)mstrncpy(chars, lchars, SIZ);
	(void)mstrncpy(lchars, cbuf, SIZ);

#ifndef NOSIG
	/* Enable interrupts */
	intp = signal(SIGINT, intp);
	quitp = signal(SIGQUIT, quitp);
#endif

	return;
}

/*
**	Format the string into blocks of 'blklen' with B blocks per
**	line.
*/
char *
blkstring(buf, str, blklen, B)
	char *	buf;
	char *	str;
	int	blklen;
	int	B;
{
	int	j = 0;
	int	k = 0;
	char *	save = buf;

	while (*str)
	{
		*buf++ = *str++;
		if (++j % blklen == 0)
			if (++k % B)
				*buf++=' ';
			else
				*buf++='\n';
	}

	if (*(buf-1) != '\n')
		*buf++='\n';
	*buf='\0';

	return(save);
}

/*
**	Select every periodth char from str (after ignoring disp chars).
*/
char *
selstring(buf, str, disp, period)
	char *	buf;
	char *	str;
	int	disp;
	int	period;
{
	char *	save = buf;
	int	chcount = 0;

#ifdef DEBUG
	(void)printf("disp=%d\nperiod=%d\n", disp, period);
#endif

	if (period <= 0)
	{
		(void)fprintf(stdout, "Invalid period %d.\n", period);
		longjmp(startenv, COMM_ERROR);
	}

	for (;*str;str++)
		if (isalpha(*str) && (chcount++ - disp) % period == 0)
			*buf++ = *str;
	*buf='\0';

	return(save);
}

/*
**	Return the string after mapping through chars.
*/
char *
mapstring(buf, str)
	char *	buf;
	char *	str;
{
	int	j = 0;

	do
		buf[j++]=chars[(int) *str];
	while (*str++);

	return(buf);
}

/*
**	Return the non-space chars from str.
*/
char *
no_spaces(buf, str)
	char *	buf;
	char *	str;
{
	char *	save = buf;

	do
		if (!isspace(*str))
			*buf++ = *str;
	while (*str++);

	return (save);
}

/*
**	Put the permutation in the string p into the array t.
**	Perm may be either in the form "1,2,5,4,3" or a key-word.
**	n.b. The key-word "fred" would be equivalent to the perm
**	"3,4,2,1".  The length of the perm is returned.
*/
int
permcreate(p, t, decryptflag)
	char *	p;
	int *	t;
	int	decryptflag;
{
	int	i;
	int	j;
	int	check[MAX_PERM_LENGTH];
	int	next[MAX_PERM_LENGTH];
	char	cb;
	int	cc;
	int	changed;
	char *	pcopy;

	if (!isdigit(*p))
		goto alpha_perm;

	/* The permutation is of the form "4,2,3,1" */
	for (j=0; j<MAX_PERM_LENGTH; j++)
		check[j]=next[j]=0;
	for (j=0; j<MAX_PERM_LENGTH; p++)
		if (*p==',' || *p=='\t' || *p==' ' || *p=='\n' || *p=='\0')
		{
			if (next[j] > MAX_PERM_LENGTH
				||
			    next[j] < 1
				||
			    check[next[j]-1]++)
			{
				(void)fprintf
				(
					stdout,
					"Invalid permutation at %d.\n",
					next[j]
				);
				longjmp(startenv, COMM_ERROR);
			}
			j++;
			if (*p==NULL || *p=='\n')
				break;
		}
		else if (isdigit(*p))
			next[j]=next[j]*10+(int)*p-(int)'0';
		else
		{
			(void)fprintf
			(
				stdout,
				"Invalid permutation at %c.\n",
				*p
			);
			longjmp(startenv, COMM_ERROR);
		}

	goto perm_out;

alpha_perm:
	/* The key is a string e.g. "fred" */

	/* Get rid of any space in the key. */
	pcopy = p;
	CHEWSPACE(pcopy);
	for (j=0; (*pcopy!=NULL && j < MAX_PERM_LENGTH); j++)
	{
		p[j] = *pcopy++;
		next[j]=j+1;
		check[j]=1;
		CHEWSPACE(pcopy);
	}

	if (*pcopy != NULL)
	{
		(void)fprintf
		(
			stdout,
			"Key is too long.  Max length is %d.\n",
			MAX_PERM_LENGTH
		);
		longjmp(startenv, COMM_ERROR);
	}

	/*
	** Bubblesort the string.
	** (Yes, I know its not the most efficient - but there is
	**  a maximum of MAX_PERM_LENGTH elements, anyway).
	*/

	do
	{
		changed=0;
		for (i=0; i<j-1; i++)
			if (p[i]>p[i+1])
			{
				/* Swap the places */
				cb=p[i];
				cc=next[i];
				p[i]=p[i+1];
				next[i]=next[i+1];
				p[i+1]=cb;
				next[i+1]=cc;
				changed++;
			}
	}
	while (changed);

perm_out:

	for (i=0; i<j; i++)
	{
		if (decryptflag==TRUE)
			t[i]=next[i]-1;
		else
			t[next[i]-1]=i;
		if (!check[i])
		{
			(void)fprintf
			(
				stdout,
				"%d not specified in permutation.\n",
				i+1
			);
			longjmp(startenv, COMM_ERROR);
		}
	}
#ifdef DEBUG
	for (i=0; i<j-1; i++)
	{
		(void)fprintf
		(
			stdout,
			"%d, ",
			t[i]
		);
	}
	(void)fprintf
	(
		stdout,
		"%d\n",
		t[j-1]
	);
#endif

	return(j);
}

/*
**	Display both original and substituted strings.
*/
void
display()
{
	int	i;
	int	j = 0;

	for (i = 0; string[i]; i++)
	{
		putchar(chars[(int) string[i]]);

		if (string[i] == '\n')
		{
			do
				putchar(string[j]);
			while (string[j++] != '\n');
			(void)fprintf(stdout, "\n");
		}
	}
}

/*
**	Restore the value of oldstring to string, and forget subs.
*/
void
reset()
{
	int	i;

	for (i = 0; i < SIZ; i++)
		chars[i] = (char) i;

	(void)strcpy(string, oldstring);

	return;
}

/*
**	Grab `n' bytes of memory - and clean up if there is not enough.
*/
char	*
salloc(n)
	unsigned int	n;
{
	register char	*p;

	if ((p = malloc(n)) != NULL)
		return p;
	else
	{
		if (making_area == TRUE)
		{
			(void)fprintf
			(
				stdout,
				"Ran out of memory.  Buffer has been lost.\n"
			);
			clear_area();
		}
		else
		{
			/* Free up any pointers which have been allocated
			** for the string frequency counts, or for the
			** substitution alphabets
			*/
			for (;alphs;)
				free ((char *) alph[--alphs]);
		
			for (;nels;)
				free ((char *) freq[--nels]);

			(void)printf("Ran out of memory.\n");
		}

		longjmp(startenv, MEM_OVFLOW);

		/* This will never be executed, but it keeps lint happy */
		return((char *)NULL);
	}
}

/*
**	Allocate areas of size `buf_size' to each of the buffers
*/
void
makearea(buf_size)
	int	buf_size;
{
#ifndef NOSIG
	/* Disable interrupts - this is a critical section */
	intp = signal(SIGINT,SIG_IGN);
	quitp = signal(SIGQUIT,SIG_IGN);
#endif

	making_area = TRUE;

	free_area();

	buf = salloc(buf_size);
	buf1 = salloc(buf_size);
	string = salloc(buf_size);
	lstring = salloc(buf_size);
	oldstring = salloc(buf_size);
	loldstring = salloc(buf_size);
	alpha = salloc(buf_size);

	making_area = FALSE;

#ifndef NOSIG
	/* Enable interrupts */
	intp = signal(SIGINT,intp);
	quitp = signal(SIGQUIT,quitp);
#endif

	return;
}

/*
**	Determine the size of the file to be read in; allocate
**	enough memory for all working buffers; and then read the
**	file in.
*/
int
load_area(fname)
	char *	fname;
{
	FILE *		INFILE;
	struct stat	statbuf; /* File info used to determine file size */
	int		a_size;  /* Size of area to be malloced. */

	if (fname == NULL || *fname == '\0')
		return(-1);

	if (stat(fname, &statbuf)!=0 || (INFILE=fopen(fname, "r")) == NULL)
	{
		(void)fprintf(stdout, "Can't open %s\n", fname);
		return(-1);
	}

	/* Allocate enough memory to be able to cope with any re-formatting
	** of the string.  This only occurs with the Block-encrypt and
	** Transposition commands. */
	a_size = ((int)statbuf.st_size*(TRANS_BLOCK_SIZE+1))/TRANS_BLOCK_SIZE;
	/* Just in case of round down, add another block on */
	a_size += TRANS_BLOCK_SIZE;

	makearea(a_size);

	oldstring[fread(oldstring, 1, (unsigned)statbuf.st_size, INFILE)]='\0';

	reset();

	backup();

	(void)fclose(INFILE);

	return(NULL);
}

/*
**	Write the string str to the file s.
*/
int
write_to(s, str)
	char *	s;
	char *	str;
{
	int	i;
	int	fd;

	if ((fd = creat(s, 0777)) == SYSERROR)
	{
		(void)fprintf(stdout, "Can't open/create %s\n", s);
		return(-1);
	}

	for (i = 0; str[i]; i++)
	{
		iob[i % 512] = str[i];
		if ((i + 1) % 512 == 0)
			(void)write(fd, iob, 512);
	}

	if (i % 512)
		(void)write(fd, iob, i % 512);
	
	(void)close(fd);
	return(0);
}

/*
**	Apply the Nth permutation to the permutation perm.
*/
int *
permgen(perm, length, N)
	int *	perm;
	int	length;
	int	N;
{
	int	i;
	int	hold[MAX_PERM];
	int	shift;

	if (length > 1)
	{
		if ((shift = N / fact[length - 1]) > 0)
		{
			/* Perform transposition */
			for (i=0; i < length; i++)
				hold[i] = perm[(i+shift) % length];

			/* Copy it back */
			for (i=0; i < length; i++)
				perm[i] = hold[i];
		}

		(void)permgen(perm+1, length-1, N);
	}

	return(perm);
}

/*
**	Permute the chars of str into buf according to trans.
*/
void
permstr(buf, str, trans, len)
	char *	buf;	/* destination buffer */
	char *	str;	/* source buffer */
	int *	trans;	/* transposition permutation */
	int	len;	/* length of trans */
{
	int	i;

	for (i=0; str[i] != NULL; i++)
		buf[i-(i%len) + trans[i % len]] = str[i];

	/* Fill up any left-over places with spaces */
	for (; i % len; i++)
		buf[i-(i%len) + trans[i % len]] = ' ';

	/* Put the null at the end */
	buf[i]='\0';
}

/*
**	Recreate the cleartext from the ciphertext (src) and the perm (p).
*/
void
unblockperm(dest, src, p, cols)
	char *	dest;
	char *	src;
	int *	p;
	int	cols;
{
	int	j;
	int	plc;
	int	slen = strlen(src);

	for (j=0; j<cols; j++)
		for (plc=p[j]; plc<slen; plc += cols)
		{
#ifdef DEBUG
			(void)printf(" [%d:%c]", plc, *src);
#endif
			dest[plc] = *src++;
		}
	dest[slen] = '\0';
}

/*
**	Create the ciphertext from the cleartext (src) and the perm (p).
*/
void
blockperm(dest, src, p, cols)
	char *	dest;
	char *	src;
	int *	p;
	int	cols;
{
	int	j;
	int	plc;
	int	slen = strlen(src);

	for (j=0; j<cols; j++)
		for (plc=p[j]; plc<slen; plc += cols)
			*dest++ = src[plc];
	*dest = '\0';
}

void
set_f(str)
	char *	str;
{
	int	i;

	/* Initialise counters. */
	for (i=0; i<26; i++)
		f[i]=0;

	for (; *str != NULL; str++)
		if (isalpha(*str))
			if (isupper(*str))
				f[*str-'A']++;
			else
				f[*str-'a']++;
	return;
}

/*
**	Graph the frequency of the alphabetic chars in str.
*/
void
grap_freq(str)
	char *	str;
{
	int	i;
	int	max = 0;
	int	inc;
	int	row;

	set_f(str);

	/* Find maximum column */
	for (i=0; i<26; i++)
		if (f[i]>max)
			max=f[i];

	if (max <= 0)
		/* Nothing to graph */
		return;

	row=(max>ROWS)?ROWS:max;
	inc=max/row;

	for (; row; row--)
	{
		for (i=0; i<26; i++)
			if (f[i] >= row*inc)
				(void)printf("* ");
			else
				(void)printf("  ");
		putchar('\n');
	}

	for(i='a'; i<='z'; i++)
		(void)printf("%c ", i);
	(void)printf("\n");

	return;
}

freq_dist(str, seqlen, outnum)
	char *	str;
	int	seqlen;
	int	outnum;
{
	int	c;
	int	j;
	int	g;
	int	gl;
	int	gh;

#ifdef DEBUG
	(void)printf("seqlen = %d\n", seqlen);
	(void)printf("outnum = %d\n", outnum);
	(void)printf("string = %s\n", str);
	(void)printf("strlen(str) = %d\n", strlen(str));
#endif

	if (seqlen > strlen(str))
	{
		(void)fprintf(stdout, "The ciphertext is not that long!!\n");
		return;
	}

	if (seqlen > MAX_LETTS || seqlen <=0)
	{
		(void)fprintf
		(
			stdout,
			"Can only analyse strings up to length %d\n",
			MAX_LETTS
		);
		return;
	}

	for (nels = 0; str[seqlen-1]!=NULL ;str++)
	{
#ifdef DEBUG
		(void)printf("nels=%d\n", nels);
#endif
		gh = nels - 1;
		gl = 0;

		if (nels > 0)
		{
			/* Find where it goes in the list using binary search */
			do
			{
				g=(gh+gl)/2;
				c=strncmp(str, freq[g]->lett, seqlen);
				if (c > 0)
					gl=g+1;
				else /* c < 0 */
					gh=g-1;
			}
			while (gh >= gl && c);

			if (!c)
			{
				/* Already in list */
				freq[g]->num++;
				continue;
			}
		}

		if (nels >= MAX_DIFF_STRINGS)
		{
			(void)fprintf
			(
				stdout,
				"Error: More than %d unique strings.\n",
				MAX_DIFF_STRINGS
			);
			break;
		}

		for (j = nels++; j>gl;j--)
			freq[j]=freq[j-1];
		freq[gl]=(qtype)salloc(sizeof (struct lf));
		freq[gl]->num=1;
		(void)mstrncpy(freq[gl]->lett, str, seqlen);
		freq[gl]->lett[seqlen]='\0';
	}

#ifdef DEBUG
	(void)printf("Sorting %d elements.\n");
#endif
	quicksort(freq,nels);
#ifdef DEBUG
	(void)printf("Sorted.\n");
#endif

	/* Print table */
	for (j=0; nels; j++)
	{
		nels--;
		if (j < outnum)
			(void)printf
			(
				"%s  %4d\n",
				freq[nels]->lett,
				freq[nels]->num
			);
		free((char *)freq[nels]);
	}

	return;
}

/*
 *	Quicksort.
 *
 */
quicksort(base, nels)
	register qtype	*base;
	register int	nels;
{
	while (nels > 1)
	{
		if (nels < 5)
		{
			register int	i;
			register int	j;
			register qtype	temp;

			/*
			 *	Bubblesort quicker on < 5 elements.
			 *	At most 6 comparisons.
			 */
			i = nels;
			while (--i > 0)
			{
				j = i;
				while (--j >= 0)
				{
					if (qcmp(&base[i], &base[j]) < 0)
					{
						temp = base[j];
						base[j] = base[i];
						base[i] = temp;
					}
				}
			}
			return;
		}
		else
		{
			register qtype	*q;
			register qtype	*b;
			register qtype	*t;
			register int	m;
			qtype		temp;

			/*
			 *	Make the pivot.
			 */
			q = base + nels / 2;
			temp = *q;
			b = base;
			t = base + nels - 1;
			*q = *t;

			/*
			 *	Segment the entries about the pivot.
			 */
			while (b != t)
			{
				while (qcmp(b, &temp) < 0)
				{
					if (++b == t)
						goto finish;
				}
				*t = *b;

				do
				{
					if (--t == b)
						goto finish;
				}
				while (qcmp(t, &temp) > 0);

				*b++ = *t;
			}
		finish:
			*b = temp;
			m = nels;
			nels = b - base;
			m -= nels + 1;

			/*
			 *	Recurse on smaller side.
			 */
			if (nels > m)
			{
				if (m > 1)
					quicksort(b + 1, m);
			}
			else
			{
				if (nels > 1)
					quicksort(base, nels);
				base = b + 1;
				nels = m;
			}
		}
	}
}

int
qcmp(a, b)
	qtype *	a;
	qtype *	b;
{
	if ((*b)->num == (*a)->num)
		return (strcmp((*b)->lett, (*a)->lett));
	else
		return ((*a)->num - (*b)->num);
}

/*
**	Calculate the Index of Coincidence of the string str.
*/
double
ic(str)
	char *	str;
{
	int	c;
	int	N = 0;
	double	IC = 0;

#ifdef DEBUG
	(void)printf("ic-str=%s\n", str);
#endif

	set_f(str);

	for (c=0; c<26; c++)
	{
		IC += f[c]*(f[c]-1);
#ifdef DEBUG
		(void)printf("f[%d]=%d  ", c, f[c]);
#endif
		N += f[c];
	}

#ifdef DEBUG
	(void)printf("IC=%f\nN=%d\n", IC, N);
#endif
	if (N>0)
		return (IC/(N*(N-1)));
	else
		return (0);
}


S_usage()
{
	(void)fprintf(stdout, "Usage: S [-] -[gvbB] {keys}\n");

	/* Free up pointers to alphabets */
	free_up();

	longjmp(startenv, COMM_ERROR);
}

/*
**	Free all the alphabets which were used in this substitution command
*/
free_up()
{
	for (;alphs;)
		free((char *) alph[--alphs]);

	return;
}

int *
new_alph()
{
	int *a;
	int i;

	a = (int *)salloc(4*128);

	for (i=128; i--; a[i]=i);

	return(a);
}

int
S(buf, str, argc, argv)
	char *	buf;		/* Where the substituted string goes */
	char *	str;		/* The start string */
	int	argc;
	char *	argv[];
{
	int	i;
	int	j;
	char	k;
	char	hb1[27];
	char	hb2[27];
	int	len;
	int	col;
	int	function=INVALID;	/* Substitution method */
	char *	key[MAX_ALPHABETS];	/* Pointer array to each key string */
	int	keys = 0;		/* Number of keys specified */
	int	charnum = 0;		/* counts number of chars processed */
	int	decrypt = 0;		/* Encrypt=0.  Decrypt=1; */

#ifdef DEBUG
	for (i=0; i<argc; i++)
		puts(argv[i]);
	(void)printf("argc=%d\n", argc);
#endif
	for (i=1; i<argc; i++)
		if (argv[i][0] == '-')
		{
			if (argv[i][1] && function!=INVALID)
			{
				(void)fprintf
				(
					stdout,
					"Only one function may be specified.\n"
				);
				S_usage();
			}
			else if (!argv[i][1] && decrypt++)
			{
				(void)fprintf(stdout, "Two decrypts??\n");
				S_usage();
			}
				
			switch (argv[i][1])
			{
			case '\0' :
				break;
			case 'g' :
				function=GENERAL;
				break;
			case 'v' :
				function=VIGENERE;
				break;
			case 'b' :
				function=BEAUFORT;
				break;
			case 'B' :
				function=VAR_BEAUFORT;
				break;
			default :
				(void)fprintf
				(
					stdout,
					"Invalid function specified.\n"
				);
				S_usage();
			}
		}
		else
		{
			if (keys >= MAX_ALPHABETS)
			{
				(void)fprintf
				(
					stdout,
					"More than %d alphabets.\n",
					MAX_ALPHABETS
				);
				S_usage();
			}

			/* Check that key is valid. */
			for (j=0; (k=argv[i][j]); j++)
				if (!isalpha(k))
				{
					(void)fprintf
					(
						stdout,
						"Invalid key character %c.\n",
						k
					);
					S_usage();
				}
				else if (isupper(k))
					argv[i][j]=k-'A'+'a';
			key[keys++]=argv[i];
		}

	/* Set up alphabets */
	switch (function)
	{
	case INVALID :
		(void)fprintf
		(
			stdout,
			"No function specified.\n"
		);
		S_usage();
	case VIGENERE :
	case VAR_BEAUFORT :
		if (keys != 1)
		{
			(void)fprintf
			(
				stdout,
				"Only one key may be given with this cipher.\n"
			);
			S_usage();
		}
		while(k = *(key[0]++))
		{
			if (alphs >= MAX_ALPHABETS)
			{
				(void)fprintf
				(
					stdout,
					"More than %d alphabets.\n",
					MAX_ALPHABETS
				);
				S_usage();
			}

			k=k-'a';

			if (function==VAR_BEAUFORT)
				k=26-k;

			if (decrypt)
				k=26-k;

			alph[alphs]=new_alph();
			for (i='a'; i<='z'; i++)
			{
				alph[alphs][i] += k;
				if (alph[alphs][i] > 'z')
					alph[alphs][i]-=26;
			}
			for (i='A';i<='Z';i++)
			{
				alph[alphs][i] += k;
				if (alph[alphs][i] > 'Z')
					alph[alphs][i]-=26;
			}
			alphs++;
		}
		break;
	case BEAUFORT :
		if (keys != 1)
		{
			(void)fprintf
			(
				stdout,
				"Only give one key for a Beauford cipher.\n"
			);
			S_usage();
		}
		while(k = *(key[0]++))
		{
			if (alphs >= MAX_ALPHABETS)
			{
				(void)fprintf
				(
					stdout,
					"More than %d alphabets.\n",
					MAX_ALPHABETS
				);
				S_usage();
			}

			k=k-'a';

			alph[alphs]=new_alph();
			for (i='a';i<='z';i++)
			{
				alph[alphs][i] = 'a' + 'a' + k - alph[alphs][i];
				if (alph[alphs][i] < 'a')
					alph[alphs][i]+=26;
			}
			for (i='A';i<='Z';i++)
			{
				alph[alphs][i] = 'A' + 'A' + k - alph[alphs][i];
				if (alph[alphs][i] < 'A')
					alph[alphs][i]+=26;
			}
			alphs++;
		}
		break;
	case GENERAL :
		/* Initalise hb1, hb2 to nulls */
		for (i=0; i<27; i++)
			hb1[i]=hb2[i]=0;

		for (alphs=0; alphs < keys; alphs++)
		{
			if (alphs >= MAX_ALPHABETS)
			{
				(void)fprintf
				(
					stdout,
					"More than %d alphabets.\n",
					MAX_ALPHABETS
				);
				S_usage();
			}

			alph[alphs]=new_alph();

			/* Make key[alphs] contain unique chars */
			for (i=0; *key[alphs] && i<26; key[alphs]++)
			{
				if (!strchr(hb1, *key[alphs]))
					hb1[i++] = *key[alphs];
			}
#ifdef DEBUG
			(void)printf("hb1 = %s\n", hb1);
#endif
			if (*key[alphs])
			{
				(void)fprintf
				(
					stdout,
					"Weird things are happening!!\n"
				);
				exit(1);
			}

			len = strlen(hb1);

			/* Fill the rest of the key with the unused letters */
			for (k='a', i=len; i<26; i++)
			{
				while (strchr(hb1, k))
					k++;
				hb1[i]=k;
			}

			for (col=0, j=0, i=0; i<26; i++)
			{
				if (j*len+col > 25)
				{
					j=0;
					col++;
				}
				hb2[i]=hb1[j++ * len + col];
			}
#ifdef DEBUG
			(void)printf("hb1=%s\nhb2=%s\n", hb1, hb2);
#endif

			for (i=0; i<26; i++)
				if (decrypt)
				{
					alph[alphs][hb2[i]] = i+'a';
					alph[alphs][hb2[i]-'a'+'A'] = i+'A';
				}
				else
				{
					alph[alphs][i+'a'] = hb2[i];
					alph[alphs][i+'A'] = hb2[i]-'a'+'A';
				}

		}
		break;

	default :
		(void)fprintf
		(
			stdout,
			"Program Logical Error.\n"
		);
		S_usage();
	}

	/* Perform the encoding */
	for (i=0; str[i]!=NULL; i++)
	{
		buf[i]=alph[charnum % alphs][(int)str[i]];
		if (isalpha(str[i]))
			charnum++;
	}
	buf[i]='\0';

	free_up();
	return(0);
}

/*
**	Apply func to str with N! different permutations - printing out
**	those containing the regular expression.
*/
void
exhaust(str, N, exp, func)
	char *		str;
	int		N;
	char *		exp;
	void		(* func)();
{
	char *	p;
	char	l1[80];		/* line buffer for reply to question */
	int	i;
	int	j;

	if (exp && (p = re_comp(exp)))
	{
		(void)fprintf(stdout, "%s\n", p);
		return;
	}

	/* Don't permute spaces */
	(void)no_spaces(alpha, str);

#ifdef DEBUG
	(void)printf("alpha=");
	(void)printf("%s", alpha);
#endif

	/* Try all N! possible perms */
	for (i=1; i<fact[N]; i++)
	{
		/* Reset permutation block */
		for (j=0; j<N; j++)
			t[j]=j;
		
		(* func)(buf, alpha, permgen(t, N, i), N);
		if ((exp && re_exec(buf)) || !exp)
		{
#ifdef DEBUG
			(void)printf("perm is ");
			for (j=0; j<N; j++)
				(void)printf("%d ", t[j]);
			putchar('\n');
			(void)printf("Permuted string=%s", buf);
#endif
			/* Get rid of those spaces again. */
			(void)no_spaces(buf1, buf);
			/* Re-format string */
			(void)blkstring
			(
				buf,
				buf1,
				TRANS_BLOCK_SIZE,
				COLS/(TRANS_BLOCK_SIZE+1)
			);
			(void)printf
			(
				"%s",
				mapstring(buf1, buf)
			);
			(void)fprintf(stdout, "Accept (y/n/q)? ");
			p = l1;
			gets(p);
			CHEWSPACE(p);
			if (*p == 'y' || *p == 'Y')
			{
				(void)strcpy(str, buf);
				return;
			}
			else if (*p == 'q' || *p == 'Q')
				return;
		}
	}
	(void)fprintf(stdout, "Out of permutations.\n");
	return;
}

/*
**	Free up all the various buffer areas.  A free area has NULL value.
*/
free_area()
{
	if (buf != NULL)
	{
		free(buf);
		buf = NULL;
	}
	if (buf1 != NULL)
	{
		free(buf1);
		buf1 = NULL;
	}
	if (string != NULL)
	{
		free(string);
		string = NULL;
	}
	if (lstring != NULL)
	{
		free(lstring);
		lstring = NULL;
	}
	if (oldstring != NULL)
	{
		free(oldstring);
		oldstring = NULL;
	}
	if (loldstring != NULL)
	{
		free(loldstring);
		loldstring = NULL;
	}
	if (alpha != NULL)
	{
		free(alpha);
		alpha = NULL;
	}
}

/*
**	Make the area nothing.
*/
clear_area()
{
	/* Allocate minimal buffer area initially */
	makearea(4);
	/* initialise the buffers to nulls */
	oldstring[0]='\0';
	/* Initialise the mapping array */
	reset();
	/* backup will initialise the backup strings */
	backup();
}

usage()
{
	(void)fprintf
	(
		stdout,
		"Usage: %s [-s] [-u] [file]\n",
		my_name
	);
	exit(1);
}

void process_line();

int
main(argc, argv)
	int	argc;
	char *	argv[];
{
	int	i;
	
	if ((my_name = strrchr(argv[0], '/')) == NULL || *++my_name == '\0')
		my_name = argv[0];

	for (i=1; i<argc; i++)
		if (argv[i][0] == '-')
			switch (argv[i][1])
			{
			case 's':
				silent = TRUE;
				break;
			case 'u':
				setbuf(stdin, (char *)NULL);
				setbuf(stdout, (char *)NULL);
				break;
			default:
				usage();
			}
		else
		{
			(void)strcpy(cur_file, argv[i]);
			break;
		}

	/* Set up variables */
	tmpfil = mktemp("/tmp/kryptoXXXXXX");
	if ((editor = getenv("EDITOR")) == NULL)
		editor = "/bin/em";
	if ((shell = getenv("SHELL")) == NULL)
		shell = "/bin/sh";

	switch (setjmp(startenv))
	{
	case FIRST_TIME:
		clear_area();
		(void)load_area(cur_file);
		if (silent == FALSE)
			(void)printf("Type '?' for help\n");
		break;
	case INT_RETURN:
	case COMM_ERROR:
	case MEM_OVFLOW:
		break;
	default:
		(void)fprintf
		(
			stdout,
			"Weird value returned by setjmp.\n"
		);
		break;
	}

#ifndef NOSIG
	intp = signal(SIGINT,interrupt);
	quitp = signal(SIGQUIT,interrupt);
#endif

	while (TRUE)
	{
		if (silent == FALSE)
			(void)fprintf(stdout, "-> ");
		process_line(gets(line));
	}
}

void
process_line(p)
	char *	p;
{
	int	i;
	int	j;
	double	this_ic;
	double	tot_ic;
	int	decrypt;

	if (!p)
	{
	    /* The user has typed a ^D */
	    puts("");
	    exit(0);
	}
	CHEWSPACE(p);
	switch(*p)
	{
	case '\0':
		break;
	case '?':
		(void)fprintf(stdout, help_message);
		break;
	case 'r':
		p++;
		CHEWSPACE(p);
		if (*p == '\0')
			(void)fprintf(stdout, "Usage: r <file>\n");
		else
			if (load_area(p) == NULL)
				(void)strcpy(cur_file, p);
		break;
	case 'w':
		p++;
		CHEWSPACE(p);
		if (*p == '\0')
			if (cur_file != NULL && *cur_file != '\0')
				(void)write_to
				(
					cur_file,
					mapstring(buf1, string)
				);
			else
				(void)fprintf
				(
					stdout,
					"Usage: w <file>\n"
				);
		else
			(void)write_to(p, mapstring(buf1, string));
		break;
	case 'z':
		backup();
		reset();
		break;
	case 'q':
		exit(0);
	case 'u':
		restore();
		break;
	case 'i':
		p++;
		if (sscanf(p, " %d", &period) != 1)
			period=1;

		/* ignore period=0 */
		if (period <= 0)
			break;

		for (tot_ic=0, disp=0; disp<period; disp++)
		{
			this_ic = ic(selstring(buf, string, disp, period));
			(void)fprintf
			(
				stdout,
				"IC = %5.3f\n",
				this_ic
			);
			tot_ic += this_ic;
		}
		(void)fprintf
		(
			stdout,
			"Average = %5.3f\n",
			(double)tot_ic/period
		);
		break;
	case 'g':
		p++;
		if (sscanf(p, " %d %d", &disp, &period) != 2)
		{
			disp=0;
			period=1;
		}
		grap_freq(selstring(buf1, string, disp, period));
		break;
	case 'f':
		p++;
		switch (sscanf(p, " %d %d", &seqlen, &num))
		{
		case 0 :
			seqlen=1;
			num=ROWS;
			break;
		case 1 :
			num=ROWS;
			break;
		case 2 :
			break;
		default :
			(void)fprintf(stdout, "Usage : f [seqlen [num]]\n");
			longjmp(startenv, COMM_ERROR);
		}
		freq_dist(no_spaces(buf, string), seqlen, num);
		break;
	case 't':
		p++;
		expr=expr_array;
		switch (sscanf(p, " %d /%s/", &n, expr))
		{
		case 1:
			expr = 0;
		case 2:
			if (n >= 1 && n <= MAX_PERM)
				break;
		default:
			(void)fprintf(stdout, "Usage: t <number> [/regexp]\n");
			longjmp(startenv, COMM_ERROR);
		}

		if (expr && strchr(expr, ' '))
		{
			(void)fprintf(stdout, "Can't match spaces.\n");
			break;
		}

		backup();
		exhaust(string, n, expr, permstr);
		break;
	case 'T':
		p++;
		CHEWSPACE(p);
		if (*p == '-')
		{
			p++;
			CHEWSPACE(p);
			decrypt = TRUE;
		}
		else
			decrypt = FALSE;
		n = permcreate(p, t, decrypt);

		if (n <= 0)
		{
			(void)fprintf
			(
				stdout,
				"Usage: T [-] <perm> | <key>\n"
			);
			break;
		}

		/* Save the old one for undoes */
		backup();

		/* Put the transposed string into buf */
		(void)permstr(buf1, no_spaces(buf, string), t, n);
		(void)no_spaces(buf, buf1);

		/* Store new string after formatting */
		(void)blkstring
		(
			buf1,
			buf,
			TRANS_BLOCK_SIZE,
			COLS/(TRANS_BLOCK_SIZE+1)
		);
		(void)strcpy(string, buf1);

		break;
	case 'B':
		p++;
		CHEWSPACE(p);
		if (*p == '-')
		{
			p++;
			CHEWSPACE(p);
			decrypt = TRUE;
		}
		else
			decrypt = FALSE;
		n = permcreate(p, t, TRUE);

		if (n<=0)
		{
			(void)fprintf
			(
				stdout,
				"Usage: B [-] <perm> | <key>\n"
			);
			break;
		}

		/* Save the old ones for undoes */
		backup();

		/* Put the newly blocked string into buf */
		if (decrypt == TRUE)
			unblockperm(buf, no_spaces(buf1, string), t, n);
		else
			blockperm(buf, no_spaces(buf1, string), t, n);

		/* Store new string after formatting */
		(void)blkstring
		(
			buf1,
			buf,
			TRANS_BLOCK_SIZE,
			COLS/(TRANS_BLOCK_SIZE+1)
		);
		(void)strcpy(string, buf1);

		break;
	case 'b':
		p++;
		expr=expr_array;
		switch (sscanf(p, " %d /%s/", &n, expr))
		{
		case 1:
			expr = 0;
		case 2:
			if (n >= 1 && n <= MAX_PERM)
				break;
		default:
			(void)fprintf(stdout, "Usage: b <number> [/regexp]\n");
			longjmp(startenv, COMM_ERROR);
		}

		if (expr && strchr(expr, ' '))
		{
			(void)fprintf(stdout, "Can't match spaces.\n");
			break;
		}

		backup();
		exhaust(string, n, expr, unblockperm);
		break;
	case 's':
		p++;
		if (sscanf(p, " %c %c", &c1, &c2) != 2)
			(void)fprintf
			(
				stdout,
				"Usage: s <char 1> <char 2>\n"
			);
		else
		{
			backup();
			chars[(int)c1]=c2;
		}
		break;
	case 'S':
		subargc=0;
		subarg[subargc++]=p;
		for (; *p != NULL; p++)
			if (isspace(*p))
			{
				*p++='\0';
				CHEWSPACE(p);
				subarg[subargc++]=p;
			}
#ifdef DEBUG
		for (i=0; i<subargc; i++)
			puts(subarg[i]);
#endif
		if ( S(buf, string, subargc, subarg) == 0)
		{
			/* Substitution went ok */
			backup();
			(void)strcpy(string, buf);
			/* Nullify the mapping array */
			for (i=0; i<SIZ; i++)
				chars[i]=i;
		}
		break;
			
	case 'p':
		display();
		break;
	case 'l':
		if (sscanf(p, "l %d %d", &i, &j) != 2)
			(void)fprintf
			(
				stdout,
				"%s",
				mapstring(buf1, string)
			);
		else
		{
			(void)blkstring(buf, no_spaces(buf1, string), i, j);
			(void)fprintf
			(
				stdout,
				"%s",
				mapstring(buf1, buf)
			);
		}

		break;
	case 'e':
		if (write_to(tmpfil, string) < 0)
			break;
		switch (fork())
		{
		case SYSERROR:
			(void)fprintf(stdout, "Cannot fork.\n");
			break;
		case 0:
			execlp(editor, editor, tmpfil, (char *)0);
			(void)fprintf(stdout, "Cannot exec editor.\n");
			exit;
		default:
#ifndef NOSIG
			intp = signal(SIGINT, SIG_IGN);
			quitp = signal(SIGQUIT, SIG_IGN);
#endif
			backup();
			(void)wait((int *) 0);
#ifndef NOSIG
			(void)signal(SIGINT, intp);
			(void)signal(SIGQUIT, quitp);
#endif
			if (load_area(tmpfil) == (-1))
			{
				(void)fprintf
				(
				stdout,
				"Internal Error. Temp file name is corrupted.\n"
				);
				exit(1);
			}
			unlink(tmpfil);
		}
		break;
	case '!':
		p++;
		CHEWSPACE(p);
		switch (fork())
		{
		case SYSERROR:
			(void)fprintf(stdout, "Cannot fork.\n");
			break;
		case 0:
			if (*p)
			    execlp(shell, shell, "-c", p, (char *)0);
			else
			    execlp(shell, shell, (char *)0);
			(void)fprintf(stdout, "Cannot exec shell.\n");
			exit;
		default:
#ifndef NOSIG
			intp = signal(SIGINT, SIG_IGN);
			quitp = signal(SIGQUIT, SIG_IGN);
#endif
			(void)wait((int *) 0);
#ifndef NOSIG
			(void)signal(SIGINT, intp);
			(void)signal(SIGQUIT, quitp);
#endif
		}
		break;
	default:
		(void)fprintf(stdout, "Type '?' for help\n");
	}
	return;
}
