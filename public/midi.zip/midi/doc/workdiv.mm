.H 1 "WORK DIVISION IN THE MIDI PROJECT"
In this project we decided to perform separate tasks each towards the final
product. That is, we each worked separately rather than everyone working on
everything. Notwithstanding this, the group as a whole held a meeting to
discuss and design the hardware and software sections of the MIDI project.
The individual responsibilities were:
.AL i
.LI
Michael Barr-David
.AL a
.LI
Hardware design
.LI
Hardware construction
.LI
Debugging
.LI
Hardware description/documentation
.LE
.LI
Chris Tham
.AL a
.LI
Monitor modifications for the SCC
.LI
Interrupt and other low level device software
.LI
Hardware test-out software
.LI
Assisting Debugging
.LI
Project documentation especially MIDI description
.LE
.LI
Jarryl Wirth
.AL a
.LI
Software design
.LI
Software implementation for both  the real and test environment
.LI
Users' guide for MIDI to RS 232 interface
.LI
Software description/documentation
.LE
.LI
Fred Holmberg
.AL a
.LI
Assisting hardware construction
.LI
Assisting debugging
.LE
.LE
.P 1
