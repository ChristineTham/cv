.H 1 "HARDWARE DESCRIPTION"
.H 2 "Introduction"
.P
The hardware design of the microprocessor board uses a Motorola MC6809
Microprocessor Unit running at a clock speed of 1 MHz.  8K of ROM
(Read Only Memory) and 32K of RAM (Random Access Memory) provide ample
space for software development for a MIDI data recorder and SDLC station
toolkit.  Four serial communications channels are available from two Zilog
Z8530 SCC (Serial Communications Controller) chips, consisting of
two asynchronous channels for the use
of the terminal interface and connection to the host Sattellite Coprocessor
System, one serial asynchronous MIDI channel
and one synchronous SDLC channel employing
NRZI at 1953.125 baud.  Line drivers are provided for the asynchronous
channels in conformance with the RS-232 interface standard.  The MIDI
Channel is interfaced per MIDI 1.0 specification.
In addition, a Motorola MC6840 PTM (Programmable Timer Module) allows
timing of MIDI and SDLC commands, as well as providing output for an
inbuilt metronome.
.H 2 "Hardware Design"
.H 3 "General"
The MIDI project started with relatively few external constraints ( As
compared to the environment group, which had to worry about A-D conversion,
etc. ) The few that did exist were:
.AL i
.LI
The MIDI channel. ( Basically a current loop asynchronous 31.25 kBaud
channel. )
.LI
The host/terminal channels. ( Two 9600 baud RS 232 channels. ) One of
which would finally become the RS 232 end of the MIDI to RS 232 interface; and
.LI
The necessity to have system timing to "time stamp" MIDI events.
.LE
.P
At the group discussion of hardware and software,
it was also decided that the MIDI project would require 32K RAM and 8K PROM.
The above requirements were
the constraints I had when doing the hardware design.
.P
On the advice of rex and Chris Tham, it was my understanding that the
MIDI channel requires special hardware. In particular, it requires the use of
a high speed ACIA. I selected the Z8530 SCC ( again on advice ) on the grounds
that they were available and there seemed to be some knowledge of their
operation in the department. ( The last was a mistaken belief. )
The MIDI specification announces that MIDI is a current loop interface, and
this is implemented via an opto-isolator on received data. The aforementioned
opto-isolator must be high speed. ( Rise and fall times of less than 2
microseconds. ) The availability of such a part was found to be poor.
.P
The host/terminal interface was to be supplied via the use of a second SCC
chip. ( One SCC has two asynchronous channels on it. ) The decision to use
the SCC a second time was jointly motivated: firstly, so that the system could
be as simple as possible, ( i.e. One type of ACIA is a simpler design than two
different types. ) and secondly, the system originally had to be as small as
possible in order to fit on the smaller wire-wrap boards. ( As it turned out
we were supplied with larger boards. )
.P
System timing is provided by a 6840 Programmable Timer Module ( PTM ).
The availability of this part was also found to be extremely poor.
.P
The system RAM is provided by four 6264 8K by 8 Static RAM chips, and the
system ROM by two 2532 4K by 8 EPROMs.
.P
The rest of the MIDI board contains only the CPU ( a Motorola 6809 ) and
various "glue" chips. These include address decoding and RS 232 line
conversion chips as well as a few inverters and NAND gates.
.P
An optional metronome was to be provided via the use of two channels on
the 6840 PTM ( Only one is used for system timing. ). ( The availability
of 3" speakers was found to be surprisingly poor ... )
.P
.H 3 "System Interrupts"
The 6840 is connected to the CPU non-maskable interrupt ( NMI ) line, in
order to preserve timing information. These interrupts would be created during
system initialization.
.P
After much debate it was decided to connect the two SCC chips to fast interrupt
request ( FIRQ ) and later move them to interrupt request ( IRQ ) if that
became desirable. In the later course of events it was decided to poll the
two SCC chips and the discussion of IRQ vs FIRQ became irrelevant.
.P
.H 2 "Hardware Construction"
The first items wired up on the board were the power supply lines. ( 0V, +5V,
-12V, and +12V. ) The conducting track around the edge of the board provided
an easy way to supply the +12V and -12V lines. ( The track was cut near
the location of the 1488 line driver chip. )
The chip pinouts ( courtesy of Jarryl ) were then glued on
and power supplies to the individual chips were soldered / wire-wrapped.
The power supply rails were then marked in indelible texta.
.P
When wiring all the rest of the project it was decided to put the simplest
wiring on the "bottom", closest to the board and more complex wiring higher
and higher "up". Under this scheme address and data buses would be near
the "bottom" whilst chip enable lines would be near the "top". This was
deemed a good idea as it was perceived to be more likely to incorrectly
wire a fairly random chip enable line rather than incorrectly wire one of
the bus lines.
.P
The address and data lines were wired across the board first and then
wired together along one edge of the board. ( To the extent that this
was possible. ) This resulted in a final "U" shaped for the address and data
buses. This was a sensible scheme as it meant that most of the cross wiring
that would have been covering chips on the board was in fact covering only
a power supply line. Data was wired in blue and address lines in pink.
.P
The address decoding circuitry was next wired in black and chip enable
lines were wired in a creamy colour. ( I think they were, although I am
red/green colour blind ... what would I know? ) The line drivers and receivers
were wired up to SCC0 next and then the opto-isolator was wired. ( This
was wired up for a PC-900, so it will have to be changed to support the
opto-isolator actually received. )
.P
The read/write lines, interrupt lines and reset line were then wired. Pull up
resistors were wired in last ( in white ) because we didn't know the pinouts
for the resistor pads. This was probably sensible as changes are likely
to be made to which lines are pulled up.
.P
Finally MIDI sockets, the reset switch, resistors and crystals were added.
Despiking capacitors were added as an afterthought using surface-mounted\(rg
technology.
.P
.H 2 "Hardware Testing and Debugging"
Once the board was wired up and checked ( at least to a small extent ), we
inserted the 6809 CPU and 4MHz crystal and then we powered up. No explosions or
burning smells were evidenced, much to the pleasure of the group members
present. We checked for an E-clock, and behold we had E-clock!
Having been thus encouraged we inserted two RAMs, the host/serial
SCC, line converters, address decoding chips, burnt a PROM and inserted it. No
dice. It did nothing, alas.
.P
We rechecked the board and discovered a wiring error in the address decoding
circuitry ( Not due to me. ). We corrected the error and tried again. No
response.
.P
An exhaustive search for our error then took place. ( We still have not 
found the error. ) Using the CRO at first we attempted to discover the
error. We still had an E-clock, were getting chip enables, and address
lines looked reasonable. We tested address decoding and read/write circuitry
and proved to our satisfaction that it works. ( Admittedly only at slow speed.
)
.P
We decided to use maximum effort and collected the Logic State Analyser ( LSA
). Connecting it up to our board we found that the CPU was executing
instructions correctly and appears to correctly initialize the SCC.
However, we
were getting no output from the SCC on TxD at all. We tried changing the
SCC initialization code many times. ( It took ages at 20 minutes a pop. )
Still no luck.
.P
Testing for the SCC clock, we found the crystal was not oscillating. Two
possible explanations were apparent: first that the SCC was incorrectly
programmed, or second that we needed capacitors around the crystal. The
first supposition was unlikely as we did so much reprogramming. We wired up the
capacitors, but still no result. We did further reprogramming all to no avail.
.P
We tried using E-clock as the SCC clock but this did not help. We tried
loop back mode with both types of clock, but nothing helpful was revealed.
.P
We have been at this stage since Wednesday 13th of May. No further ideas as to
what is wrong have occurred to us. The SCCs seem to work and the only
possibility seems to be that the bus is somehow incompatible.
.P
