.H 1 "INTRODUCTION"
.P
This is a joint report for the Computer Science Honours courses
.I "Computer Networks"
and
.I "Microprocessor Systems"
taught by Dr. Doan Hoang and Dr. Robert Kummerfield respectively at the
Basser Department of Computer Science at the University of Sydney in 1987.
.P
The project consists of building a microprocessor hardware board using a
Motorola MC6809 MPU (microprocessor unit).  The board links up to a
minicomputer host (either a PDP-11/84 or VAX-11/780) using a Sattelite
Coprocessor system developed by Dr. Kummerfield.
.P
The microprocessor board, with suitable hardware and software, implements
two functions:
.AL
.LI
A
.I "MIDI (Musical Instrument Digital Interface) data recorder & playback unit"
allowing MIDI connected musical instruments to be connected to the
host.  Information over the MIDI channel can be saved as files in the host
in Real Time.  The information stored can then be 'played' back in real
time over the MIDI channel back to the musical instruments.  In effect, the
board and the host as a system acts as the digital equivalent of a tape
recorder.  Music can be digitally recorded as MIDI data and subsequently
played back.
.LI
An
.I "SDLC (Synchronous Data Link Control) station"
allowing SDLC frames to be transmitted and received.  The board implements
an open-ended SDLC toolkit.  Basically, SDLC station implementations can be
constructed in a "do-it-yourself" manner using the hardware in the
microprocessor board and low-level functions implemented in the project.
.LE
.P
Project members for the MIDI recorder/playback unit are:
.BL
.LI
Michael Barr-David (hardware, overall project leader)
.LI
Fred Holmberg (hardware, miscellaneous)
.LI
Chris Tham (low level software, documentation)
.LI
Jarryl Wirth (MIDI software)
.LE
.P
Project members for the SDLC station are:
.BL
.LI
Jason Lo (documentation)
.LI
Chris Tham (hardware, overall project leader)
.LE
.P
In the MIDI project, we decided to perform separate tasks each towards the final
product. That is, we each worked separately rather than everyone working on
everything. Notwithstanding this, the group as a whole held a meeting to
discuss and design the hardware and software sections of the MIDI project.
The individual responsibilities were:
.AL i
.LI
Michael Barr-David
.AL a
.LI
Hardware design
.LI
Hardware construction
.LI
Debugging
.LI
Hardware description/documentation
.LE
.LI
Chris Tham
.AL a
.LI
Monitor modifications for the SCC
.LI
Interrupt and other low level device software
.LI
Hardware test-out software
.LI
Assisting Debugging
.LI
Project documentation especially MIDI description
.LE
.LI
Jarryl Wirth
.AL a
.LI
Software design
.LI
Software implementation for both  the real and test environment
.LI
Users' guide for MIDI to RS 232 interface
.LI
Software description/documentation
.LE
.LI
Fred Holmberg
.AL a
.LI
Assisting hardware construction
.LI
Assisting debugging
.LE
.LE
.P
