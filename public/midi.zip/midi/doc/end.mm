.HU "Appendix A: Circuit Schematic"
.HU "Appendix B: Board Layout"
.HU "Appendix C: Memory Map"
.HU "Appendix D: Parts Listing"
.HU "Appendix E: monitor.s listing"
.HU "Appendix F: MIDI Recorder listings"
.HU "Appendix G: Low Level Function listings"
.HU "Appendix H: MIDI 1.0 Specification"
.HU "Appendic I: HDLC: Data communication \*(EM High level data link control procedures \*(EM Elements of procedures"
.HU "Appendix J: Data Sheets"
.TC
.CS
