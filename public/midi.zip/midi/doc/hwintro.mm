.H 1 "HARDWARE DESCRIPTION"
.P 1
The hardware design of the microprocessor board uses a Motorola MC6809
Microprocessor Unit running at a clock speed of 1 MHz.  8K of ROM
(Read Only Memory) and 32K of RAM (Random Access Memory) provide ample
space for software development for a MIDI data recorder and SDLC station
toolkit.  Four serial communications channels are available from two Zilog
Z8530 SCC (Serial Communications Controller) chips, consisting of
two asynchronous channels for the use
of the terminal interface and connection to the host Sattellite Coprocessor
System, one serial asynchronous MIDI channel
and one synchronous SDLC channel employing
NRZI at 1953.125 baud.  Line drivers are provided for the asynchronous
channels in conformance with the RS-232 interface standard.  The MIDI
Channel is interfaced per MIDI 1.0 specification.
In addition, a Motorola MC6840 PTM (Programmable Timer Module) allows
timing of MIDI and SDLC commands, as well as providing output for an
inbuilt metronome.
