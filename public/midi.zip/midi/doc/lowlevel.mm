.H 1 "LOW LEVEL FUNCTIONS"
.P
Some low level routines to allow the SCC and PTM chips to be accessible in
a convenient and rational way from within C source files were implemented.
These functions allow the PTM timers and SCC channels to be programmed
using symbolic constants.  In addition, port based functions using the SCC
channels have been defined.  This gives a consistent port interface
that allows the Host, Terminal, MIDI and SDLC functions to be written in a
uniform manner.
.P
The following include files have been written to support the low level
routines and any routines that need to call upon the low level routines:
.VL 20
.LI config.h
machine / operating system / C compiler dependent configuration parameters.
Hardware addresses such as the end of available memory, base addresses of
the SCC and PTM chips as well as port / timer assignments are defined here.
In addition, various parameters to isolate portability problems are also
defined in this file.
.LI ports.h
describes the port level interface to the SCC channels.  Each SCC channel
and be considered as a port for input and output.  This file describes
parameters required by the port based functions as well as some useful
macros for controlling port configurations.
.LI scc.h
contains symbolic names for the registers and configurable parameters of
the Zilog Z8530 SCC (Serial Communications Controller) chip.
.LI ptm.h
contains symbolic names for the registers and configurable parameters of
the Motorola MC6840 PTM (Programmable Timer Module) chip.
.LE
.P
The actual low level routines are contained within the following files:
.VL 20
.LI nmi.c
sets the nmi vector jump address.  A program wishing to grab control of NMI
(Non Maskable Interrupt) processing should install the address of the NMI
handler into location pointed to by the variable
.I nmivec
of type
.I "int *" .
.LI ports.c
defines the port I/O functions
.I PORTget() ", " PORTput() ", and " PORTsetbaud() .
.LI ptm.c
defines the PTM timer related functions
.I PTMinit() ", " PTMwritelatch() ", and " PTMreadcounter() .
.LI sccio.c
defines some SCC programming tables (incomplete, see
.B monitor.s
for SCC initialization programs) as well as the function
.I SCCprogram() .
SCC programs for raw / cooked I/O as well as interrupt enable/disable are
in this file.
.LE
.P
In addition, there is an assembler stand alone file called
.B monitor.s .
This contains the source code to the 6809 monitor modified for the
MIDI/SDLC board.  This monitor is used for debugging the MIDI/SDLC software
but is also used as an interface to the Host Sattelite Software system.
.H 1 "LOW LEVEL FUNCTION DESCRIPTIONS"
.P
The following are low level functions that may be called from any C
function that wishes to communicate with either the SCC or PTM chip.
.H 2 "nmiset() (MACRO)"
.DS
.B Syntax:

#include "config.h"

void
nmiset(addr)
int	(*addr)();

extern int	(*nmivec)();

.B Description:
.DE
.P
Sets the NMI processing routine to the function pointed to by the variable
.I addr .
Initially, the NMI handler resides in the monitor, and the global variable
.I nmivec
points to the address of the monitor NMI handler.  If the address of
a user supplied NMI handling function is passed to
.I nmiset()
then future NMI exceptions will be routed by the monitor to the user
supplied address.
.H 2 "PORTdisableint() (MACRO)"
.DS
.B Syntax:

#include "config.h"
#include "ports.h"

void
PORTdisableint(port)
int	port;

.B Description:
.DE
.P
Disables interrupts on the SCC port specified.  The parameter to
.I SCCdisableint()
must be a valid SCC port, such as P_TERMINAL, P_HOST, P_MIDI, P_SDLC.  Note
that to disabling interrupts on any port still leaves the SCC chip on which
the port belongs to in interrupt enable mode.
.H 2 "PORTenableint() (MACRO)"
.DS
.B Syntax:

#include "config.h"
#include "ports.h"

void
PORTenableint(port)
int	port;

.B Description:
.DE
.P
Enables interrupts on the SCC port specified.  The parameter to
.I SCCenableint()
must be a valid SCC port, such as P_TERMINAL, P_HOST, P_MIDI, P_SDLC.  Note
that to enable interrupts on a particular port, both
.I SCCenableint()
and
.I PORTenableint()
macros have to be called, in order to enable interrupts on the SCC chip
specified as well as the port.
.H 2 "PORTget()"
.DS
.B Syntax:

#include "config.h"
#include "ports.h"

int
PORTget(port)
int	port;

.B Description:
.DE
.P
Receives one character from the port specified, which must be either
P_HOST, P_TERMINAL, P_MIDI or P_SDLC.  If a character is not available,
this function will do a busy loop until a character is actually available.
If this is not desirable, a test using PORTrxready() must be made before
calling this function.
.DS
E.g.
	...
	if (PORTrxready(P_TERMINAL))
		ch = PORTget(P_TERMINAL);
	...

will only receive a character from the terminal if one is available.
.DE
.H 2 "PORTput()"
.DS
.B Syntax:

#include "config.h"
#include "ports.h"

void
PORTput(port)
int	port;

.B Description:
.DE
.P
Transmits one character across the port specified, which must be either
P_HOST, P_TERMINAL, P_MIDI or P_SDLC.  If the port is still busy
transmitting the previous character,
this function will do a busy loop until the port becomes ready.
If this is not desirable, a test using PORTtxready() must be made before
calling this function.
.DS
E.g.
	...
	if (PORTtxready(P_TERMINAL))
		ch = PORTput(P_TERMINAL);
	...

will only transmit a character from the terminal if it is ready.
.DE
.H 2 "PORTrxready() (MACRO)"
.DS
.B Syntax:

#include "config.h"
#include "ports.h"

boolean
PORTrxready(port)
int	port;

.B Description:
.DE
.P
Tests whether port specified (P_TERMINAL, P_HOST, P_MIDI, and P_SDLC) has a
character ready to be received.  A nonzero value is returned if there is a
character ready, otherwise a zero value is returned.
.H 2 "PORTsetbaud()"
.DS
.B Syntax:

#include "config.h"
#include "ports.h"

void
PORTsetbaud(port, baudrate)
int	port, baudrate;

.B Description:
.DE
.P
Initializes the port specified (P_TERMINAL or P_HOST) to the baud rate
specified.  The baud rate given must be a multiple of 100.
.DS
E.g.

	...
	PORTsetbaud(P_TERMINAL, 4800);
	...

will set the terminal to 4800 baud communications.
.DE
.H 2 "PORTsetcooked() (MACRO)"
.DS
.B Syntax:

#include "config.h"
#include "ports.h"

void
PORTsetcooked(port)
int	port;

.B Description:
.DE
.P
Sets the port specified to cooked (7 bits per character, 1 stop bit per
character, even parity mode).  The parameter to this function must be either
P_HOST or P_TERMINAL.  Cooked mode is generally preferable for human
oriented I/O.
.H 2 "PORTsetraw() (MACRO)"
.DS
.B Syntax:

#include "config.h"
#include "ports.h"

void
PORTsetraw(port)
int	port;

.B Description:
.DE
.P
Sets the port specified to raw (8 bits per character, 1 stop bit per
character, no parity mode).  The parameter to this function must be either
P_HOST or P_TERMINAL.  Raw mode is necessary for 8 bit character I/O.
.H 2 "PORTtxready() (MACRO)"
.DS
.B Syntax:

#include "config.h"
#include "ports.h"

boolean
PORTtxready(port)
int	port;

.B Description:
.DE
.P
Tests whether port specified (P_TERMINAL, P_HOST, P_MIDI, and P_SDLC) has
an empty transmit buffer.  An empty transmit buffers means the port is
ready to send a character out.
A nonzero value is returned if the transmit buffer is empty,
otherwise a zero value is returned.
.H 2 "PTMinit()"
.DS
.B Syntax:

#include "config.h"
#include "ptm.h"

void
PTMinit()

.B Description:
.DE
.P
Initializes and starts the three PTM timers into operation.  Timer L_TIMER has
interrupts enabled and will interrupt the main CPU using the NMI line
whenever the counter reaches zero.  Timers L_TONE and L_DURATION have
their outputs directed to a speaker and are used to generate metronome
tones.  This function initializes timers L_TIMER and L_TONE to continuous
and L_DURATION to one shot.  L_TIMER is used for timing incoming and
outgoing MIDI data.  L_TONE provides the frequency of the metronome beep.
L_DURATION gives the duration of a metronome beep.   Before calling this
function, the PTM latches should have been previously written to using the
.I PTMwritelatch()
function.  Once initialized, the timers start operating and L_TIMER will
periodically interrupt the CPU.  A write to the L_DURATION latch using
.I PTMwritelatch()
will cause the metronome to sound for the duration specified on the
frequency specified by L_TONE.
.H 2 "PTMreadcounter()"
.DS
.B Syntax:

#include "config.h"
#include "ptm.h"

int
PTMreadcounter(timer)
int	timer;

.B Description:
.DE
.P
Reads the currrent counter value for the timer specified, which must be
L_TIMER, L_TONE, or L_DURATION.
.H 2 "PTMwritelatch()"
.DS
.B Syntax:

#include "config.h"
#include "ptm.h"

void
PTMwritelatch(timer, value)
int	timer, value;

.B Description:
.DE
.P
Initialize the counter latch values for the timer specified, which must be
either L_TIMER, L_TONE or L_DURATION.  The value must be a 16 bit value
that the timer will count down to.  The rate of countdown depends on the
CPU clock speed, which on this board is 1 MHz.
After calling the function
.I PTMinit()
the three timers will start counting down from the latch values specified.
L_TIMER and L_TONE counts down continuously (once zero is reached, the
counter is reloaded from the latch) whereas the L_DURATION is a one shot
timer.  A
.I PTMwritelatch()
to L_DURATION will restart the timer.
.H 2 "SCCdisableint() (MACRO)"
.DS
.B Syntax:

#include "config.h"
#include "ports.h"

void
SCCdisableint(scc)
int	scc;

.B Description:
.DE
.P
Disables interrupts on the SCC chip specified.  The parameter to
.I SCCdisableint()
must be either SCC0 or SCC1.
.H 2 "SCCenableint() (MACRO)"
.DS
.B Syntax:

#include "config.h"
#include "ports.h"

void
SCCenableint(scc)
int	scc;

.B Description:
.DE
.P
Enables interrupts on the SCC chip specified.  The parameter to
.I SCCenableint()
must be either SCC0 or SCC1.
.H 2 "SCCprogram()"
.DS
.B Syntax:

#include "config.h"
#include "scc.h"

void
SCCprogram(port, str)
int	port;
char	*str;

.B Description:
.DE
.P
Programs the SCC port specified with a valid SCC programming string.
A valid SCC programming string is simply a character array with the
following structure:
.DS
.I "" "char	program[" COUNT+2 "] ="
	{
.I "" "		" COUNT ,
.I "" "		" REGISTER ", " VALUE "[, ]"
		...
	};
.DE
where COUNT is the number of REGISTER and VALUE bytes to be programmed.
A REGISTER and VALUE pair is simply an SCC register value followed by the
actual value to be programmed into the register specified.  Combinations of
SCC constants may be specified.
.P
For example, to program register 3 with the following attributes:
.DS
	Receive 7 bits per character,
	Receive enable
.DE
and register 5 with the following attributes:
.DS
	Transmit 8 bits per character,
	Transmit enable,
	DTR active,
	RTS active
.DE
The following string could be used:
.DS
char	hi_mom[6] =
	{
		4,
		3, W_RX7BITS | W_RXEN
		5, W_DTR | W_TX8BIT | W_TXEN | W_RTS
	};
.DE
