.nr B 3
.nr S 12
.nr N 2
.SA 1  \"  right justified
.TL "Computer Science Honours" "Microprocessor Systems, Computer Networks"
MIDI (Musical Instrument Digital Interface) &
SDLC (Synchronous Data Link Control)
Hardware Board
Project Report
.AF "University of Sydney"
.ds Ba "Basser Department of Computer Science
.AU "Michael Barr-David" MBD Ba
.AU "Fred Holmberg" FH Ba
.AU "Jason Lo" JL Ba
.AU "Chris Tham" CT Ba
.AU "Jarryl Wirth" JW Ba
.AT "CS Honours 1987"
.AS   \" abstract start for TM 
This document decribes the hardware and software of a 6809 based
microprocessor board that implements the dual functions of a MIDI data recorder
and SDLC station toolkit.  It fulfils the requirements of Project Report for
the following courses: Computer Networks and Microprocessor Systems.
.sp 2
Date Printed: \*(DT
.AE   \" abstract end
.MT 4  \"  memo type
.nr Ej 1
.nr Cl 3
.nr Hu 1
