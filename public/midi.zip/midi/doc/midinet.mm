.H 1 "MIDI NETWORK ARCHITECTURE"
.P
The basic idea behind MIDI is a two-layer network consisting of a physical
interconnection scheme and a code to communicate information across the
channel.
.H 2 "The Physical Interconnection"
.P
The physical layer of MIDI is a simple point-to-point opto-isolated 5 mA
current loop using a 5-pin DIN connector in which three of the pins are
used.  The cable is made of a shielded twisted pair with the shield being
grounded at the source end only.  Each twisted pair implements a
one-direction transmission line.  Hence two cables are needed to implement
a two-way communication path between MIDI stations.  An instrument
implementing the interface must have a MIDI input and output jacks, to be
labelled MIDI IN and MIDI out.  A MIDI THRU jack may also be provided,
which simply provides a buffered electrical copy of the input signal.
Information is transmitted across as asynchronous serial data at a baud
rate of 31250 baud with 1 start bit, 8 data bits and 1 stop bit.
.P
Some interconnection schemes for interconnection of musical instruments:
.VL 20
.LI Unidirectional
master talks to slave
.LI Bidirectional
two masters drive each other as slaves
.LI Ring
an extension of bidirectional connection to three or more devices
.LI "Daisy Chain"
one master drives several slaves using MIDI THRU
.LI Star
one master has several unidirectional or bidirectional links.
.LE
.P
Note that a single MIDI cable is a unidirectional single-talker /
single-listener network.  Using a MIDI THRU connection allows it to become
a multilistener network.
.H 2 "The Code Specification"
.P
The code specification consists of three elements:
.I modes ", " channels ", and " commands .
.H 3 "MIDI modes and channels"
There are three modes and sixteen channels, which provide for
multisynthesizer control within a single MIDI network.  The modes establish
the relationship between the channels and voice assignment methods within a
synthesizer.  MIDI commands with a field for channel number are called
.I "channel commands" .
The MIDI mode configures synthesizers to receive or ignore channel commands
depending on the channel number.  The three modes are
.VL 10
.LI Omni
causes a MIDI unit to accept commands on all channels
.LI Poly
causes a synthesizer to assign voices polyphonically, i.e. sequential MIDI
commands to turn notes on will generate a chord.
.LI Mono
configures the synthesizer to respond to only one voice per channel.
However, the synthesizer may receive on more than one channel, so
sequential note on commands on different channels may still generate a
chord in the synthesizer.
.LE
.P
The modes may be grouped into four states:
.AL
.LI
.I "Omni On" " and " Poly
allows all commands regardless of channel to be recognized by the receiver
and voices are assigned polyphonically.
.LI
.I "Omni On" " and " Mono
allows all commands regardless of channel to be recognized by the receiver
and assigned to just one voice.  Only one voice may sound.
.LI
.I "Omni Off" " and " Poly
allows only channel commands matching the receiver channel number to be
recognized and voices are assigned polyphonically.
.LI
.I "Omni Off" " and " Mono
allows only channel commands matching a range of receiver channel numbers
(possibly one) to be
recognized and voices are assigned one per channel recognized.
.LE
.H 2 "MIDI Command Types"
There are five categories of MIDI commands:
.VL 20
.LI Channel
communicates event data such as
.I "note on" " and " "note off"
and status of device controllers such as pitch-bend and breath controllers
as well as continuous modulation controls.
.LI "System common"
deals with sequence selection and positioning within a sequence.  These
commands are useful for instruments recording MIDI data (i.e. a MIDI data
recorder).
.LI "System realtime"
synchronizes a network of MIDI devices to a common clock.
.LI "Reset"
terminates activity in progress and reinitializes devices to power on
condition.
.LI "System exclusive"
is manufacturer dependent commands for sending device-specific information such
as voice parameters.
.LE
.P
System realtime commands have the highest priority (can interrupt multibyte
commands) followed by System exclusive. All other commands have equal
priority.
.H 2 "Format of MIDI commands"
.P
A typical MIDI command byte is as follows:
.DS

	Status byte
	10010010
	1XXXYYYY

	1	Leading Sentinel bit
	XXX	Command ID
	YYYY	Channel ID

.FG "MIDI Status Byte Format"
.DE
.P
The sentinel signals the start of a new command (status byte).  Data bytes
must have this bit reset.
The Command ID identifies the MIDI command.  If the command ID identifies
the command to be a
.I "channel command"
then the Channel field contains the channel number of the command,
otherwise the channel field is used as an extension of the command field.
.P
Each command type contains a specified number of trailing data bytes.  The
only exception is System exclusive, which may contain an unspecified number
of trailing 7 bit data bytes terminated by an EOX (End of Exclusive)
command.  Some commands have no trailing data bytes at all.
.P
If a subsequent command have a status byte identical to the command prior
to it, then the status byte need not be sent and will be assumed by the
receiver.  This feature is called
.I "MIDI running status"
and reduces the amount of information that has to be passed through the
MIDI interface.
.DF
.TS
center expand;
l l l l.
_
Status	Arg 1	Arg 2	Mnemonic
_
8X	Key	Velocity	Key off
9X	Key	Velocity	Key on
AX	Key	Pressure	Polyphonic Key Pressure
BX	Index	Value	Control Change
CX	Index	\_	Program Change
DX	Pressure	\_	Pressure (combined)
EX	LSB	MSB	Pitch Wheel change
.TE

.TB "CHANNEL COMMANDS"
.DE
.DF
.TS
center expand;
l l l l.
_
Status	Arg 1	Arg 2	Mnemonic
_
F0	Mfg. ID	...	System Exclusive Command
.TE

.TB "SYSTEM EXCLUSIVE COMMAND"
.DE
.DF
.TS
center expand;
l l l l.
_
Status	Arg 1	Arg 2	Mnemonic
_
F2	LSB	MSB	Program Position Select
F3	Index	\_	Program Select
F6	\_	\_	Tune request
F7	\_	\_	End of System Exclusive (EOX)
.TE

.TB "SYSTEM COMMON COMMANDS"
.DE
.DF
.TS
center expand;
l l l l.
_
Status	Arg 1	Arg 2	Mnemonic
_
F8	\_	\_	Timing Clock
F9	\_	\_	Undefined
FA	\_	\_	Start
FB	\_	\_	Continue
FC	\_	\_	Stop
FD	\_	\_	Undefined
FE	\_	\_	Active sensing
FF	\_	\_	System reset
.TE

.TB "REAL TIME COMMANDS"
.DE
