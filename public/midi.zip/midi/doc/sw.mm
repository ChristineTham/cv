.H 1 "MIDI SOFTWARE DESCRIPTION "
.H 2 "Design Considerations"
.P
The MIDI interface is a "real-time" device. It must continually, and
simultaneously, service three distinct I/O ports: MIDI, host and terminal.
The MIDI port receives musical information, in standard MIDI format, which
must be processed as soon as it arrives, and must transmit MIDI data at
specific timed intervals. At the same time, the interface must communicate
with the user via the terminal port, in order for commands to be recieved,
and error messages and other information to be sent. Finally, the interface
must manage I/O with the host computer, which is primarily used for the
storage and retrieval of MIDI files.
.P
As mentioned, all of this must occur simultaneously, in real-time. It was
therefore decided to create a software design for the interface which
consists, conceptually, of seven "parallel" processes: midi_in, midi_out,
terminal_in, terminal_out, host_in, host_out and a "timer" process.
This design is implemented by seven main functions corresponding to these
processes. Each I/O function is entirely responsible for the processing
of data at its associated port (in the appropriate direction), and is called
by the main program when data arrives or needs to be sent. The timer
process is responsible for the control of the timer chip on the board, and
as such, provides the timing services required by midi_in and midi_out.
The only other functions in the program are simple support routines for these
seven functions.
.H 2 "Control Structures"
.P
As described, the interface is essentially "event-driven". This would 
perhaps suggest the use of interupts to control the various processes.
However, as there are many processes, and limited interupt priority
facilities avaliable, it would be necessary to poll all the ports at each
interupt. Furthermore, due to modularity of the above design, there is
actually nothing left for the "main loop" to do. Thus, for simplicity's
sake, it was decided to dispense with interupts for the I/O processes
and have a main program which simply consists of an "infinite" polling
loop. Provided the processing time for data is small compared to its I/O
time (as is the case), there is no danger of "losing" any bytes with this
approach. However, care must be taken to ensure that no process does any
"busy-waiting" for data, and only processes what data is immediately
available, before passing control back to the main loop. The timer
process must, of course, remain interupt-driven.
.P
The most important (and most difficult) task of the interface is to add
timing information to MIDI data. Without this requirement, the interface
would simply be a filter for passing data between MIDI devices and the host
- a kind of "intelligent buffer". MIDI data consists of small packets of
bytes called "MIDI messages" (see Section "Description of MIDI").
This data describes the
important characteristics of the notes in a musical piece, but contains no
timing information, i.e. does not say where a note appears in a bar, nor
how long it should last. This information has to be added by the interface.
It does this by preceding each MIDI message with a "time-stamp" as it arrives
at the midi_in port, before passing it on to the host. Data coming from the
host must consist of a time-stamp followed by a valid MIDI message. The
interface then dispatches the MIDI message to the midi_out port at the
time indicated by the time-stamp.  A MIDI message plus its leading
time-stamp is refered to as a "MIDI event". Thus the principal function
of the interface may be described as the conversion of MIDI messages
into MIDI events, and of MIDI events into MIDI messages.
.H 2 "Coding Details"
.P
The functions midi_in and midi_out are contained in the file "midi.c".
The functions term_in and term_out are contained in the file "term.c".
Not surprisingly, the functions host_in and host_out are contained in
the file "host.c". The details of the operation of these functions may be
found in the corresponding source files. The main program is, of course,
in this file, "main.c". The passing of data between modules is done
through shared buffers which operate as FIFO queues. These are controlled
by functions and macros contained in the source file "queue.c", and are
described there. The timer interupt-handling routine "ptm_int" and
associted timer functions are in the file "timer.c". Finally, low level
I/O and ptm chip functions are to be found in the files "ports.c", "sccio.c",
"ptm.c" and "nmi.c".
.P
The basic operation of the software is as follows: Timing of MIDI messages
is achieved via the use of two counters controlled by the ptm interupt
routine. They are the "record counter" and the "playback counter", and
they are incremented and decremented respectively at each timer interupt.
The duration between timer interupts is set as a function of the current
"tempo" and "grain" of the interface (see "User's Guide"). As bytes
of MIDI data arrive at the midi_in port, they are collated in a small local 
buffer. When a complete MIDI message has been recieved, a time-stamp is
obtained by reading the record counter. The entire MIDI event is then
placed in the midi-to-host queue, to be later removed by the host_out
process and sent to the host at a convenient time. When the record counter
overflows between MIDI events, a special "timer overflow" byte is inserted
into the queue. Also, whenever the record counter is read, it is automatically
cleared. Thus, each time-stamp is relative to the last.
.P
On playback, MIDI
events are loaded from the host into the host-to-midi queue. Each time-stamp
is collected in turn from the queue by the midi_out routine and placed
in the playback counter. An "alarm" is then set to send the following
MIDI message when the playback counter zeroes out. (This alarm function
is controlled by the timer routine.) While waiting for the alarm, the
MIDI message is placed in a local buffer, ready to be sent. When an
overflow byte is seen, the overflow time-value is placed in the playback
counter, no MIDI message is brought from the queue, and, on zero-out, the
next time-stamp or overflow is fetched. Note also one special case:
time-stamps of 0 are not placed in the playback counter - the corresponding
MIDI message is simply sent straight through.
.P
There is one other minor
detail: MIDI real-time messages (see Section "Description of MIDI")
are generated by the ptm
interupt routine for the purposes of synchronizing the interface with
other units. These are placed in a special real-time queue, which is
also emptied by the midi_out process.
(Bytes in the real-time queue have output priority over other MIDI bytes
in the host-to-midi queue.)
.P
Control of these operations is maintained via a simple command
interpreter implemented by the term_in module. (For details of commands
see the "User's Guide".) When the command interpreter needs to
communicate with the user, it places the bytes of the message in the
terminal queue, which are later sent out by the term_out module.
.P
(N.B. The reason for all these queues is to fulfill the design
goal of not doing any busy-waiting in the processing functions.)
.P
For further implementation details read the source documentation.
