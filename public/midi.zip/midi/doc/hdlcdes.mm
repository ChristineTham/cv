.H 1 "DESCRIPTION OF THE HDLC DATA LINK PROTOCOL"
.P
This summary of the HDLC protocol is taken from the document
.B
"Data communication \*(EM High Level data link control procedures \*(EM
Elements of procedures"
.R
ISO Standard ISO 4335 First Edition 1979-04-15 published by the International
Organization for Standardization (ISO).  ISO 4335 was developed by the ISO
Technical Committee ISO/TC 97 (Computers and Information Processing).
.H 2 "Introduction"
.P
The HDLC protocol is a superset of IBM SDLC protocol designed for
synchronous bit oriented data transmission between independent data
stations.  Information to be transmitted from a data source to a data sink
is divided into
.I frames .
Each frame is transmitted in turn by the data source and must be
acknowledged by a frame going in the opposite direction.  Until the
acknowledgment frame from the data sink is received, the data source must
hold the frame in buffer for possible future retransmissions.
.P
A
.I "data link"
is a connection between two or more stations.  One station on the link
controls the data flow and error recovery and is known as the
.I "primary station" .
The primary station transmits
.I "command frames" .
All other stations are designated
.I "secondary stations"
and transmit
.I "response frames" .
.P
There are two cases of data link control considered:
.AL
.LI
The primary may act as the data source by transmitting select-type commands.
.LI
The primary may act as the data sink by sending poll-type commands.
.LE
.P
The two cases may be combined to allow two-way alternate or two-way
simultaneous communication.
.P
For the purposes of acknowledgment synchronization and sliding window
protocol control, data frames are transmitted and acknowledged using
.I "sequence numbers" .
.H 2 "Operational Modes"
.P
There are two operational modes are defined for secondary stations;
normal response mode (NRM) and asynchronous response mode (ARM). NRM is an
operational mode in which the secondary may initiate transmission only as the
result of receiving explicit permission to do so from the primary. ARM is an
operational mode in which the secondary may initiate transmission without 
receiving explicit permission from the primary. Such an asynchronous 
transmission may contain single or multiple frames and is used for information
field transfer and/or indicate status changes in yhe secondary.
.H 3 "Control Fields"
.P
There are three control field formats : information transfer format
(I-format), supervisory format (S-format) and Unnumbered format (U-format).
.P
The I-format is used to perform an information transfer. Bit "0" of
the I-frame is always a 0; the next three bits is the transmitting send
sequence number (N(S) = 000 through 111); the next bit is P/F (Poll bit : 
primary transmissions, Final bit : secondary transmissions), which is the same
for the other two formats; the last three bits is the transmitting receive
sequence number (N(R) = 000 through 111).
.P
The S-format is used to perform link supervisory control function such
as acknowlege I-frames, request retransmission of I-frames, and to request a
temporary suspension of transmission of I-frames. Bits "0" and "1" of the 
S-frame are always a 1 and a 0; the next two bits is the supervisory function
bits (S = 00 through 11); the last three bits is N(R) and is the same as in
the I-frame.
.P
The U-format is used to provide additional link control functions, and
this format contains no sequence number. Bits "0" and "1" of the U-frame are
always a 1 and a 1; the next two bits and the last three bits is the modifier
function bits (M). 
.H 3 "Parameters"
.P
There are various parameters associated with the control field formats,
and are describing in the following sub-clauses.
.H 4 "Modulus:"
Each I-frame is sequentially numbered and may have value 0
through MODULUS minus ONE (where MODULUS is the modulus of the sequence number).
.H 4 "Frame variables and sequence numbers:"
In HDLC operation, each data 
station maintains an independent send sequence number N(S) and receive sequence
number N(R) on the I-frame it sends and receives.
.H 4 "Send state variables V(S):"
V(S) denotes the sequence number of the
next in sequence I-frame to be transmitted and may have value 0 through MODULUS
minus ONE (where MODULUS is the modulus of the sequence numbering scheme and
the number cycle through the entire range).
.H 4 "Send sequence number N(S):"
Only I-frames contain N(S), the send
sequence number of the transmitted frames. Prior to transmission of an 
in-sequence I-frame, N(S) is updated to equals to V(S).
.H 4 "Receive state variables V(R):"
V(R) denotes the sequence number of the
next in-sequence I-frame to be received.
.H 4 "Poll/Final bit (P/F):"
The poll bit is used by primary to solicit (poll)
a response or sequence of responses from secondaries. The final bit is used by
a secondary in two cases; in NRM to indicate the final frame transmitted as the
result of a previous soliciting (poll) command; in ARM to indicate the response
frame transmitted as the result of a soliciting (poll) command.
.H 3 "Data link channel states"
.P
The data link channel states are classified as active channel state and
idle channel state. Active channel state is when a channel is in an ACTIVE
condition; in this state, aborting a frame is accomplished by transmitting at
least seven contigous one bits (with non-inserted zeroes).  Idle channel
state is when a channel is in an IDLE condition.  Interframe time fill
is accomplished by transmitting continuous flags between frames.
.H 3 "Functions of the Poll/Final (P/F) bit"
.P
The P/F bit serves a function in both command frames and response
frames. In command frames, the P/F bit is refered to as P bit. In response
frames it is refered to as the F bit.
.P
In NRM, the P bit is set to "1" to solicit response frames from the
secondary. In ARM, I-frames can be transmitted by the secondary on an
asynchronous basis; the P bit zero set to "1" is used to solicit response, at
the eariest opportunity, with the F bit set to "1".
.P
In NRM, the secondary must set F bit to "1" in the last frame of its
response. In ARM, the secondary will transmit a response frame with the F bit
set to "1" only in response to a received command frame with the P bit set to
"1".
.P
The P/F bit can also be used to assist in error recovery by a capability
known as
.I "check-pointing" .
In check-pointing, the primary sends a P bit set to a 1.  Error recovery
will be initiated if the receiver does not acknowledge at least all
I-frames up to sequence number of frame with the P bit set.
.H 3 "Commands and responses"
.P
The set of commands and responses for each of the control field formats
are listed below. (assume that left bit is low and right bit is high)
.DS

Supervisory format commands (when P/F is poll) :
	RR - Receive Ready (when S = 00).
	RNR - Receive Not Ready (when S = 01).
	REJ - Reject (when S = 10).
	SREJ - Selective Reject (when S = 11).

Unnumbered format commands :
	SNRM - Set Normal Response Mode (1111P000).
	SARM - Set Asynchronous Response Mode (1100P001).
	DISC - Disconnect (1100P010).
	SNRME - Set Normal Response Mode Extended (1111P010).
	SARME - Set Asynchronous Response Mode Extended (1111P011).

Supervisory format responses (when P/F bit is final) :
	RR - Receive Ready (when S = 00).
	RNR - Receive Not Ready (when S = 01).
	REJ - Reject (when S = 10).
	SREJ - Selective Reject (when S = 11).

Unnumbered format responses :
	UA - Unnumbered Acknowledge (1100F110).
	CMDR - Command Reject (1110F001).

.FG "HDLC Commands and Responses"
.DE
