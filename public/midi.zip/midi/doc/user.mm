.ds MI \fIMIDI-in\fP 
.ds MO \fIMIDI-out\fP 
.ds MT \fIMIDI-thru\fP 
.H 1 "USER'S GUIDE TO THE MIDI INTERFACE"
.H 2 "Introduction"
.P
The interface may be viewed as a kind of digital "tape recorder"
for MIDI data.
Thus, it can be used to "record" and "playback" musical information
produced by any standard MIDI instrument.
.P
However, it is more than this.
.P
Firstly, it should be noted that the information recorded by the interface
describes the length, duration and important
characteristics of the \fInotes\fP of a piece, not the actual musical
sounds.
Thus, for example,
a recorded piece need not be played back on
the same instrument, or with the same sound, as it was recorded with.
.P
Secondly, it is possible to set such parameters as musical tempo,
and, say, set the tempo on playback to a different value than that it was recorded at
(without, of course, the resultant pitch variation of a real tape recorder).
.P
Thirdly, as the recorded information is stored on the host computer, the data can
be manipulated by any MIDI application program,
combined with other MIDI data, and so on and so forth.
Indeed, the data can actually \fIoriginate\fP from a computer program
(such as a "sequencer"),
rather than be recorded from an instrument.
The music thus created or changed can then be played back in the usual way,
provided, of course, it is in the format expected by the interface.
(For instance, such a program would be a compiler for Chris Tham's
RUBATO musical description language,
which he is developing as his honours project.
With an appropriate back end, the compiler could translate musical pieces
of arbitrary complexity specified in this language
into MIDI data files which could control, via the interface,
any number of MIDI instruments.)
.P
Finally, the interface can
synchronize its operation with that of other MIDI units, such as
other interfaces, drum machines etc.
In this way, the interface can be used as a "master" synchronization unit
in a network of MIDI units, not only playing its own MIDI data, but,
at the same time, also causing the other units to play in time with it,
at the same tempo.
.H 2 "Set up"
The interface has the usual MIDI connections:
.BL
.LI
\*(MI For recording, connect the \*(MO socket of any
MIDI instrumnent to the \*(MI socket of the interface.
.LI
\*(MO For playing, connect the \*(MO socket of
the interface to the \*(MI socket of any MIDI instrument.
For synchronization, also connect \*(MO on the interface to
\*(MI on the other unit.
If more than one instrument or unit is to recieve data from the interface
they may be daisy-chained together using their \*(MT sockets.
.LI
\*(MT A \*(MT socket on any MIDI device simply echoes the data it sees at
\*(MI.
Thus, to pass on data being recieved at the interface \*(MI to another device,
simply connect \*(MT on the interface to \*(MI on that device. 
.LE
.H 2 "Command and Control"
.P
The interface is  controlled by typing commands on the terminal connected to it.
When the machine is switched on, the prompt appears on the terminal:
.DS
	>
.DE
.P
This means the interface is ready to recieve commands.
The syntax of commands is as follows:
.DS
	r [<song>]		("record")
	p [<song>]		("play")
	c			("continue")
	s			("stop")
	t [<number>]		("tempo")
	g [<number>]		("grain")
	q			("quit")
.DE
The items in square brackets are optional, and there presence or absence
causes different results.
.P
A song is simply a file of MIDI data with timing information.
The name of a song is the name of the corresponding file in the operating
system of the host.
The command "r <song>" causes any subsequent data arriving at \*(MI to
be timed and stored in the file <song>.
The command "p <song>" causes the MIDI data contained in the file <song>
to be sent to \*(MO at intervals specified by the accompanying timing data.
In both cases, if the file is omitted, then the most recent file-name specified
by an 'r' or 'p' command is used.
is used.
(Of course, the first time one of these is used after
switch-on, a file-name is mandatory.)
.P
The stop command "s" is used to stop either recording or playback.
A song may be stopped at any time.
After stopping during playback, a subsequent "p" command will play
the song again from the beginning.
The continue command "c", on the other hand, will play the song from
where it was stopped.
.P
The command "t <number>" sets the tempo of the interface at <number>,
in beats per minute (bpm).
Note that this is the tempo of the \fIinterface\fP, not the song.
Thus, to play a song back at the same speed it was recorded at,
the interface must be set to the same tempo that it was set to when
the song was recorded.
The command "t" will display the current tempo setting.
The tempo is set to a default value of 120 bpm at switch-on.
.P
The "grain" of the interface is the fineness to which incoming MIDI data is
timed.
To be precise, if grain is set to \fIn\fP, then the data is timed to the nearest
\fIn\fPth. of a beat.
The command "g <number>" sets grain to <number>, and the command "g"
displays the current value.
It is initially set to a default value of 24.
.P
The quit command "q" does the obvious.
