.H 1 "DESCRIPTION OF THE ZILOG Z8530 SCC"
.H 2 "Functional description of the SCC"
.P
The SCC supports several modes of communications:
.BL
.LI
Asynchronous
.LI
Synchronous (both byte-oriented and bit-oriented)
.LI
SDLC (Synchronous Data Link Control)
.LI
SDLC Loop mode
.LI
HDLC (High Level Data Link Control)
.LE
.P
Any of the above modes can be put into
Local Loopback
or
Auto Echo
for testing purposes.
.H 2 "SDLC mode"
.P
The SCC supports SDLC by performing automatic flag sending, zero insertion,
and CRC generation. In this mode, SDLC polynomial is used, the generator and
checker may be preset to all 1s or all 0s.
.P
In SDLC mode, one to eight bits per character can be sent, allowing reception
of a message with no prior information about the character structure in the
information field of a frame.
.P
To transmit a message, character assembling process is carried out by the 
transmitter. A special cammand can be used to abort a frame in transmission.
At the end of message, the SCC automatically transmits the CRC and trailing
flag when the transmitter underruns. If a transmit underrun occurs in the middle
of a message, an External/Status interrupt warns the CPU of this status change
so that an abort may be used.
.P
On the receiver side, the receiver automatically acquires synchronization on
the leading flag of a frame and provides a synchronization on the SYNC pin.
The receiver can be programmed to search for frames addressed by a single
byte (or 4 bits within a byte) of a user-selected or a grobal broadcast
address, if not matching, either the user-selected or broadcast address are
ignored.
.P
For receiving data, an interrupt on the first character, or on every 
character,
or on special condition only (end-of-frame) can be selected. The receiver
automatically deletes all 0s inserted by the transmitter during the character
assembly. The CRC is also calculated and is automatically checked to validate
frame transmission. At the end of transmission, the status of a received frame 
is available in the status registers.
.H 2 "SDLC Loop mode"
.P
The SCC supports SDLC Loop mode in addition to normal SDLC. In this 
mode, there is a primary controller station that manages the message traffic 
flow on the loop and any number of secondary stations.
.P
A secondary station is always listening to the messages being send 
around the loop, and in fact must pass the messages to the rest of the loop by
retransmitting them with a one-bit-time delay. The secondary station can
transmit its message only at specific times. The controller signals that
secondary stations may transmit messages by sending a special character,
called an EOP (End Of Poll), around the loop. The EOP character is a unique
bit pattern 11111110.
.P
When a secondary station has a message to transmit and recognizes an EOP on the
line, it changes the last binary 1 of the EOP to a 0 before transimission (this
has the effect of turning the EOP into a flag sequence). The secondary station
now places its message on the loop and terminates the message with an EOP. Any
secondary staions further down the loop with messages to transmit can then
append the messages to the message of the first secondary station by the same
process. Any secondary stations without messages to send merely echo the 
incoming messages and prohibited to place messages on the loop (except recognizing an EOP).
.H 2 "SCC interrupts"
.P
There are three types of interrupts in the SCC:
.BL
.LI
Transmit
.LI
Receive
.LI
External/Status
.LE
.P
Each interrupt type is enabled under program control with
channel A having higher priority than channel B, and with Receive, Transmit
and External/Status interrupts prioritized in that order with each channel.
.P
When Transmit interrupt is enabled, the CPU is interrupted when the transmit
buffer becomes empty. The receiver then can interrupt the CPU in one of three
ways:
.AL
.LI
Interrupt on First Receive character or Special Receive Condition.
.LI
Interrupt on All Receive character or Special Receive Condition.
.LI
Interrupt on Special Receive Condition Only.
.LE
.P
.I "Interrupt on First Receive character"
and
.I "Interrupt on Special Receive Condition Only"
are typically used with Block Transfer mode. A Special 
Receive Condition is one of the following:
.BL
.LI
receive overrun
.LI
framing error (in Asynchronous mode)
.LI
end-of-frame (in SDLC mode)
.LI
parity error (optionally).
.LE
An interrupt can occur from Special Receive Condition any time after the First
Receive character interrupt.
.P
External/Status interrupt is to monitor the signal transitions of the CTS, DCD
and SYNC pin; It is also caused by a Transmit Underrun condition, or a zero
count in the baud rate generator, or by the detection of a Break (Asynchronous
mode), or Abort (SDLC mode), or EOP (SDLC Loop mode).
.P
When the SCC responds to an Interrupt Acknowledge signal (INTACK) from the CPU,
an interrupt vector is placed on the data bus. This vector is written in WR2
and may be read in RR2A or RR2B.
.P
Three bits in this vector can be modified to indicate status, so can speed
interrupt response time as if the vector is read in channel A , status is never
included; if it is read in channel B, status is always included.
.P
Two bits are related to the interrupt priority chain. As a microprocessor
peripheral, the SCC may request an interrupt only when no higher priority
device is requesting one, e.g. when IEI is high.
.P
Each of the six sources of interrupts in SCC (Transmit, Receive and 
External/Status in both channels) has the other three bits associated with the
interrupt sources : Interrupt Pending (IP), Interrupt Under Service (IUS) and 
Interrupt Enable (IE).
.P
The IE bit is set for a given interrupt source, indicates that source can
request interrupts except when MIE (Master Interrupt Enable) bit in WR9 is
reset and no interrupts may be requested, the IE bits are write only.
.P
The IP bit signals a need for interrupt servicing, when an IP bit is 1 and the
IEI input is high, the INT output is pulled low, requesting an interrupt. If
the IE bit is not set by enabling interrupts, then the IP for that source can
never be set. The IP bits are readable in RR3A.
.P
The IUS bit signals that an interrupt request is being serviced. If an
IUS is set, all interrupt sources of lower priority in the SCC and external to
the SCC are prevented from requesting interrupts.
.H 2 "Architecture of the SCC"
.P
The SCC internal structure includes two full-duplex channels, two baud rate
generators, internal control and interrupt logic, and a bus interface to a
nonmultiplexed bus. Associated with each channel are a number of read and
write registers for mode control and status information, as well as logic
necessary to interface to modems or other external devices.
.P
The logic for both channels provides formats, synchronization, and validation
for data transferred to and from the channel interface. The modem control
inputs are monitored by the control logic under program control.
.P
The register set for each channel includes ten control (write) registers, and
four states (read) registers. In addition, each baud rate generator has two
(read/write) registers for holding the time constant that determines the baud
rate. Associated with the interrupt logic is a write register for the 
interrupt vector accessible through either channels, a write only Master
Interrupt Control register and three read registers : one containing the 
vector with status information (channel B only), one containing the vector
without status (channel A only), and one containing the Interrupt Pending 
bits (channel A only).
.P
The registers for each channel are designated as follows:
.BL
.LI
Write Registers : WR0-WR15.
.LI
Read Registers  : RR0-RR3,RR10,RR12,RR13,RR15.
.LE
The SCC contains only one WR2 and WR9, but they can be accessed by either
channel. All other registers are paired (one for each channel).
