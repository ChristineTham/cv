.H 1 "INTRODUCTION TO MIDI"
.P
MIDI stands for Musical Instrument Digital Interface.  It is a
specification of a communications scheme for digital music devices and
represents a
formal set of hardware and software rules for sending and receiving
musical-event data between computers and synthesizers.  MIDI is currently
the
.I de facto
standard for the interconnection of musical devices.  Musical data such
as notes or other performance parameters such as pitch-bending are
typically input by the musician using a keyboard synthesizer equipped with
a MIDI hardware interface.  This MIDI hardware encodes the key depressions
and transmits them serially over the MIDI port.
The output of this port may be connected to the input of another MIDI port
that is either attached to a computer or another synthesizer.
.P
The MIDI interface built into the 6809 microprocessor board allows data
from musical instruments equipped with a MIDI port to be collected, stored
and possibly analysed.  The software in the board allows the board to
function as a tapeless, single track 'digital' recorder of MIDI data.
.P
The next section describes how to use the the interface.
For a complete description of the MIDI protocol, see Section 4 "MIDI
Network Architecture".
