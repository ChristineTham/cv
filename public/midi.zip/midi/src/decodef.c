/*
 * %W% (%G% %U%)
 *
 * Sends SDLC frames across a channel (high-level)
 * Allows user to send S-, I- and U-frames
 *
 * christie
 */

#include "config.h"
#include "sdlc.h"

decodef(control)
char	control;
{
	/*
	 * decode control frame into frame type.
	 * Returns I_DENT, S_IDENT, U_IDENT or F_ERROR
	 */

	if (control & 01)
	{
		/* must be S- or U- frame */
		switch (control & 03)
		{
		case	S_IDENT:
		case	U_IDENT:
			return control & 03;

		default:
			return F_ERROR;
		}
		/*UNREACHED*/
	}
	else
		return I_IDENT;
}
