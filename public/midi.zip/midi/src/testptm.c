/*
 * %W% (%G% %U%)
 *
 * Test Motorola MC6840 PTM functionality
 *
 * christie
 */

#include "config.h"
#include "ports.h"
#include "ptm.h"

main()
{
	PTMinit();
	exit(0);
}
