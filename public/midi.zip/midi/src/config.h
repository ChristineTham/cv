/*
 * %W% (%G% %U%)
 *
 * Machine/Operating System/C Compiler configuration parameters
 *
 * christie
 */

/* Pseudo boolean type */
#define boolean	int
#define	TRUE	1
#define	FALSE	0

/* define this if the C Compiler does not accept the void type */
#define void	int

/* The following is the type of an unsigned char */
#define	uchar	char

/* Hardware address constants */

#define	RAMEND	0x8000		/* End of RAM */
#define	SCC0	0x8000		/* Address of SCC 0 */
#define	SCC1	0xa000		/* Address of SCC 1 */
#define	PTM	0xc000		/* address of PTM chip */

/* Port addresses */

#define	P_TERMINAL	SCC0		/* Terminal I/O port */
#define	P_HOST		(SCC0+2)	/* Host Interface I/O port */
#define	P_SDLC		SCC1		/* CS4 Networks SDLC port */
#define	P_MIDI		(SCC1+2)	/* MIDI Interface I/O port */

/* Timer latches for PTM */
#define	L_TIMER		PTM+02	/* MIDI event timer */
#define	L_TONE		PTM+04	/* tone frequency generator */
#define	L_DURATION	PTM+06	/* duration of tone one shot counter */

#ifndef NOEXTNMIVEC
extern int	*nmivec;
#endif

/* overwrites NMI vector */
#define	nmiset(addr)	*nmivec = addr
