/*
 * %W% (%G% %U%)
 *
 * SCC Register bit pattern constants
 *
 * christie
 */

/* Register 0 write patterns */

#define	W_RSTRXCRC	0100	/* Reset Rx CRC Checker */
#define W_RSTTXCRC	0200	/* Reset Tx CRC Transmitter */
#define W_TXEOM		0300	/* Reset Tx Underrun / EOM latch */

#define	W_RSTESI	020	/* Reset EXT/STAT interrupts */
#define	W_SABORT	030	/* Send SDLC abort */
#define	W_ENIRXC	040	/* Enable interrupt on next Rx char */
#define	W_RSTTXI	050	/* Reset Tx interrupt pending */
#define	W_RSTERR	060	/* Error reset */
#define	W_RSTIUS	070	/* Reset highest IUS pending */

/* Register 1 writes */

#define	W_WDREQEN	0200	/* WAIT/DMA request enable */
#define	W_WAITREQ	0	/* WAIT request function */
#define	W_DMAREQ	0100	/* DMA request function */
#define	W_WDREQT	0	/* WAIT/DMA request transmit */
#define	W_WDREQR	040	/* WAIT/DMA request receive */
#define	W_RXINTDS	0	/* Rx int disable */
#define	W_RXINTFS	010	/* Rx int on 1st char or special cond */
#define	W_RXINTAS	020	/* Rx int on all chars or special cond */
#define	W_RXINTS	030	/* Rx int on special condition */

#define	W_PARSC		04	/* parity is special condition */
#define	W_TXINTEN	02	/* tx int enable */
#define	W_RXINTEN	01	/* rx int enable */

/* Register 3 writes */

#define	W_RX5BITS	0	/* Rx 5 bits / char */
#define	W_RX7BITS	0100	/* Rx 7 bits / char */
#define	W_RX6BITS	0200	/* Rx 6 bits / char */
#define	W_RX8BITS	0300	/* Rx 8 bits / char */

#define	W_AUTOEN	040	/* Auto enables */
#define	W_ENTHUNT	020	/* Enter Hunt mode */
#define	W_RXCRCEN	010	/* Rx CRC enable */
#define	W_ADRSEARCH	04	/* Address search mode (SDLC) */
#define	W_SYNCLDI	02	/* sync char load inhibit */
#define	W_RXEN		01	/* Rx enable */

/* Register 4 writes */

#define	W_CLKX1		0	/* X1 clock */
#define	W_CLKX16	0x40	/* X16 clock */
#define	W_CLKX32	0x80	/* X32 clock */
#define	W_CLKX64	0xC0	/* X64 clock */

#define	W_SYNC8		0	/* 8 bit sync */
#define	W_SYNC16	0x10	/* 16 bit sync */
#define	W_SDLC		0x20	/* 16 bit sync */
#define	W_EXSYNC	0x30	/* 16 bit sync */

#define	W_SYNCM		0x00	/* sync modes enable */
#define	W_STOP1		0x04	/* 1 stop bit / char */
#define	W_STOP15	0x08	/* 1.5 stop bit / char */
#define	W_STOP2		0x0C	/* 2 stop bit / char */

#define	W_PODD		00	/* parity odd */
#define	W_PEVEN		02	/* parity even */
#define	W_PARITYEN	01	/* parity enable */

/* Register 5 writes */

#define	W_DTR		0x80	/* DTR active */
#define	W_TX5BIT	0	/* tx 5 bits / char */
#define	W_TX7BIT	0x20	/* tx 7 bits / char */
#define	W_TX6BIT	0x40	/* tx 6 bits / char */
#define	W_TX8BIT	0x60	/* tx 8 bits / char */

#define	W_SBREAK	020	/* send break */
#define	W_TXEN		010	/* tx enable */
#define	W_SDLCCRC	0	/* SDLC CRC poly */
#define	W_CRC16		04	/* CRC-16 poly */
#define	W_RTS		02	/* RTS active */
#define	W_TXCRCEN	01	/* Tx CRC enable */

/* Register 7 writes */

#define	W_SDLCFLAG	0x7e	/* 01111110 */

/* Register 9 writes */

#define	W_RSTCHA	0100	/* reset channel A */
#define	W_RSTCHB	0200	/* reset channel B */
#define	W_MRESET	0300	/* master reset */

#define	W_STATHI	020	/* status high */
#define	W_MIE		010	/* master interrupt enable */
#define	W_DLC		04	/* DLC ??? */
#define	W_NV		02	/* No vector with interrupt */
#define	W_VIS		01	/* Vector interrupt with status */

/* Register 10 writes */

#define	W_CRCP0		0	/* CRC preset 0 */
#define	W_CRCP1		0x80	/* CRC preset 1 */
#define	W_NRZ		0	/* NRZ mode */
#define	W_NRZI		0x20	/* NRZI mode */
#define	W_FM1		0x40	/* FM1 mode */
#define	W_FM0		0x60	/* FM0 mode */

#define	W_ACTPOLL	020	/* Go active on poll */
#define	W_FIDLE		0	/* Flag idle */
#define	W_MIDLE		010	/* Mark idle */
#define	W_FURUN		0	/* Flag underrun */
#define	W_AURUN		04	/* ABORT underrun */
#define	W_LOOP		02	/* Loop mode */
#define	W_SYNC6		01	/* 6 bit sync */

/* Register 11 writes */

#define	W_RTXCXTAL	0x80	/* RTxC pin is XTAL */

#define	W_RXCRTXC	0	/* Rx clock RTXC */
#define	W_RXCTRXC	0x20	/* Rx clock TRXC */
#define	W_RXCBRG	0x40	/* Rx clock BR Gen */
#define	W_RXCDPLL	0x60	/* Rx clock DPLL */

#define	W_TXCRTXC	0	/* Tx clock RTXC */
#define	W_TXCTRXC	010	/* Tx clock TRXC */
#define	W_TXCBRG	020	/* Tx clock BR Gen */
#define	W_TXCDPLL	030	/* Tx clock DPLL */

#define	WTRXCI		0	/* TRXC Input */
#define	WTRXCO		04	/* TRXC Output */

#define	W_TRXCOSC	0	/* TRXC out Oscillator */
#define	W_TRXCTXC	010	/* TRXC out TX clock */
#define	W_TRXCBRG	020	/* TRXC out BR Gen */
#define	W_TRXCDPLL	030	/* TRXC out DPLL */

/* Register 14 writes */

#define	W_ENTSEARCH	0x20	/* enter search mode */
#define	W_RSTMCLK	0x40	/* reset missing clock */
#define	W_DISDPLL	0x60	/* disable DPLL */
#define	W_SRCBRG	0x80	/* source = BR Gen */
#define	W_SRCRTXC	0xA0	/* source = RTXC */
#define	W_FMMODE	0xC0	/* set FM mode */
#define	W_NRZIMODE	0xE0	/* set NRZI mode */

#define	W_LLOOPBACK	020	/* local loopback */
#define	W_AECHO		010	/* auto echo */
#define	W_REQFN		04	/* request function */
#define	W_BRGSRC	02	/* BR Gen source */
#define	W_BRGEN		01	/* BR Gen enable */

/* Register 15 writes */

#define	W_BRKABIE	0200	/* Break / Abort IE */
#define	W_TXEOMIE	0100	/* Tx Underrun / EOM IE */
#define	W_CTSIE		040	/* CTS IE */
#define	W_SYNCHIE	020	/* Sync / Hunt IE */
#define	W_DCDIE		010	/* DCD IE */
#define	W_ZEROCIE	02	/* Zero count IE */

/* Register 0 reads */

#define	R_BRKAB		0200	/* Break / Abort */
#define	R_TXEOM		0100	/* Tx Underrun / EOM */
#define	R_CTS		040	/* CTS */
#define	R_SYNCH		020	/* Sync / Hunt */
#define	R_DCD		010	/* DCD */
#define	R_TXEMPTY	04	/* Tx buffer empty */
#define	R_ZEROC		02	/* Zero count */
#define	R_RXAVAIL	01	/* Rx char avail */

/* Register 1 reads */

#define	R_ENDFRAME	0200	/* End of frame (SDLC) */
#define	R_CRCFERR	0100	/* CRC/FRAME error */
#define	R_RXORUN	040	/* Rx overrun */
#define	R_PARERR	020	/* parity error */
#define	R_RESIDUE	016	/* residue code */
#define	R_ALLSENT	01	/* all sent */
