/*
 * %W% (%G% %U%)
 *
 * Motorola MC6840 PTM constants
 *
 * christie
 */

/* Address of PTM chip defined as PTM in config.h */

/* write registers */

#define	C_CR13		PTM+0	/* control register 1 & 3 */
#define	C_CR2		PTM+01	/* control register 2 */
#define	C_BUFFER1	PTM+02	/* MSB buffer register */
#define	C_LATCH1	PTM+03	/* Timer 1 latch */
#define	C_BUFFER2	PTM+04	/* MSB buffer register */
#define	C_LATCH2	PTM+05	/* Timer 2 latch */
#define	C_BUFFER3	PTM+06	/* MSB buffer register */
#define	C_LATCH3	PTM+07	/* Timer 3 latch */

/* read registers */

#define	C_STATUS	PTM+01	/* status register */
#define C_COUNTER1	PTM+02	/* timer 1 counter */
#define C_LSBCNT1	PTM+03	/* LSB Buffer register */
#define C_COUNTER2	PTM+04	/* timer 2 counter */
#define C_LSBCNT2	PTM+05	/* LSB Buffer register */
#define C_COUNTER3	PTM+06	/* timer 3 counter */
#define C_LSBCNT3	PTM+07	/* LSB Buffer register */

/* Control Register 1 */

#define	C1_START	0	/* Operate timers */
#define	C1_INTRST	01	/* Hold timers in preset state */

/* Control Register 2 */

#define	C2_WRITE3	0	/* Write CR3 */
#define	C2_WRITE1	01	/* Write CR1 */

/* Control Register 3 */

#define	C3_CDIV1	0	/* clock / 1 */
#define	C3_CDIV8	01	/* clock / 8 */

/* Common register 1 2 3 bits */

#define	C_EXCLOCK	0	/* Use external clock source */
#define	C_ENCLOCK	02	/* Use Enable (E or phi2) clock */

#define	C_COUNT16	0	/* 16 bit counting mode */
#define	C_COUNT8	04	/* dual 8 bit counting mode */

#define	C_CONTL		0	/* continuous operating mode */
				/* gate active/write latch/reset */
				/* initializes counter */

#define	C_FRQCL		010	/* Frequency comparison mode */
				/* int if gate freq < counter time out */

#define	C_CONT		020	/* continuous operating mode */
				/* gate active/reset */
				/* initializes counter */

#define	C_PULSL		030	/* Pulse width comparison mode */
				/* int if gate pulse < counter time out */

#define	C_SSHOTL	040	/* single shot operating mode */
				/* gate active/write latch/reset */
				/* initializes counter */

#define	C_FRQCMG	050	/* Frequency comparison mode */
				/* int if gate freq > counter time out */

#define	C_SSHOT		060	/* single shot operating mode */
				/* gate active/reset */
				/* initializes counter */

#define	C_PULSMG	070	/* Pulse width comparison mode */
				/* int if gate pulse > counter time out */

#define	C_INTDIS	0	/* Interrupt Flag Disable */
#define	C_INTEN		0100	/* Interrupt Flag Enable */

#define	C_TOUTDIS	0	/* Timer Output Disable */
#define	C_TOUTEN	0200	/* Timer Output Enable */
