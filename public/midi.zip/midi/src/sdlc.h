/*
 * %W% (%G% %U%)
 *
 * SDLC frame constants
 *
 * christie
 */

/* Frame type identification */
#define	I_IDENT		0	/* Information transfer command/response */
#define	S_IDENT		1	/* Supervisory command/response */
#define	U_IDENT		3	/* Unnumbered command/response */
#define	F_ERROR		4	/* Frame identification error */

/* control field offsets */

#define	SSEQ_OFF	0x02	/* receiver sequence offset */
#define	MODE_OFF	0x04	/* s-frame mode offset */
#define	PF_BIT		0x10	/* poll/final bit */
#define	RSEQ_OFF	0x20	/* receiver sequence offset */

/* control field masks */

#define	SSEQ_MASK	0x0E	/* receiver sequence mask */
#define	SMOD_MASK	0x0C	/* s-frame mode mask */
#define	UMOD_MASK	0xEC	/* u-frame modifier mask */
#define	RSEQ_MASK	0xE0	/* receiver sequence mask */

/* mode types */

#define	MODE_RR		0	/* receive ready */
#define	MODE_RNR	1	/* receiver not ready */
#define	MODE_REJ	2	/* reject */
#define	MODE_SREJ	3	/* selective reject (HDLC) */

/* command types */

#define	CR_NSI		0		/* non sequenced Information */
#define	CR_SNRM		(04 * RSEQ_OFF)	/* set normal response mode */
#define	CR_SARM		(03 * MODE_OFF)	/* set asynchronous response mode */
#define	CR_DISC		(02 * RSEQ_OFF)	/* disconnect */
#define	CR_ORP		(01 * RSEQ_OFF)	/* optional response poll */
#define	CR_SIM		(01 * MODE_OFF)	/* set initialization mode */

/* response types */

#define	CR_UI		0		/* non sequenced Information */
#define	CR_CMDR		(04 * RSEQ_OFF + 01 * MODE_OFF)	/* command reject */
#define	CR_UA		(03 * RSEQ_OFF)	/* nonsequence acknowledgment */
#define	CR_RIM		(01 * MODE_OFF)	/* request for initialization */
#define	CR_DM		(03 * MODE_OFF)	/* request online */

/* macro functions */

#define	maskns(control)		((control & SSEQ_MASK) / SSEQ_OFF)
#define	maskrs(control)		((control & RSEQ_MASK) / RSEQ_OFF)
#define	maskpf(control)		(control & PF_BIT)
#define	masksmod(control)	(control & SMOD_MASK / MODE_OFF)
#define	maskumod(control)	(control & UMOD_MASK)

/* error returns from rxpacket */
#define	E_CRCFERR	-1
#define	E_RXORUN	-2
