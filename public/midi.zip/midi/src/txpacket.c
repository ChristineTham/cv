/*
 * %W% (%G% %U%)
 *
 * Transmits an SDLC packet across the SDLC channel
 *
 * christie
 */

#include "config.h"
#include "ports.h"
#include "scc.h"

char	inittxp[6] =
	{
		4,
		/* enable transmitter and handshaking */
		5, W_DTR | W_TX8BIT | W_TXEN | W_SDLCCRC | W_RTS | W_TXCRCEN,
		/* reset errors */
		W_RSTERR,
		/* reset tx CRC generator */
		W_RSTTXCRC
	};

char	endtxp[4] =
	{
		2,
		/* disable transmitter */
		5, W_TX8BIT | W_SDLCCRC
	};

void
txpacket(addr, info, size, data)
char	addr, info;
int	size;
char	*data;
{
	char	stat;
	char	*statreg;

	statreg = P_SDLC + R_STATUS;

	/* initialize transmitter and clear errors */
	SCCprogram(P_SDLC, inittxp);

	/* send frame address and control bytes */
	PORTput(P_SDLC, addr);
	PORTput(P_SDLC, info);

	/* send data in frame */
	while (size--)
		PORTput(P_SDLC, *data++);

	/* tell SCC to finish packet */
	*statreg = W_TXEOM;

	/* check that packet has been transmitted */

	while (!((stat = *statreg) & R_TXEMPTY))
		;

	while (!((stat = *statreg) & R_TXEOM))
		;

	/* check for ALL SENT status in register 1 */
	*statreg = 1;
	while (!((stat = *statreg) & R_ALLSENT))
		;

	/* disable transmitter */
	SCCprogram(P_SDLC, endtxp);
}
