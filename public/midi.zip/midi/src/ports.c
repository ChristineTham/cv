/*
 * %W% (%G% %U%)
 *
 * MIDI/SDLC transmitter/receiver board port functions
 *
 * christie
 */

#include "config.h"
#include "ports.h"

int
PORTget(p)
char	*p;
{
	/* Get a byte from port p */
	/* Busy waits until port is ready */

	while (!PORTrxready(p))
		;
	return *(p + R_DATA);
}

void
PORTput(p, c)
char	*p;
char	c;
{
	/* Puts character c into port p */
	/* Busy waits until port is ready */

	while (!PORTtxready(p))
		;
	p += R_DATA;
	*p = c;
}

void
PORTsetbaud(p, b)
char	*p;
int	b;
{
	int	tc;

	p += R_STATUS;
	tc = BR_CONS0 / b - 2;
	*p = '\014';
	*p = tc % 256;
	*p = '\015';
	*p = tc / 256;
}
