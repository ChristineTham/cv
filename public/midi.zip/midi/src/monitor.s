;
; 6809 monitor
;
; Modified for the CS4 Microprocessor Systems MIDI interface board.
; Support for SCC serial chip used for Host/Terminal interface.
;
; Modifications done by Chris Tham (christie)
;
;	Commands:
;
; L	load
; M	memory change location "n"
; G	goto location "n"
; W	test memory from "m" to "n"
; S	enter sattelite subsystem
; C	continue after swi
; P	display memory from "m" to "n"
; ?	list valid commands
;
NULL:	equ	0		;string terminator
ENQ:	equ	$05
ACK:	equ	$06
NAK	equ	$15
SYNC	equ	$16
space:	equ	$20		;ascii equivalent for space
del:	equ	$7f		;ascii equivalent for Del Key
noerr:	equ	$0000		;flag for no error

;
;
; Zilog 8530 SCC (Serial Communications Controller) constants
;
adata:	equ	1		;SCC data register
astat:	equ	0		;SCC status register
acom:	equ	0		;SCC command register (same as status)
XMTSTA: equ	0B00000100	;acia transmitter status bit
DCD:	equ	0B00001000	;DCD bit (0 for Carrier on)
RCVSTA: equ	0B00000001	;acia receiver status bit

clrzer: equ	0B11111011	;clear zero bit of condition code register
setzer: equ	0B00000100	;set zero bit of condition code register

;
;
; Motorola MC6840 PTM (Programmable Timer Module) constants
;
pcr1	equ	0B000		;PTM control register 1
pcr2	equ	0B001		;PTM control register 2
pcr3	equ	0B000		;PTM control register 3
pstat	equ	0B001		;PTM status register
ptm1	equ	0B010		;PTM timer 1 counter/latch LSB
ptm2	equ	0B100		;PTM timer 2 counter/latch LSB
ptm3	equ	0B110		;PTM timer 3 counter/latch LSB
pmsb	equ	0B011		;MSB of counter/latch

;
; other constants
;
mtpatb: equ	0B11111111	;memory test pattern B
mtpatc: equ	0B10101010	;memory test pattern C
mtpatd: equ	0B01010101	;memory test pattern D
wbpat:	equ	0B10000000	;initialization for walking bit memory test
usercc: equ	0B00010000	;inhibit irq
;
;******************************************************************
;
; ===>> PROJECT SPECIFIC CONSTANTS <<===
;
rambeg: equ	$0000		;beginning of ram
ramend: equ	$8000		;1 past the ram
SCC0:	equ	$8000		;Zilog 8530 SCC 0
SCC0B:	equ	$8000		;terminal acia address - serial i/o
SCC0A:	equ	$8002		;host acia address - serial i/o
SCC1:	equ	$a000		;Zilog 8530 SCC 1
SCC1B:	equ	$a000		;CS4 Computer Networks SDLC channel
SCC1A:	equ	$a002		;MIDI UART serial i/o
PTM:	equ	$c000		;Motorola MC6840 PTM
prom1:	equ	$e000
prom2:	equ	$f000		;4k prom start location
;
;******************************************************************
;
; monitor ram
;
monstk: equ	ramend-98		;monitors user stack area
hdwrst: equ	ramend-48		;allow for qseudovecs & working store
;
;******************************************************************
;
;	Satellite Processor System communication area
;
	org	ramend-48	;DO NOT CHANGE UNLESS YOU CHANGE TRUN AND 09lib
param	defs	6
result	defs	2
;
;******************************************************************
;	monitor local storage
aciain: defs	2		;address of serial input device
aciout: defs	2		;address of serial output device
porta:	defs	2		;address of parallel port a
portb:	defs	2		;address of parallel port b
outsw:	defs	1		;output switch (0=output enabled)
errsto: defs	2		;error message storage - cleared for no error
addr:	defs	2		;address temp storage
check:	defs	1		;checksum for sattel
xtmp:	defs	2		;temporary storage for pretty picture display
;
;	vectors
swij3:	defs	2		;swi3 routine pointer
swij2:	defs	2		;swi2 routine pointer
fiov:	defs	2		;firq routine pointer
iov:	defs	2		;maskable irq routine pointer
swij1:	defs	2		;swi1 routine pointer
niov:	defs	2		;nmi routine pointer
stackp: defs	2		;stack pointer initialization


	org	prom2
;
; jump table to routines performing commands
;
fctabl:
	defm	'G'		;;"G" - go to entered address
	defw	goto
	defm	'L'		;;"L" - load
	defw	load
	defm	'M'		;;"M" - memory change
	defw	change
	defm	'P'		;;"P" - punch
	defw	punch
	defm	'W'		;;"W" - memory test
	defw	memtst
	defm	'S'		;;"S" - enter sattel
	defw	sattel
	defm	'C'		;;"C" - continue after swi1
	defw	cont
	defm	'?'		;;"?" - list valid commands
	defw	mhelp
fctben: equ	*
;
; constant data
;
mgreet: defm	'\r\n6809 Monitor - system type `V\'\0'
mcl:	defm	'\r\n*\0'		;  lf,cr,prompt
mqe:	defm	' ? undefined command. Type "?" for help\0'
mpstk:	defm	'\r\ncc a  b  dp x    y	   u	 pc  s\0'
mcrlf:	defm	'\r\n\0'		;  carriage return and line feed
nmihed: defm	'\r\nstk  a  b	dp x	y    u	  cc pc\r\n\0'
mtape1: defm	'\r\nS1\0'		;  punch header
merr1:	defm	'\r\nBAD RAM\0'
merr2:	defm	'\r\nCHECKSUM ERROR\0'
merr3:	defm	'\r\nBAD LOAD\0'
mcoms:	defm	'\r\n valid commands are :'
	defm	'\r\n  "G <XXXX>"	 - go to address X'
	defm	'\r\n  "L <XXXX>"	 - load address X'
	defm	'\r\n  "M <XXXX> <ZZ>"	 - change memory location X to Z'
	defm	'\r\n  "P <XXXX> <YYYY>" - display memory contents from X to Y'
	defm	'\r\n  "W <XXXX> <YYYY>" - test memory from X to Y'
	defm	'\r\n  "S"		 - return control to host'
	defm	'\r\n  "C"		 - continue after swi1\0'
;
; maskable interrupt sequences
;
io:	jmp	[iov]
fastio: jmp	[fiov]
;
; nmi sequence
;
nio:	jmp	[niov]		;get nmi vector
;
; swi interrupt sequences
;
sw1:	jmp	[swij1]
sw2:	jmp	[swij2]
sw3:	jmp	[swij3]

;
; initialization/reset code
;
start:
	lds	#hdwrst		;initialize hardware stack
	ldu	#monstk		;set up monitor's user stack pointer
	ldx	#swi1p		;swi1 routine
	stx	swij1
	ldx	#intz		;initialize interrupts for no action (rti only)
	stx	swij2		;for swi2
	stx	swij3		;for swi3
	stx	iov		;for irq
	stx	niov		;and nmi
	ldx	#fidef		;nmi default action
	stx	fiov		;for firq
	ldd	#SCC0B
	std	aciain
	std	aciout
strt4:	ldx	#mgreet		;greetings message
	stx	errsto	;put in place of error message
;
; initialize SCC0 chip for asynchronous Host/Terminal I/O
; 9600 baud, 7 bits even parity, 1 stop bit
; Channel A & B
;
	ldy	#SCC0+acom	;Address of SCC0 control register
;					(either channel)
	ldx	#sccn		;reset SCC0 to known state
	lda	#sccnc
	absr	sccini
	ldy	#SCC0A+acom
	ldx	#s0an		;Channel A Initialization
	lda	#s0anc
	absr	sccini
	ldx	#scc0c		;and set to cooked mode
	lda	#scc0cc
	absr	sccini
	ldy	#SCC0B+acom
	ldx	#s0bn		;Channel B Initialization
	lda	#s0bnc
	absr	sccini
	ldx	#scc0c		;and set to cooked mode
	lda	#scc0cc
	absr	sccini

	ldy	#SCC1+acom
	ldx	#sccn
	lda	#sccnc
	absr	sccini		;Initialize SCC1
	ldy	#SCC1A+acom
	ldx	#s1an
	lda	#s1anc
	absr	sccini		;Initialize Channel A to MIDI
	ldy	#SCC1B+acom
	ldx	#s1bn
	lda	#s1bnc
	absr	sccini		;Initialize Channel B to SDLC

;
; initialize PTM chip
;
	lda	#0B00000010	;Address Control Register 3
	sta	PTM+pcr2
	lda	#0B00000010
;		   \\\|/\\\_	Timer 3 clock / 1
;		    \\\	 \\_	Internal Clock
;		     \\\  \_	16-bit Count Mode
;		      \\\
;		       \\\
;			\\\_	Continuous Operating Mode, ~GATE down or
;			 \\	Reset causes counter initialization
;			  \\_	Interrupt Flag Masked
;			   \_	Timer output masked
	sta	PTM+pcr3
	lda	#0B00000011
;		   \\\|/\\\_	address Control Register 1
;		    \\\	 \\_	Internal Clock
;		     \\\  \_	16-bit Count Mode
;		      \\\
;		       \\\
;			\\\_	Continuous Operating Mode, ~GATE down or
;			 \\	Reset causes counter initialization
;			  \\_	Interrupt Flag Masked
;			   \_	Timer output masked
	sta	PTM+pcr2
	lda	#0B00000011
;		   \\\|/\\\_	all timers reset
;		    \\\	 \\_	Internal Clock
;		     \\\  \_	16-bit Count Mode
;		      \\\
;		       \\\
;			\\\_	Continuous Operating Mode, ~GATE down or
;			 \\	Reset causes counter initialization
;			  \\_	Interrupt Flag Masked
;			   \_	Timer output masked
	sta	PTM+pcr1

;
;	test if terminal connected
;
;	ldb	#DCD
;	andb	SCC0B+astat
;	abeq	prom1		;if DCD==0 jump to e000 eprom
;
; main command/control loop
;
contrl:
	ldu	#monstk		;set up monitor's user stack pointer
	clr	outsw		;make sure input is echoed
	ldx	errsto		;has there been an error?
	beq	con1		;if not, display prompt
	absr	pdata		;otherwise, print error message
	ldx	#noerr		;flag for no error
	stx	errsto		;reinitialize for no error
con1:	ldx	#mcl		;terminal prompt string
	absr	pdata		;print data string
	absr	inchp		;read command character
; "a" register holds character input by user
; first ignore carriage returns
	cmpa	#'\r'
	beq	contrl
; use jump table to go to appropriate routine
search:
	ldx	#fctabl		;x:= address of jump table
nxtchr: cmpa	,x+		;does input char match?
	beq	goodch		;yes, goto appropriate routine
	leax	2,x		;else, update index into table
	cmpx	#fctben		;end of table reached?
	bne	nxtchr		;no, try next char
	ldx	#mqe		;undefined command
	absr	pdata		;do print query message
	bra	contrl		;no match, reprompt user
goodch: absr	outs		;print space after acceptable command
	jsr	[0,x]		;go to appropriate routine
	bra	contrl		;and loop back to control
;
intz:	rti			;deafaul interrupt action
;
;
; load command
;
load:
	lda	#'='
	absr	outch
load1	absr	inch		;read
	ldx	#SCC0A
	stx	aciout		;write to host
	absr	outch
	ldx	#SCC0B
	stx	aciout		;write terminal
	absr	outch
	cmpa	#'\r'
	bne	load1
	lda	#'\n'
	absr	outch
	inc	outsw		;do not echo tape
	ldx	#SCC0A
	stx	aciain		;input from host
load2:	absr	inchp
	cmpa	#'S'
	bne	load2		;1st char not (S)
	absr	inchp		;read char
	cmpa	#'9'
	beq	loadz		;2nd char is (9)
	cmpa	#'1'
	bne	load2		;2nd char not (1)
	clrb			;zero checksum
	absr	byte		;read byte
	bne	lderr3		;format error caused invalid address to be built
	suba	#2
	pshs	a		;save byte count
	absr	baddr		;build address
	bne	lderr		;format error caused invalid address to be built
load3:	bsr	byte		;get data to be stored
	bne	lderr		;format error caused invalid byte to be built
	dec	0,s		;decrement byte count
	beq	load4		;is byte count zero?
	sta	0,x		;store data byte
	cmpa	,x+		;check data to see if stored and inc xreg
	beq	load3		;if successful, get next byte
	ldx	#merr1		;error message for bad ram
	bra	lderr2		;restore stack, save error message, then back to load routine
;
; does checksum check?
;
load4:	puls	a		;restore stack
	incb			;check checksum
	beq	load2		;okay?
	ldx	#merr2		;error message for checksum error
	bra	lderr4		;save error message, then back to load routine
lderr:	ldx	#merr3		;message for format error
lderr2: puls	a		;restore stack
	bra	lderr4		;save error message, then back to load routine
lderr3: ldx	#merr3		;message for format error
lderr4: stx	errsto		;save error message
	bra	load2		;wait for next s1 or s9
loadz:	ldx	#SCC0B
	stx	aciain		;back to terminal
	rts
;
; input hex character
; escape by carriage return, line feed, up arrow, or del key
; zero bit of ccreg set if valid hex character input
;
inhex:
	inc	outsw		;do not echo character
	absr	inchp		;input character and convert to upper case
	dec	outsw		;reallow character echo
	cmpa	#'\b'		;is it backspace
	beq	inhnot		;if so, quit
	cmpa	#'\s'		;is it space
	beq	inhnot		;if so, quit
	cmpa	#'\r'		;is it carriage return?
	beq	inhnot		;if so, quit
	cmpa	#'\n'		;is it line feed?
	beq	inhnot		;if so, quit
	cmpa	#'^'		;is it up arrow?
	beq	inhnot		;if so, quit
	cmpa	#del		;is it del key?
	beq	inhnot		;if so, quit
	cmpa	#'0'		;less than '0' ?
	blo	inhex		;if so, try again
	cmpa	#'9'		;less than '9' ?
	bls	inhex2		;if hex 0-9, output character
	cmpa	#'A'		;less than 'A' ?
	blo	inhex		;if so, try again
	cmpa	#'F'		;higher than 'F' ?
	bhi	inhex		;if so, try again
	absr	oinp1		;if A-F, output character and
	suba	#'A'-$a		;convert ascii alpha A-F to hex a-f
	bra	inhex3		;flag for hex
inhex2: absr	oinp1		;output character
	suba	#'0'		;convert ascii 0-9 to hex 0-9
inhex3: orcc	#setzer		;flag for hex by setting zero bit
	rts
inhnot: andcc	#clrzer		;flag for not hex by clearing zero bit
	rts
;
; input byte (two frames)
; escape by carriage return, line feed, up arrow, or del key
; zero bit of ccreg set if valid byte built
;
byte:
	bsr	inhex		;get hex char (first frame)
	bne	bytez		;if not hex, quit building byte
	asla
	asla
	asla
	asla			;left justify first frame
	pshs	a,b		;stack first frame and old checksum
	bsr	inhex		;get hex char (second frame)
	beq	bytex		;if hex character, continue building byte
	leas	2,s		;otherwise restore stack pointer
	bra	bytez		;and quit building byte - acca holds character
bytex:	adda	,s+		;add frames and increment stack pointer
	tfr	a,b		;get copy of byte
	addb	,s+		;update checksum and restore stack pointer
	orcc	#setzer		;flag for valid byte by setting zero bit
bytez:	rts			;if not valid byte, zero bit will be clear
;
; output a space
;
outs:
	pshs	a		;save acca
	lda	#space		;space
	bsr	outch		;output character
	puls	a,pc		;restore acca and rts
outhl:	lsra			;out left hex digit
	lsra
	lsra
	lsra
outhr:	anda	#$0f		;out right hex digit
	adda	#'0'
	cmpa	#'9'
	bls	outch		;output 0-9
	adda	#'A'-$a-'0'	;output A-F
;
; output one char
; %
outch:
	pshs	b,x
	ldx	aciain
	ldb	#XMTSTA		;transmitter status bit
out1:	bitb	astat,x
	beq	out1
	sta	adata,x
	puls	b,x,pc


; test if valid alphabetic character
; zero bit of ccreg set if valid alphabetic character
;
alpha:
	cmpa	#'A'
	blt	a1
	cmpa	#'Z'
	ble	a2
	cmpa	#'a'
	blt	a1
	cmpa	#'z'
	bgt	a1
a2:	orcc	#setzer		;flag for alpha by setting zero bit
	rts
a1:	andcc	#clrzer		;flag for not alpha by clearing zero bit
	rts
;
; input one char to areg
;
inch:
	absr	tstat		;test the status of the keyboard
	beq	inch		;loop if not ready
	rts

; build address
; zero bit of ccreg set if valid address built
; acca has invalid entry if valid address not built - otherwise acca not lost
;
baddr:
	pshs	a		;save acca
	bsr	byte		;read 2 frames
	bne	badadr		;invalid byte read
	sta	addr		;save ms byte
	bsr	byte
	bne	badadr		;invalid byte read
	sta	addr+1		;save ls byte
	ldx	addr		;x has address we built
	orcc	#setzer		;flag for good address by setting zero bit
	puls	a,pc		;restore acca and rts
badadr: sta	0,s		;acca will have invalid entry upon puls a
	andcc	#clrzer		;flag for bad address by clearing zero bit
	puls	a,pc		;invalid entry into acca and rts
;
; input character and convert to upper case
;
inchp:
	bsr	inch		;get char
oinchp: bsr	alpha		;is character alphabetic
	bne	oinp1		;if not alphabetic, leave alone
	anda	#$5f		;otherwise, convert to upper case
oinp1:	tst	outsw		;should input be echoed?
	beq	outch		;if so, output the char and rts
	rts			;otherwise just rts
;
; change memory (m aaaa dd nn) - aaaa=address  dd=old data  nn=new data
;
change:
	bsr	baddr		;build address
	bne	chaz		;if not valid addr, quit routine
	tfr	x,y		;get copy of address in yreg
	jsr	outs		;output space
chang2: tfr	y,x		;put into xreg,	addr where data to be changed
	bsr	out2hs		;print data old
chang3: absr	byte		;get new data byte
	bne	chang4		;if not valid byte, decide next move
	sta	0,y		;if valid byte, change memory
	cmpa	0,y		;check memory
	beq	chanpr		;change made ok
	lda	#'?'		;no change made
	absr	outch		;print '?' and reopen address
	bra	chanpr
lf:	leay	2,y		;inc address
ua:	leay	-1,y		;dec address
chanpr: ldx	#mcrlf
	bsr	pdata		;print car ret, line feed
	pshs	y		;temp storage for new address
	leax	0,s		;point to new addr
	bsr	out4hs		;output data addr
	puls	y		;remove temp address storage
	bra	chang2
; non valid byte entered
chang4: cmpa	#'\n'		;was it line feed?
	beq	lf		;if so, look at next location
	cmpa	#'\s'		;was it space
	beq	lf		;if so, look at next location
	cmpa	#'^'		;was it up arrow?
	beq	ua		;look at preceeding location
chaz:	rts			;any other character (car ret or del key), quit
;
; output two hex characters
;
out2h:
	lda	,x+		;output 2 hex char
	pshs	a
	absr	outhl		;out left hex char
	puls	a
	abra	outhr		;output right hex char and rts
out4hs: bsr	out2h		;output 4 hex char + space
out2hs: bsr	out2h		;output 2 hex char + space
	abra	outs		;output space and rts
;
; G requires user to enter destination address from keyboard
; this is real hard go
;
goto:
	absr	baddr		;go get program address from user
	beq	go2		;if address valid
	rts			;if invalid character, return to caller
go2:	ldx	#mcrlf
	absr	pdata
	andcc	#usercc
	jmp	[addr]
	jmp	,x		;x was set by baddr
;
; print data pointed to by xreg
;
pdata:
	pshs	a		;save acca
p1:	lda	,x+		;get character and auto increment
	cmpa	#NULL
	beq	pdz		;stop on eot
	absr	outch		;output character
	bra	p1		;do next character
pdz:	puls	a,pc		;restore acca and rts
;
; print contents of stack
;
pstak:
	ldx	#mpstk		;cr, lf, register header, cr, lf
	bsr	pdata		;print string
	ldx	stackp		;print out stack
	bsr	out2hs		;condition code register
	bsr	out2hs		;acc-a
	bsr	out2hs		;acc-b
	bsr	out2hs		;direct page register
	bsr	out4hs		;x-reg
	bsr	out4hs		;y-reg
	bsr	out4hs		;user stack pointer
	bsr	out4hs		;p-counter
	ldx	#stackp		;pointer to stack pointer
	bsr	out4hs		;hardware stack pointer
	rts
;
;	firq	default service
;
;
fidef:	sts	stackp
	pshs	u,y,x,dp,b,a
	ldx	stackp
	leax	-3,x		;allow for cc, pc
	stx	stackp
	ldx	#nmihed
	absr	pdata		;print string
	ldx	#stackp
	absr	out4hs		;print stack pointer
	leax	,s
	absr	out2hs		;a
	absr	out2hs		;b
	absr	out2hs		;dp
	absr	out4hs		;x
	absr	out4hs		;y
	absr	out4hs		;u
	absr	out2hs		;cc
	absr	out4hs		;pc
	ldx	#mcrlf
	absr	pdata
	ldy	#4
f1	ldx	#57600
f2	leax	-1,x
	bne	f2
	leay	-1,y
	bne	f1		;delay to debounce the firq wire twiddle
	puls	a,b,dp,x,y,u
	rti
; punch dump
; punch from beginning address (bega) through ending address (enda)
;
; hardware stack offsets for temporary information
dtemp1: equ	0		;8 bits temp
dtemp2: equ	1		;8 bits temp
xtemp1: equ	2		;temp adr
punch:
	leas	-4,s		;reserve 4 bytes of stack as temporary storage
pstart: absr	baddr		;get starting adr
	bne	punz		;if not valid address, quit
	stx	xtemp1,s	;save starting adr
	absr	outs		;leave one space
	absr	baddr		;get ending adr - save in addr
	bne	punz		;if not valid address, quit
pun2:	ldd	addr		;end adr
	subd	xtemp1,s	;minus starting adr
	cmpd	#24		;less than 24?
	blo	pun3		;if so, not a complete punch line
	ldb	#23
pun3:	addb	#4
	stb	dtemp1,s	;number of frames in punch line
	subb	#3
	stb	dtemp2,s	;number of data bytes in punch line
;
; punch cr,lf,s,1
;
	ldx	#mtape1
	absr	pdata
	clrb			;zero checksum
	leax	dtemp1,s	;punch frame count
	bsr	pun5		;punch 2 hex characters
	leax	xtemp1,s	;punch address
	bsr	pun5
	bsr	pun5
	ldx	xtemp1,s	;punch data
pun4:	bsr	pun5		;punch one byte (2 frames)
	dec	dtemp2,s	;dec byte count
	bne	pun4		;finished?
	stx	xtemp1,s	;new starting adr
	comb			;complement checksum
	pshs	b,x
	tfr	s,x
	bsr	pun5		;punch checksum
	puls	b,x		;restore stack
	leax	-1,x
	cmpx	addr		;finished?
	bne	pun2
punz:	leas	4,s		;remove 4 bytes temporary storage
	rts
; punch 2 hex characters and update checksum
pun5:	addb	0,x		;update checksum
	jmp	out2h		;output 2 hex characters and rts
;
; software interrupt processing (swi)
;
swi1p:
	sts	stackp		;save user's hardware stack pointer
	absr	pstak		;stop and show regs to user
	jmp	contrl		;return to control loop
;
; C command, to continue from swi1 by rti
;
cont:	lds	stackp
	rti
;
transp:
t1:	lda	#RCVSTA
	bita	SCC0B+astat
	abeq	t2
	ldb	SCC0B+adata
	cmpb	#$01		;cntr a
	abeq	_S_		;goto restart

t3	lda	#XMTSTA
t4:	bita	SCC0A+astat
	beq	t4
	stb	SCC0A+adata
t2	lda	#RCVSTA
	bita	SCC0A+astat
	abeq	t1
	ldb	SCC0A+adata
	cmpb	#SYNC
	bne	t5
	rts			;host wants exit from transp

t5	lda	#XMTSTA
tt4:	bita	SCC0B+astat
	beq	tt4
	stb	SCC0B+adata
	abra	t1
;
;	sattel Bo0Bs sattelite subsystem
;
sattel:
	ldx	#10000
b1	leax	-1,x
	bne	b1		;delay 80ms to make sure acia is empty
;				before changing to 7 bit chars with parity
	ldy	#SCC0A+acom
	ldx	#scc0c
	lda	#scc0cc
	absr	sccini
	absr	transp		;put Channel A in cooked mode

spntry:
	ldy	#SCC0A+acom
	ldx	#scc0r
	lda	#scc0rc
	absr	sccini		;set Channel A in raw mode

main	absr	cpin	;read a character from the host
	cmpa	#ENQ	;look for control character
	bne	main

	absr	cpin	;read action number
	cmpa	#5
	abgt	_S_
	asla		;mult by two
	ldx	#action
	jmp	[a,x]	;go to action routine
action	defw	serror
	defw	readm
	defw	writem
	defw	trans
	defw	return
;
serror	jmp	sattel
;
;	send memory from sp to cp
;
;	read memory sp to cp
;
readm	absr	getadr	;get address of mem to send
	absr	cpin	;get count of bytes to send
	clrb
	exg	a,b
	tfr	d,x
	clr	check	;initialise check character
r1	lda	,y+	;get a byte
	absr	cpout	;send it
	adda	check
	sta	check	;compute check character
	leax	-1,x
	bne	r1	;repeat if more bytes to send
	lda	check
	absr	cpout	;send check character
	jmp	main
;
;	write memory cp to sp
;
writem	absr	getadr	;get address
	absr	cpin	;get number of bytes
	clrb
	exg	a,b	;put count into low order part of d reg
	tfr	d,x	;into x reg
	clr	check	;clear check char
w1	absr	cpin	;read a byte
	sta	,y	;store it
	lda	,y+	;read it back
	adda	check	;calculate check char
	sta	check
	leax	-1,x	;decrement count
	bne	w1	;continue if non zero
	absr	cpin	;read the check character
	cmpa	check	;compare it with the calculated check
	bne	ww1
	lda	#ACK	;ok
	bra	w2
ww1	lda	#NAK
w2	absr	cpout	;send acknowledgement
	jmp	main
;
;	read an address from the cp
;
getadr	absr	cpin	;read high byte of address
	exg	a,b
	absr	cpin	;read low byte of address
	exg	a,b
	tfr	d,y	;leave address in y reg
	rts
;
;	transfer control to an sp program
;
trans	absr	getadr	;get address to go to
	lda	#ACK
	absr	cpout	;acknowledge
	andcc	#usercc		;allow firq
	jmp	,y	;jump to the designated address
;
;	return control to an sp program
;
return	lda	#ACK
	absr	cpout	;acknowledge return from system call
	rts		;absr used for sys call
;
;
;
;	read a character from the cp
;
;
cpin:
	lda	#RCVSTA
Z1:	bita	SCC0A+astat
	beq	Z1
	lda	SCC0A+adata
	rts
;
;	get charcter from terminal
;
getc:
	ldb	#RCVSTA
G1:	bitb	SCC0B+astat
	beq	G1
	ldb	SCC0B+adata
	clra
	rts
;
;	put character to terminal
;
putc:
	lda	#XMTSTA+DCD
P1:	bita	SCC0B+astat
	beq	P1
	stb	SCC0B+adata
	rts
;
;	write a character to the cp
;
cpout:
	ldb	#XMTSTA
C1:	bitb	SCC0A+astat
	beq	C1
	sta	SCC0A+adata
	rts
;
;
;	dig parameters of system calls
;	library routine calls library sys
;		which calls monitor sys
;
spar	ldb	6,s
	stb	param+1
	ldb	7,s
	stb	param+0
	ldb	8,s
	stb	param+3
	ldb	9,s
	stb	param+2
	ldb	10,s
	stb	param+5
	ldb	11,s
	stb	param+4
	rts
;
;	generate system call
;
sys	lda	#ENQ
	pshs	b
	absr	cpout
	puls	a
	absr	cpout
	absr	main
	ldd	result
	rts

;
; memory test program
; takes approx 3 min 53 sec for 1K byte memory test with 1 MHz system clock
; increasing memory size of test causes time to increase by square law
; for example 8K byte memory test takes 8 * 8 * 3 min 53 sec = 4 hr 9 min
;
memtst:
	leas	-2,s		;set aside temporary storage
	absr	baddr		;get starting address
	lbne	wbtz		;if not valid address, quit
	tfr	x,y		;save starting address in yreg
	absr	outs		;leave space
	absr	baddr		;get ending address
	lbne	wbtz		;if not valid address, quit
	absr	outs
	lda	#'A'		;get output char for memory test A
	sta	dtemp1,s	;make dtemp1,s nonzero (1st time through)
	bsr	outcht		;go output start of test char
;
mem2:	tfr	y,x		;starting address into xreg
mem3:	clr	dtemp2,s	;clear flag
	tfr	x,d		;get data from address- a,b address being stored
mem4:	tst	dtemp1,s	;should we store (1st time only)
	beq	mem5		;no, just verify
	sta	0,x		;yes, store
mem5:	cmpa	,x+		;test right after store or for verify & auto inc
	beq	M1
	bsr	error		;found error
M1:	cmpx	addr		;end of memory reached?
	bhi	mem6		;done
	tst	dtemp2,s	;1st or 2nd byte of address being tested?
	bne	mem3		;if was 2nd then finished with this address
	tfr	b,a		;otherwise setup for 2nd byte
	inc	dtemp2,s	;and flag to that effect
	bra	mem4		;do 2nd byte now
;
;	end of store or verify loop;
;	do verify if not already done
;
mem6:	tst	dtemp1,s	;has verify been done?
	beq	pat		;yes, go on to next test
	clr	dtemp1,s	;no, indicate that verify should take place
	bra	mem2		;back through memory again
;
;	pattern tests
;	first store all ones
;
pat:	lda	#'B'		;indicates memory test B
	bsr	outcht		;output to terminal
	lda	#mtpatb
	bsr	storea
;
;	store 10101010 pattern
;
	lda	#'C'
	bsr	outcht
	lda	#mtpatc
	bsr	storea
;
; store 01010101 pattern
;
	lda	#'D'
	bsr	outcht
	lda	#mtpatd
	bsr	storea
;
; store all zeroes
;
	lda	#'E'
	bsr	outcht
	clra
	bsr	storea
;
;	go to walking bit test now
;
	bra	wbtst		;walking bit test
;
outcht: lbra	outch		;output char
;
;	storea goes through memory with bit pattern
;	given in a register
;
storea: tfr	y,x		;starting address into xreg
st31:	sta	,x+		;store pattern
	cmpx	addr
	bls	st31		;more
;	verify data stored
	tfr	y,x		;starting address into xreg
st42:	cmpa	,x+		;same as stored data? - auto inc
	beq	SS1		;ok
	bsr	error		;found error
SS1:	cmpx	addr		;end of memory reached?
	bls	st42
	rts
;
; error routine
; prints - was data, should have been data, address that failed
;
error:
	leax	-1,x		;get back address that failed (before auto inc)
	pshs	a,x		;save should have been data and address of error
	lda	0,x		;data was
	pshs	a		;save was data
	ldx	#mcrlf		;cr lf
	absr	pdata		;print it
	leax	0,s		;where information to be printed is
	absr	out2hs		;print was data
	absr	out2hs		;print should have been data
	absr	out4hs		;print out address that failed
	puls	a		;restore stack
	puls	a,x		;restore acca and xreg
	leax	1,x		;restore xreg to auto incremented address
	rts
;
;	walking bit test
;	assumes zeroes are in memory (pia last test)
;
;	b holds pattern
;	dtemp1,s has pattern holding location
;
wbtst:
	lda	#'W'
	bsr	outcht		;start of test char
	sty	dtemp1,s	;starting address is first holding location
wbt2:	ldb	#wbpat		;start new bit pattern
wbt3:	tfr	y,x		;put starting address into xreg
	stb	[dtemp1,s]	;store pattern in holding location
; loop through memory making sure it's all zero
; except for the 1 bit in location given by dtemp1,s
wbt4:	cmpx	dtemp1,s	;is xreg same as holding location
	beq	wbt6		;if so, do special test
	lda	,x+		;otherwise just check if 0 and auto inc xreg
	bne	wbter1		;if nonzero, indicate error
wbt5:	cmpx	addr		;end of memory reached?
	bls	wbt4		;if not, check next address
; update bit position
	lsrb			;logical shift right of bit
	bcc	wbt3		;if not shifted out, keep same holding location
; update holding location
	ldx	dtemp1,s	;otherwise, get holding location
	clr	,x+		;clear that location and increment holding loc
	stx	dtemp1,s	;save new holding location
	cmpx	addr		;end of memory reached
	bls	wbt2		;if not, reinitialize bit pat in new holding loc
wbtz:	leas	2,s		;otherwise, restore stack
	rts			;and quit
wbt6:	cmpb	,x+		;is pattern what it should be? - auto inc xreg
	beq	wbt5		;if so, continue with test
	tfr	b,a		;otherwise put bit pattern in acca
	bra	wbter2		;and give error
wbter1: clra			;what data should be (0)
wbter2: bsr	error		;error, tell user
	bra	wbt5		;then, continue with test

;
; ? -command for help
;
mhelp:	ldx	#mcoms		;print out valid commands
	jmp	pdata

;
; Initialize SCC chip by sending command string at address in X register
; to memory mapped register at address in Y register.  Command string has
; length given by contents of A register.
sccini:
	ldb	,x+		;Get byte and increment string address
	stb	,y
	deca
	bne	sccini
	rts

;*************************************************************************
;
	org	$f800		;THIS TABLE HAS TO BE HERE
;
; list of user usable monitor routines
; registers unaffected accept those required to pass information unless stated
; indirect addressing to be used to access routines
; for example:	 jsr [_inch_]	 will jump to subroutine inch
; user stack pointer must point to acia address that is desired for input
; user stack pointer +2 must point to acia address that is desired for output
; user stack pointer +4 is output switch -  0 for echo of input, 1 for non echo
_ctrl_: jmp	contrl		;monitor control loop - all registers destroyed
_inch_: jmp	inch		;input ascii character into acca
_inpr_: jmp	inchp		;input ascii char, conv to upper case, into acca
_inhx_: jmp	inhex		;input a hex digit into acca, set cczero if hex
_byte_: jmp	byte		;input two hex digits (one byte) into acca and update accb (checksum)
_badr_: jmp	baddr		;input four hex digits (address) into xreg and user stack +6
_outc_: jmp	outch		;output ascii character from acca
_outl_: jmp	outhl		;output left hex digit from acca
_outr_: jmp	outhr		;output right hex digit from acca
_out2_: jmp	out2h		;output byte pointed to by xreg - acca lost
_ou2s_: jmp	out2hs		;output byte pointed to by xreg and then a space - acca lost
_ou4s_: jmp	out4hs		;output address pointed to by xreg and a space - acca lost
_pdat_: jmp	pdata		;output string of ascii characters pointed to by xreg until NULL reached
_outs_: jmp	outs		;output a space
_spar_: jmp	spar		;dig parameters of second level caller
_sys_:	jmp	sys		;generate sattel system call
_sattel_: jmp	sattel
_S_:	jmp	start		;reset
_S_ID:	defm	'V'		;SYSTEM IDENTIFICATION - SEE trun.c
_PUTC:	defw	putc
_GETC:	defw	getc
_PARAM: defw	param
_SCC0A: defw	SCC0A
_tsta_: jmp	tstat		;test the status of the console. returns result in acca
;
;
;
;						*
;	available				*
;	for					*
;	expansion				*
;						*

;
; SCC Programming Tables (courtesy of christie, after much sweat and blood)
;		Reg Contents	Description
;**************************************************************************
; SCC General Initialization (Interrupts all disabled)
sccn:
	defb	9,0B11000010
;		      \/ \\\\\_ no VIS (vector interrupt status)
;		       \  \\\\_ NV (no vector with interrupt)
;			\  \\\_ no DLC (what does this mean???)
;			 \  \\_ no MIE (master interrupt enable)
;			  \  \_ status low
;			   \
;			    \
;			     \_ Hardware Reset

	defb	2,0B00000000	;Interrupt Vector = 0
sccnc:	equ	4

; SCC Enable Interrupts
scci:
	defb	9,0B00001010
;			 \\\\\_ no VIS (vector interrupt status)
;			  \\\\_ NV (no vector with interrupt)
;			   \\\_ no DLC (what does this mean???)
;			    \\_ MIE (master interrupt enable)
;			     \_ status low
sccic:	equ	2

; Enable Rx, Tx & error (special condition) interrupts on SCC channel
sccei:
	defb	1,0B00001111
;		      \|/\/\\\_ enable external interrupts
;		       \  \ \\_ enable Tx interrupts
;			\  \ \_ parity = special condition
;			 \  \
;			  \  \_ enable Rx interrupt on 1st char or special cond
;			   \
;			    \
;			     \_ No DMA requests

	defb	15,0B11001000
;		      \\  \
;		       \\  \
;			\\  \
;			 \\  \_ DCD int enable
;			  \\
;			   \\
;			    \\_ Tx Underrun int enable
;			     \_ BREAK int enable
scceic: equ	4

; SCC0 Channel A initialization (Host serial I/O) -- no interrupts
s0an:
	defb	1,  0B00000000
;		      \|/\/\\\_ no external interrupts
;		       \  \ \\_ no Tx interrupts
;			\  \ \_ parity != special condition
;			 \  \
;			  \  \_ no Rx interrupts
;			   \
;			    \
;			     \_ No DMA requests

	defb	15,0B00000000	;Disable All interrupts

	defb	11, 0B01010100
;		      \\/\/\\/
;		       \\ \ \\_ ~TRxC out = XTAL output
;			\\ \ \_ ~TRxC is output pin
;			 \\ \
;			  \\ \_ Tx Clock = BR Generator output
;			   \\
;			    \\_ Rx Clock = BR Generator output
;			     \_ ~RTxC = XTAL

	defb	14, 0B00000001
;			 \\\\\_ enable BR Generator
;			  \\\\_ BR Generator Source (maybe should be 1???)
;			   \\\_ ~DTR function
;			    \\_ no auto echo
;			     \_ no local loopback
s0anc:	equ	8

; SCC0 Channel B initialization (Terminal I/O) -- no interrupts
s0bn:
	defb	1,0B00000000
;		      \|/\/\\\_ no external interrupts
;		       \  \ \\_ no Tx interrupts
;			\  \ \_ parity != special condition
;			 \  \
;			  \  \_ no Rx interrupts
;			   \
;			    \
;			     \_ No DMA requests

	defb	15,0B00000000	;Disable All interrupts

	defb	11, 0B11010100
;		      \\/\/\\/
;		       \\ \ \\_ ~TRxC out = BR Generator Output
;			\\ \ \_ ~TRxC is output pin
;			 \\ \
;			  \\ \_ Tx Clock = BR Generator output
;			   \\
;			    \\_ Rx Clock = BR Generator output
;			     \_ ~RTxC = not XTAL

	defb	14, 0B00000001
;			 \\\\\_ enable BR Generator
;			  \\\\_ BR Generator Source (maybe should be 1???)
;			   \\\_ ~DTR function
;			    \\_ no auto echo
;			     \_ no local loopback
s0bnc:	equ	8

; Initialize SCC0 channel to raw (8 bits, 1 stop bit, no parity 9600 baud)
scc0r:
	defb	4,0B01000110
;		      \/  \/\/
;		       \   \ \_ no parity
;			\   \
;			 \   \_ 1 stop bit
;			  \
;			   \
;			    \
;			     \_ X16 clock

	defb	12,10		;BR Generator Time constant = 10
	defb	13,0		;This gives baud rate of 9600 baud
;				XTAL frequency = 3.6864 MHz
;				Hence:
;				baud rate = 1 / (2 * (time constant + 2) *
;					(BR clock period))
;				BR clock period = 1 / (XTAL freq / 16)
;						= 16 / 3.6864 MHz
;						= 1 / 230.4 kHz
;				baud rate = 1 / (2 * (10 + 2) / 230.4 kHz)
;					  = 230.4 kHz / (2 * (10 + 2))
;					  = 9600 baud

	defb	3,0B11000001
;		      \/     \_ Rx Enable
;		       \
;			\
;			 \
;			  \
;			   \
;			    \
;			     \_ Rx 8 bits / character

	defb	5,0B11101010
;		      \\/\\ \\_ disable Tx CRC
;		       \\ \\ \_ RTS = 1
;			\\ \\
;			 \\ \\_ Tx Enable
;			  \\ \_ BREAK off
;			   \\
;			    \\_ Tx 8 bits / character
;			     \_ DTR = 1
scc0rc: equ	10

; Initialize SCC0 channel to cooked (7 bits, 1 stop bit, even parity 9600 baud)
scc0c:
	defb	4,0B01000111
;		      \/  \/\/
;		       \   \ \_ even parity
;			\   \
;			 \   \_ 1 stop bit
;			  \
;			   \
;			    \
;			     \_ X16 clock

	defb	12,10		;BR Generator Time constant = 10
	defb	13,0		;This gives baud rate of 9600 baud
;				XTAL frequency = 3.6864 MHz
;				Hence:
;				baud rate = 1 / (2 * (time constant + 2) *
;					(BR clock period))
;				BR clock period = 1 / (XTAL freq / 16)
;						= 16 / 3.6864 MHz
;						= 1 / 230.4 kHz
;				baud rate = 1 / (2 * (10 + 2) / 230.4 kHz)
;					  = 230.4 kHz / (2 * (10 + 2))
;					  = 9600 baud

	defb	3,0B01000001
;		      \/     \_ Rx Enable
;		       \
;			\
;			 \
;			  \
;			   \
;			    \
;			     \_ Rx 7 bits / character

	defb	5,0B10101010
;		      \\/\\ \\_ disable Tx CRC
;		       \\ \\ \_ RTS = 1
;			\\ \\
;			 \\ \\_ Tx Enable
;			  \\ \_ BREAK off
;			   \\
;			    \\_ Tx 7 bits / character
;			     \_ DTR = 1
scc0cc: equ	10

; SCC1 Channel A initialization (MIDI serial I/O) -- no interrupts
; Asynchronous, 31.25 kbaud, 8 bits / character, 2 stop bits
s1an:
	defb	1,  0B00000000
;		      \|/\/\\\_ no external interrupts
;		       \  \ \\_ no Tx interrupts
;			\  \ \_ parity != special condition
;			 \  \
;			  \  \_ no Rx interrupts
;			   \
;			    \
;			     \_ No DMA requests

	defb	15,0B00000000	;Disable All interrupts

	defb	11, 0B11010100
;		      \\/\/\\/
;		       \\ \ \\_ ~TRxC out = XTAL output
;			\\ \ \_ ~TRxC is output pin
;			 \\ \
;			  \\ \_ Tx Clock = BR Generator output
;			   \\
;			    \\_ Rx Clock = BR Generator output
;			     \_ ~RTxC = XTAL

	defb	14, 0B00000011
;			 \\\\\_ enable BR Generator
;			  \\\\_ BR Generator Source (maybe should be 1???)
;			   \\\_ ~DTR function
;			    \\_ no auto echo
;			     \_ no local loopback

	defb	4,  0B01001110
;		      \/  \/\/
;		       \   \ \_ no parity
;			\   \
;			 \   \_ 2 stop bits/character
;			  \
;			   \
;			    \
;			     \_ X16 clock

	defb	12,8		;BR Generator Time constant = 8
	defb	13,0		;This gives baud rate of 31250 baud
;				XTAL frequency = 10 MHz
;				Hence:
;				baud rate = 1 / (2 * (time constant + 2) *
;					(BR clock period))
;				BR clock period = 16 / XTAL frequency
;						= 16 / 10 MHz
;						= 1 / 625 kHz
;				baud rate = 1 / (2 * (8 + 2) / 625 kHz)
;					  = 625 kHz / (2 * (8 + 2))
;					  = 31250 baud

	defb	3,  0B11000001
;		      \/     \_ Rx Enable
;		       \
;			\
;			 \
;			  \
;			   \
;			    \
;			     \_ Rx 8 bits / character

	defb	5,  0B11101010
;		      \\/\\ \\_ disable Tx CRC
;		       \\ \\ \_ RTS = 1
;			\\ \\
;			 \\ \\_ Tx Enable
;			  \\ \_ BREAK off
;			   \\
;			    \\_ Tx 8 bits / character
;			     \_ DTR = 1
s1anc:	equ	18

; SCC1 Channel B initialization (CS4 Networks SDLC) -- no interrupts
s1bn:
	defb	1,  0B00000000
;		      \|/\/\\\_ no external interrupts
;		       \  \ \\_ no Tx interrupts
;			\  \ \_ parity != special condition
;			 \  \
;			  \  \_ no Rx interrupts
;			   \
;			    \
;			     \_ No DMA requests

	defb	15,0B00000000	;Disable All interrupts

	defb	11, 0B01110100
;		      \\/\/\\/
;		       \\ \ \\_ ~TRxC out = XTAL output
;			\\ \ \_ ~TRxC is output pin
;			 \\ \
;			  \\ \_ Tx Clock = BR Generator output
;			   \\
;			    \\_ Rx Clock = DPLL output
;			     \_ ~RTxC = no XTAL

	defb	14,0B11100000
;		     \|/
;		      \
;		       \
;			\
;			 \
;			  \
;			   \_	set NRZI mode

	defb	14,0B10000011
;		     \|/\\\\\_ enable BR Generator
;		      \  \\\\_ BR Generator Source (maybe should be 1???)
;		       \  \\\_ ~DTR function
;			\  \\_ no auto echo
;			 \  \_ local loopback
;			  \
;			   \
;			    \_ set source = BR Generator

	defb	4,0B10100000
;		    \/\/\/\/
;		     \ \ \ \_ no parity
;		      \ \ \
;		       \ \ \_ sync modes enable
;			\ \
;			 \ \_ SDLC mode
;			  \
;			   \_ X32 clock

	defb	12,48		;BR Generator Time constant = 48
	defb	13,0		;This gives baud rate of 5000 baud
;				XTAL frequency = 16 MHz
;				Hence:
;				baud rate = 1 / (2 * (time constant + 2) *
;					(BR clock period))
;				BR clock period = 32 / XTAL frequency
;						= 1 / 500 kHz
;				baud rate = 1 / (2 * (48 + 2) / 500 kHz)
;					  = 500 kHz / (2 * (48 + 2))
;					  = 5000 baud

	defb	6,  0B00000000	;SDLC Address = 0

	defb	7,  0B01111110	;SDLC

	defb	10, 0B10110001
;		      \\/\\\\\_ 8 bit sync
;		       \\ \\\\_ not in loop mode
;			\\ \\\_ flag on underrun
;			 \\ \\_ flag idle
;			  \\ \_ go active on poll
;			   \\
;			    \\_ NRZI
;			     \_ CRC Preset 1
	defb	3,  0B11101001
;		      \/\\\\\\_ Rx Enable
;		       \ \\\\\_ Sync Character Load Enable
;			\ \\\\_ no Address Search Mode
;			 \ \\\_ Rx CRC Enable
;			  \ \\_ not in hunt mode
;			   \ \_ Auto Enables
;			    \
;			     \_ Rx 8 bits / character

	defb	5,  0B11101011
;		      \\/\\\\\_ Tx CRC enable
;		       \\ \\\\_ RTS = 1
;			\\ \\\_ SDLC
;			 \\ \\_ Tx Enable
;			  \\ \_ BREAK off
;			   \\
;			    \\_ Tx 8 bits / character
;			     \_ DTR = 1
s1bnc:	equ	26

; test the status of the keyboard. Returns the character ready or
;  0 if none are ready
;
tstat:
	pshs	x
	ldx	aciain
	lda	#RCVSTA
	bita	astat,x
	beq	nred
	lda	adata,x
	puls	x,pc
nred:	clra
	puls	x,pc

;
; interrupt vectors
;
	org	$fff2
sw3vec: defw	sw3
sw2vec: defw	sw2
firqvc: defw	fastio
irqvec: defw	io
sw1vec: defw	sw1
nmivec: defw	nio
; restart vector
resvec: defw	start
