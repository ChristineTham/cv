/*
 * %W% (%G% %U%)
 *
 * Receives an SDLC packet from the SDLC channel
 *
 * christie
 */

#include "config.h"
#include "ports.h"
#include "scc.h"
#include "sdlc.h"

char	rxany[10] =
	{
		8,
		/* reset DPLL missing clock */
		14, W_RSTMCLK | W_BRGSRC | W_BRGEN,
		/* enter DPLL search mode */
		14, W_ENTSEARCH | W_BRGSRC | W_BRGEN,
		/* enable receiver and put into hunt mode */
		W_RSTERR,
		W_RSTRXCRC,
		3, W_RX8BITS | W_ENTHUNT | W_RXCRCEN | W_RXEN
	};

char	rxaddr[10] =
	{
		8,
		/* reset DPLL missing clock */
		14, W_RSTMCLK | W_BRGSRC | W_BRGEN,
		/* enter DPLL search mode */
		14, W_ENTSEARCH | W_BRGSRC | W_BRGEN,
		/* enable receiver and put into hunt mode */
		W_RSTERR,
		W_RSTRXCRC,
		3, W_RX8BITS | W_ENTHUNT | W_RXCRCEN | W_ADRSEARCH | W_RXEN
	};

char	endrxp[4] =
	{
		2,
		/* disable transmitter */
		3, W_RX8BITS
	};

int
rxpacket(addr, control, size, data)
char	*addr, *control;
int	*size;
char	*data;
{
	/*
	 * Receive packet from address in addr into array data.
	 * assumes receiver is currently in search mode
	 * data must be large enough to hold packet.
	 * Function stores address, control field, and size of packet
	 * received into the location pointed to by the pointers
	 * addr, control, and size respectively.
	 * Function returns status of receive
	 * i.e. either an error status or number of residue bits in
	 * last character
	 */

	char	*statreg;
	int	status;
	char	ch;

	statreg = P_SDLC + R_STATUS;
	/* size has to be 'negative' to account for address and status */
	*size = -1;

	do
	{
		/* wait for character to be available */
		/* store byte */
		ch = PORTget(P_SDLC);
		switch ((*size)++)
		{
		case	-1:
			/* store address character */
			*addr = ch;
			break;

		case	0:
			/* store control character */
			*control = ch;
			break;

		default:
			/* store data character */
			*data++ = ch;
		}


		/* address register 1 */
		*statreg = 1;
		/* get status of last receive */
		status = *statreg;
	} while (!(status & (R_ENDFRAME | R_CRCFERR | R_RXORUN)));

	/* check for any errors that have occured */
	switch (status)
	{
	case	R_CRCFERR:
		/* CRC/Frame error */
		status = E_CRCFERR;
		break;

	case	R_RXORUN:
		/* receiver overrun error */
		status = E_RXORUN;
		break;

	default:
		/* get residue code */
		status = (status & R_RESIDUE) >> 1;
	}

	/* get last character */
	*data++ = PORTget(P_SDLC);
	(*size)++;

	/* disable receiver */
	SCCprogram(P_SDLC, endrxp);

	return status;
}

void
searchany()
{
	/* Enable the receiver and make it search for any packet */

	SCCprogram(P_SDLC, rxany);
}

void
searchaddr(addr)
char	addr;
{
	/* Enable the receiver and make it search for a particular address */

	char	*statreg;

	statreg = P_SDLC + R_STATUS;
	*statreg = 6;	/* SCC SDLC address register */
	*statreg = addr;

	SCCprogram(P_SDLC, rxaddr);
}
