/*
 * %W% (%G% %U%)
 *
 * Include file for MIDI/SDLC transmitter/receiver board port functions
 *
 * christie
 */

/* Addresses of SCC chips defined in config.h as SCC0 and SCC1 */

/* Port registers */
#define	R_STATUS	0
#define	R_DATA		1


/* Port flags */
#define	F_CHARAVAIL	01
#define	F_TXREADY	04
#define	F_DCD		010
#define	F_CTS		040
#define	F_TXEOM		0100

/* Baud Rate Generator constant for SCC 0 */
#define	BR_CONS0	1152		/* 3.6864MHz / 16 / 100 / 2 */
/* Baud Rate Generator constant for SCC 1 */
#define	BR_CONS1	3125		/* 10MHz / 16 / 100 / 2 */

/* Macro functions */

/* Test to see if character available from port */
#define PORTrxready(p)		(*(p + R_STATUS) & F_CHARAVAIL)

/* Test to see if Ok to send character to port */
#define PORTtxready(p)		(*(p + R_STATUS) & F_TXREADY)

/* Set port to raw (9600 baud 8 bits no parity 1 stop bit) mode */
#define	PORTsetraw(p)		SCCprogram(p, p_raw)

/* Set port to cooked (9600 baud 7 bits even parity 1 stop bit) mode */
#define	PORTsetcooked(p)	SCCprogram(p, p_cooked)

/* Enable and disable interrupts on SCC and/or port */
#define	SCCenableint(p)		SCCprogram(p, p_enint)
#define	SCCdisableint(p)	SCCprogram(p, p_disint)
#define	PORTenableint(p)	SCCprogram(p, p_penint)
#define	PORTdisableint(p)	SCCprogram(p, p_pdisint)
