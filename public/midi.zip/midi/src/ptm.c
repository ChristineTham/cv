/*
 * %W% (%G% %U%)
 *
 * Motorola MC6840 PTM functions
 *
 * christie
 */

#include "config.h"
#include "ptm.h"

void
PTMinit()
{
	/* Initializes the three timers to continuous, enable clock */
	/* 16 bit counter operating mode and starts timer */
	/* Timer 1 has interrupts enabled */
	/* Timers 2 & 3 have outputs enabled */

	char	*PTMreg;

	PTMreg = C_CR2;

	*PTMreg = C2_WRITE3;

	/* duration single shot counter */
	PTMreg = C_CR13;
	*PTMreg =	C3_CDIV1 |
			C_ENCLOCK |
			C_COUNT16 |
			C_SSHOTL |
			C_INTDIS |
			C_TOUTEN;

	/* frequency continuous counter */
	PTMreg = C_CR2;
	*PTMreg =	C2_WRITE1 |
			C_ENCLOCK |
			C_COUNT16 |
			C_CONTL |
			C_INTDIS |
			C_TOUTEN;

	/* MIDI event continuous counter */
	PTMreg = C_CR13;
	*PTMreg =	C1_START |
			C_ENCLOCK |
			C_COUNT16 |
			C_CONTL |
			C_INTEN |
			C_TOUTDIS;
}

void
PTMwritelatch(timer, value)
char	*timer;
int	value;
{
	/* writes to counter latch for timer specified */

	*timer++ = value / 256;
	*timer = value % 256;
}

void
PTMreadcounter(timer)
char	*timer;
{
	/* reads the counter of the timer specified */

	int	val;

	val = *timer++ * 256;
	val += *timer;

	return val;
}
