/*
 * %W% (%G% %U%)
 *
 * Sends SDLC frames across a channel (high-level)
 * Allows user to send S-, I- and U-frames
 *
 * christie
 */

#include "config.h"
#include "sdlc.h"

void
senduframe(addr, cr, pf, size, data)
char	addr;
int	cr, pf, size;
char	*data;
{
	/*
	 * sends a U-frame (unnumbered) or nonsequenced frame.
	 * addr is the address of the station
	 * cr	is the command/response type
	 * pf	is the poll/final bit
	 * size	is the size of the data frame
	 * data	is the data frame
	 */

	int	info;

	info = cr + U_IDENT;
	if (pf)
		info += PF_BIT;

	txpacket(addr, info, size, data);
}

void
sendsframe(addr, seq, pf, mode)
char	addr;
int	seq, pf, mode;
{
	/*
	 * sends an S-frame (supervisory) frame.
	 * addr is the address of the station
	 * seq	is the sequence number of the frame (0 to 7)
	 * pf	is the poll/final bit
	 * mode	is the supervisor control
	 */
	
	int	info;

	info = seq * RSEQ_OFF + mode * MODE_OFF + S_IDENT;
	if (pf)
		info += PF_BIT;

	txpacket(addr, info, 0, (char *)0);
}

void
sendiframe(addr, rseq, sseq, pf, size, data)
char	addr;
int	rseq, sseq, pf, size;
char	*data;
{
	/*
	 * sends an I-frame (information transfer) frame.
	 * addr is the address of the station
	 * rseq	is the receiver sequence number of the frame (0 to 7)
	 * sseq	is the sender sequence number of the frame (0 to 7)
	 * pf	is the poll/final bit
	 * size	is the size of the data frame
	 * data	is the data frame
	 */
	
	int	info;

	info = rseq * RSEQ_OFF + sseq * SSEQ_OFF + I_IDENT;
	if (pf)
		info += PF_BIT;

	txpacket(addr, info, size, data);
}
