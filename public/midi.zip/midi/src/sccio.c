/*
 * %W% (%G% %U%)
 *
 * SCC programs
 *
 * christie
 */

#include "config.h"
#include "ports.h"
#include "scc.h"

/* See scc.h for documentation */

char	p_raw[8] =
	{
		6,
		4, W_CLKX16 | W_STOP1,
		3, W_RX8BITS | W_AUTOEN | W_RXEN,
		5, W_DTR | W_TX8BIT | W_TXEN | W_RTS
	};

char	p_cooked[8] =
	{
		6,
		4, W_CLKX16 | W_STOP1 | W_PEVEN | W_PARITYEN,
		3, W_RX7BITS | W_AUTOEN | W_RXEN,
		5, W_DTR | W_TX7BIT | W_TXEN | W_RTS
	};

char	p_enint[4] =
	{
		2,
		9, W_MIE | W_NV
	};

char	p_disint[4] =
	{
		2,
		9, 0
	};

char	p_penint[6] =
	{
		4,
		1, W_RXINTAS | W_PARSC | W_TXINTEN | W_RXINTEN,
		15, W_BRKABIE | W_DCDIE
	};

char	p_pdisint[6] =
	{
		4,
		1, 0,
		15, 0
	};


void
SCCprogram(p, s)
char	*p, *s;
{
	/* Programs SCC port p with character string s */
	/* The first character of s is the number of bytes to program */

	int	count;
	
	count = *s++;
	p += R_STATUS;
	while (count--)
		*p = *s++;
}
