/*
 * %W% (%G% %U%)
 *
 * Test Zilog Z8530 SCC 1 MIDI Channel B
 *
 * Puts MIDI port into loopback mode
 * Gets string from terminal
 * Sends string to port and verify correct reception in loopback mode
 * Beeps for every character not received correctly.
 *
 * christie
 */

#include "config.h"
#include "ports.h"
#include "scc.h"

char	loopback[] =
	{
		2,
		14,
		W_LLOOPBACK | W_BRGSRC | W_BRGEN
	};

main()
{
	char	str[80];
	char	*s;

	SCCprogram(P_MIDI, loopback);

	for (s = str; *s != '\n' || *s != '\r'; s++)
		*s = PORTget(P_TERMINAL);
	*s = '\0';

	s = str;
	while (*s)
	{
		PORTput(P_MIDI, *s);
		if (PORTget(P_MIDI) != *s)
			PORTput(P_TERMINAL, 'G' - '@');
		s++;
	}
	exit(0);
}
