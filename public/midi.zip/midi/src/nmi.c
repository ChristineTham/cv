/*
 * %W% (%G% %U%)
 *
 * NMI software vector
 *
 * christie
 */

#define	NOEXTNMIVEC

#include "config.h"

int	*nmivec = RAMEND - 14;
