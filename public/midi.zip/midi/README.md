# MIDI & SDLC hardware board

A Motorola 6809 microprocessor board that does two unrelated jobs: it records and
plays back MIDI, and it acts as an SDLC station toolkit. One board, one report,
submitted for two courses at once.

CS Honours 1987, Basser Department of Computer Science, University of Sydney —
a joint report for **Computer Networks** (Dr Robert Kummerfield) and
**Microprocessor Systems** (Dr Doan Hoang).

## Authors

A five-person group project: **Michael Barr-David** (hardware design and
construction, project leader), **Fred Holmberg** (hardware construction,
debugging), **Jason Lo** (SDLC station documentation), **Chris Tham** (SCC
monitor modifications, interrupt and low-level device software, hardware
test-out software, MIDI documentation) and **Jarryl Wirth** (MIDI software
design and implementation, user guide).

Unlike the other reconstructions here, most of this is not the work of one
author. The division of labour is set out in `doc/workdiv.mm`.

## What the board does

**As a MIDI recorder** it sits between MIDI instruments and a host minicomputer —
a PDP-11/84 or the VAX 11/780 — connected through the Satellite Coprocessor
system. MIDI data is captured to host files in real time and can be streamed back
out to the instruments: the digital equivalent of a tape recorder, in the
report's own words. What it stores are note events rather than audio, so a piece
can be played back on a different instrument, or at a different tempo without the
pitch shifting.

**As an SDLC station toolkit** the same board transmits and receives SDLC frames
over a synchronous channel, as a deliberately open-ended set of low-level
functions from which a primary or secondary station can be assembled.

Hardware: MC6809 at 1 MHz, 8K ROM, 32K RAM, two Zilog Z8530 SCCs providing four
serial channels (terminal, host link, MIDI, SDLC), and an MC6840 PTM for timing —
which also drives a metronome. SDLC runs NRZI at 1953.125 baud, derived from a
10 MHz crystal through the SCC's baud rate generator and digital phase-locked
loop.

## Layout

| Here | From | What it is |
| :-- | :-- | :-- |
| `doc/` | `christie/hons/midicpio/midi/doc/` | the fullest document set, 16 troff chapters and its own Makefile |
| `src/` | `christie/hons/midi/` and `midicpio/midi/` | board software: C, headers, 6809 assembly |
| `notes/` | `christie/hons/midi/jason` | reference summaries of HDLC, SDLC and SCC interrupts |
| `drafts/` | `christie/hons/midi/`, `hons/midi/final/` | two earlier drafts of the document set |

`doc/` is preferred because it is the only set with `hwintro.mm`, `midinet.mm`,
`sw.mm`, `user.mm` and `workdiv.mm`, and because it came through cpio with its
Unix filenames intact. The two draft sets in `drafts/` differ from it and from
each other.

The C and assembly survive only in the DOS copies, and are byte-for-byte
identical between `hons/midi/` and `hons/midi/final/` — those two differ in their
documents alone. Where a file exists in both the DOS copy and the Unix cpio, the
cpio version is used here: `monitor.s` differs between them by three bytes.
`monitor.new` is a further revision of it.

`notes/` was recovered from `jason`, a Unix `ar` archive sitting loose in the DOS
directory.

## Its companion project

The user guide, `doc/user.mm`, works through what you could feed the board, and
gives as its example a compiler for the RUBATO musical description language —
named there as an honours project being developed alongside this one, which with
a suitable back end could turn pieces of arbitrary complexity into MIDI data
files to drive any number of instruments.

That project is reconstructed in [`../rubato/`](../rubato/). Rubato was the
language and the front end; this board was the path from a description of music
to instruments actually playing it.

## Building the documents

Troff `-mm`, as written for a VAX 11/780 running UNIX V8.

```sh
cd doc && cat start.mm intro.mm hwintro.mm hardware.mm sccdes.mm midi.mm \
    midinet.mm sdlc.mm sdlcdes.mm hdlcdes.mm lowlevel.mm sdlclow.mm \
    sw.mm user.mm workdiv.mm end.mm | tbl | nroff -mm | less
```
