.H 1 "DESCRIPTION OF SDLC PROTOCOL"
.P 1
SDLC (Synchronous Data Link Control)
is a bit oriented, full/full duplex, serial by bit transmission,
centralized control, synchronous, data communications message protocol.
.P 1
The SDLC-Format is of the form Flag-Address-Control-Info-CRC-Flag.
The first set of bits to be generated in the format is called a "flag". The
configuration of this flag byte is always 01111110, and this sequence will
never be repeated again throughout the entire message transmission until the
end flag with the same configuration is transmitted. In order to ensure this
operation every time, when a sequence of five 1 bits in a row is recognised by
the transmit hardware after a start flag is generated, an extra 0 bit will be
added to the bit stream between the fifth 1 bit and the next bit, regardless
of whether that next bit is 0 or 1. This technique is called "zero stuffing".
The hardware at the receive end will always remove a 0 which is detected after
five consecutive 1 bits before being passed on to the recognition logic. The
only time 01111110 can occur in between the start flag and the end flag is due
to a transmission error. In this case, the receive hardware assumes that second
flag is preceeded by a 16-bit CRC check sequence. When the calculated CRC at
the receive end is compared with the assumed CRC which resulted from the 
transmission error, they will be found to be different, the message is
determined to be in error and will have to be retransmitted.
.P 1
The next byte after the start flag is the "address byte", which consists
of 8 bits giving 256 combinations. The address byte allows 128 unique addresses
to be accomodated on every single individual communication line in the network,
but because the probability of using that many on one line is extremely remote
(16 being a practical limit), many of the other vendors who have the SDLC type
protocols have taken bits from the address byte to use for other functions.
These other functions could be used for more control or for transmission of
more blocks of information before an acknowledgement must be received.
.P 1
The third byte of the format is called "control byte". The control byte
can have any one of three different formats depending on what is to be
transmitted. If bit "0" is a 0, this is called an "information transfer format".
If bits "0" and "1" are a 1 and a 0, it is a "supervisory format"; and if bits
"0" and "1" are a 1 and a 1, it is called a "nonsequenced format". When bit "0"
is 0, the next three bits identify the sequence number (Ns = 000 through 111) 
of the block being transmitted (by either the master or the slave). Since there
are 8 combinations available for 3 bits, this means that no more than 8 blocks
of information can be sent before this segment will start repeating itself.
.P 1
The next bit in the control character is the same for all three formats;
it is called P/F bit. What this means is that when being transmitted from the
master location it is called a P bit and if set to 1, identified as a "poll
message". If set to 0 this is not a poll message, and the slave which is being
addressed should not answer. If coming from a slave location it is called an
F bit (final message of a sequence), and if it is a 0, then at least one more
block of information will be following the block in which this control character
is contained. If F bit is a 1, this block will be the last block in the present
sequence to be transmitted by that slave site.
.P 1
The last three bits of the control byte contained in the information
transfer format is the next block number (Nr = 000 through 111) which the
transmitting end (master or slave) expects to get from the other end the next
time a transmission takes place.
.P 1
For the supervisory format, where bits "0" and "1" are a 1 and a 0, the
next two bits are defined as the "mode", they are either receive-ready (RR) when
00, receive not ready (RNR) when 10, or reject (REJ) when 01. These are controls
which are used to identify whether a particular terminal can receive or not. The
next bit is P/F and the last three bits is Nr, they are the same as for
information transfer format.
.P 1
Nonsequenced format is now called Unnumbered format. It is defined by
bits "0" and "1" of the control byte being 1 and 1. When the nonsequenced format
is identified, then bit numbers 2,3,5,6,7 must be looked at together as being a
command or a response. The commands are Nonsequeced Information (NSI = 000-00),
Set Normal Response Mode (SNRM = 001-00), Disconnect (DISC = 010-00), Optional
Response Poll (ORP = 100-00), and Set Initialization Mode (SIM = 000-10). The
responses are Nonsequenced Information (UI = 000-00), Nonsequence
Acknowledgement (UA = 100-00), Request for Initialization (RIM = 000-10),
Command Reject (FRMR = 001-10), and Request Online (DM = 000-11). Nonsequenced
formats are used primarily for establishing the initial synchronization and
for ultimate disconnecting of a terminal site.
.P 1
The next segment in SDLC format is the Information Portion. This is the
segment of the transmission which is the total user transmission and starts with
the user's first character and ends with the user's last character. Information
is of variable length for Information Transfer format, prohibited for
Supervisory format, variable length for Nonsequenced format with NSI, and fixed
format with the use of the command reject (FRMR) response by a slave to the
master.
.P 1
Following the information portion is the CRC (cyclic redundancy check),
in which all transmission integrity functions are included. It is also called
the frame check sequence and guarantees, to an extremely high reliability, the
fact that the transmission is correct.
.P 1
After the SDLC CRC is the final flag byte. This final flag identifies
the end of the present block and a new flag sequence must be transmitted to
initiate the next message or block.
