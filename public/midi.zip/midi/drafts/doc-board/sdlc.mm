.H 1 "DESCRIPTION OF THE SDLC INTERFACE FUNCTIONS"
.P 1
The SDLC interface on the board is implemented as a set of open ended
functions that allow the hardware board to function as an SDLC primary /
secondary data station with proper programming.
.P 1
The SDLC physical layer
consists of an serial communications channel connected to a standard RS-232
25 pin connector configured as a DTE (Data Terminal Equipment).
The serial communications channel on the board consists of 1 channel
(Channel A) of a Zilog Z8530 SCC (Serial Communications Controller) chip.
Information is transferred through the physical layer in NRZI (Non Return
to Zero Inverted) synchronous mode at 1953.125 baud.  Other baud rates may
be chosen by suitable reprogramming of the SCC chip.  The clock driving the
SDLC Channel on the SCC chip is a 10 MHz crystal and the baud rate is
obtained by dividing down the crystal frequency using an osciallator
circuit and baud rate generator internal to the SCC chip.  The output of
the baud rate generator is then used to drive the internal DPLL (Digital
Phase Locked Loop) hardware
which is then used to generate the SDLC baud rate.
.P 1
Low level functions have been written to allow SDLC frames to be sent and
received from the SDLC channel.  These functions are completely open-ended
and allow for a wide variety of SDLC and HDLC operating modes to be
implemented.  In addition to functions allowing raw SDLC frames to be
transmitted and received, functions have been written to transmit frames in
any of the defined SDLC frame formats (Information transfer, supervisory,
or unnumbered).  A frame received may be decoded into a frame format by a
decoding function.  For example, with proper programming, the SDLC interface on
the board may allow the board to become an SDLC or HDLC data station acting
as a primary or secondary.  The station may be programmed in HDLC Normal
Response Mode or HDLC Asynchronous Response Mode.
.P 1
For a description of the low level SDLC functions implemented, refer to the
section entitled
.B "SDLC Low Level Routines"
and
.B "SDLC Low Level Function Descriptions" .
These functions employ the low-level hardware dependent functions that
isolates the board's hardware idiosyncracies from software.  See sections
entitled
.B "Low Level Functions"
and
.B "Low Level Function Descriptions" .
.H 1 "EXAMPLE OF SDLC PRIMARY DATA SOURCE"
.P 1
The proper way of enabling the board as an SDLC station is to write a
program in Tiny C (a subset of the C programming language) that implements
an SDLC controller and using the low level SDLC functions defined in this
project to send and receive SDLC frames.
.P 1
As an example, consider the following code, which allows the board to act
as an SDLC NRM primary station with the primary acting as a data source:
.P 1
The code initializes the data link in Normal Response Mode (NRM) and then
sends information frames while scanning for acknowledgement.  The address
of the primary station is 1 and the address of the secondary station is 2.
In order to make the example as simple as possible, the following
simplifications have been introduced:
.AL
.LI
There is only one secondary.
.LI
The primary sets the data link to NRM and then sends a number of data
frames followed by a DISCONNECT command.
.LI
A simple stop and wait protocol is used.  Hence the sender and receiver
sequence numbers are always zero.  After sending an information frame, the
primary waits until acknowlegment is received.
.LI
The secondary is always ready and never rejects Unnumbered commands.
.LI
In response to a data frame, the secondary never transmits a Receiver Not
Ready (RNR) response.
.LI
There is a function called getbuffer() which simply gets a frame of data of
size BUFFER from the host.
If the size returned by the function is not BUFFER, then the
host has run out of buffers to send.
.LI
There are functions called waitACK() and waitres() which simply sets a
timer and then waits for a response from the secondary.  If a response is
found, waitACK() and waitres() decodes the control field of the U-frame
and S-frame respectively and returns the mode/response, else R_TIMEOUT is
returned.  These functions can be written quite easily using the low level
timer functions and an NMI handler and the low level SDLC functions.
.LE
.DS

#include "config.h"
#include "sdlc.h"

#define PRIMARY         1
#define SECONDARY       2

#define BUFFER          512     /* frame size */

char    data[BUFFER];

main()
{
        int     res, size;
        boolean done;

        /* enable receiver */
        searchaddr(SECONDARY);

        /* initialize to NRM mode */
        done = FALSE;
        while (!done)
        {
                senduframe(PRIMARY, CR_SNRM, TRUE, 0, 0);

                /* get response from secondary */
                switch(res = waitACK())
                {
                case    CR_UA:
                        /* Acknowledgment */
                        done = TRUE;
                        break;

                case    R_TIMEOUT:
                        /* acknowledgment timeout */
                        break;
                }
        }

        /* now start transmitting frames with info */
        do
        {
                size = getbuffer(data);

                done = FALSE;
                while (!done)
                {
                        sendiframe(PRIMARY, 0, 0, TRUE, size, data);

                        /* enable receiver */
                        searchaddr(SECONDARY);

                        /* receiver replies */
                        switch (res = waitres(SECONDARY))
                        {
                        case    MODE_REJ:
                        case    R_TIMEOUT:
                                /* timeout or reject */
                                break;

                        case    MODE_RR:
                                done = TRUE;
                        }
                }
        } while (size == BUFFER);

        /* enable receiver */
        searchaddr(SECONDARY);

        /* disconnect */
        done = FALSE;
        while (!done)
        {
                senduframe(PRIMARY, CR_DISC, TRUE, 0, 0);

                /* get response from secondary */
                switch(res = waitACK())
                {
                case    CR_UA:
                        /* Acknowledgment */
                        done = TRUE;
                        break;

                case    R_TIMEOUT:
                        /* acknowledgment timeout */
                        break;
                }
        }
}

.FG "Simple stop and wait example"
.DE
.P 1
The above example is then compiled on the host development machine and
linked in with the low level functions to form a target binary.  The binary
can then be downloaded into the board and enables the board to function in
the manner specified.  The example above can be extended for a real
application.
