SCC INTERRUPTS :
	There are three types of interrupts in the SCC : Transmit, Receive and
External/Status. Each interrupt type is enabled under program control with
channel A having higher priority than channel B, and with Receive, Transmit
and External/Status interrupts prioritized in that order with each channel.
	When Transmit interrupt is enabled, the CPU is interrupted when the transmit
buffer becomes empty. The receiver then can interrupt the CPU in one of three
ways :
	(1) Interrupt on First Receive character or Special Receive Condition.
	(2) Interrupt on All Receive character or Special Receive Condition.
	(3) Interrupt on Special Receive Condition Only.
	(1) and (3) are typically used with Block Transfer mode. A Special 
Receive Condition is one of the following : receive overrun, framing error (in
Asynchronous mode), end-of-frame (in SDLC mode) and a parity error (optionally).
An interrupt can occur from Special Receive Condition any time after the First
Receive character interrupt.
	External/Status interrupt is to monitor the signal transitions of the CTS, DCD
and SYNC pin; It is also caused by a Transmit Underrun condition, or a zero
count in the baud rate generator, or by the detection of a Break (Asynchronous
mode), or Abort (SDLC mode), or EOP (SDLC Loop mode).
	When the SCC responds to an Interrupt Acknowledge signal (INTACK) from the CPU,
an interrupt vector is placed on the data bus. This vector is written in WR2
and may be read in RR2A or RR2B.
	Three bits in this vector can be modified to indicate status, so can speed
interrupt response time as if the vector is read in channel A , status is never
included; if it is read in channel B, status is always included.
	Two bits are related to the interrupt priority chain. As a microprocessor
peripheral, the SCC may request an interrupt only when no higher priority
device is requesting one, e.g. when IEI is high.
	Each of the six sources of interrupts in SCC (Transmit, Receive and 
External/Status in both channels) has the other three bits associated with the
interrupt sources : Interrupt Pending (IP), Interrupt Under Service (IUS) and 
Interrupt Enable (IE).
	The IE bit is set for a given interrupt source, indicates that source can
request interrupts except when MIE (Master Interrupt Enable) bit in WR9 is
reset and no interrupts may be requested, the IE bits are write only.
	The IP bit signals a need for interrupt servicing, when an IP bit is 1 and the
IEI input is high, the INT output is pulled low, requesting an interrupt. If
the IE bit is not set by enabling interrupts, then the IP for that source can
never be set. The IP bits are readable in RR3A.
	The IUS bit signals that an interrupt request is being serviced. If an
IUS is set, all interrupt sources of lower priority in the SCC and external to
the SCC are prevented from requesting interrupts.

ARCHITECTURE OF SCC
	The SCC internal structure includes two full-duplex channels, two baud rate
generators, internal control and interrupt logic, and a bus interface to a
nonmultiplexed bus. Associated with each channel are a number of read and
write registers for mode control and status information, as well as logic
necessary to interface to modems or other external devices.
	The logic for both channels provides formats, synchronization, and validation
for data transferred to and from the channel interface. The modem control
inputs are monitored by the control logic under program control.
	The register set for each channel includes ten control (write) registers, and
four states (read) registers. In addition, each baud rate generator has two
(read/write) registers for holding the time constant that determines the baud
rate. Associated with the interrupt logic is a write register for the 
interrupt vector accessible through either channels, a write only Master
Interrupt Control register and three read registers : one containing the 
vector with status information (channel B only), one containing the vector
without status (channel A only), and one containing the Interrupt Pending 
bits (channel A only).
	The registers for each channel are designated as follows:
	Write Registers : WR0-WR15.
	Read Registers  : RR0-RR3,RR10,RR12,RR13,RR15.
The SCC contains only one WR2 and WR9, but they can be accessed by either
channel. All other registers are paired (one for each channel).

