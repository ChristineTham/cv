.HU "Appendix A: Circuit Schematic"
.HU "Appendix B: Board Layout"
.HU "Appendix C: Memory Map"
.HU "Appendix D: Parts Listing"
.HU "Appendix E: Program Listings"
.HU "Appendix F: Summary of the Zilog Z8530 SCC"
.HU "Appendix G: Data Sheets"
.TC
.CS
