/*
 *	MPU401IO.C
 *
 *	Very Low Level Routines to access the Roland MPU 401 MIDI Processing
 *	Unit.  This consists of a set of functions that perform low-level
 *	I/O to and from the MPU 401 using the IBM PC interface card.
 *
 *	The routines are written in C, but can be replaced by assembler
 *	routines for efficiency.  These routines currently do not make use
 *	of the ability of the interface card to request an 8088 interrupt
 *	using the IRQ2 line in the IBM PC bus.  Hence polling is performed
 *	to determine if the MPU is ready to send a character.  It is
 *	anticipated that in the very near future an interrupt driven set of
 *	routines to access the Roland MPU 401 will be developed in assembler.
 *
 *	christie
 */

#include "mpu401.h"

byte
getdata()
{
	/*
	 *	This function gets a data byte from the MPU 401.  It hangs
	 *	until the MPU 401 is ready to send a character (very
	 *	inefficient but this will soon be cured by using interrupt
	 *	driven routines
	 */

	while (inp(STATPORT) & NOTDSR)
	 	;
	return (byte)inp(DATAPORT);
}

void
putcmd(cmd)
byte cmd;
{
	/*
	 *	This functions puts out a single MPU command to the
	 *	command port.  Then polling is done to receive the ACK signal
	 *	from the MPU.  If some other signal besides ACK is received,
	 *	then the function jumps to mpuexcept() in order to process
	 *	the MPU message received.
	 */

	byte d;

	while (inp(STATPORT) & NOTDRR)
	 	;
	outp(COMPORT, cmd);
	while ((d = getdata()) != MS_ACK)
		mpuexcept(d);
}

void
putdata(data)
byte data;
{
	/*
	 *	This function puts out a single MPU data byte to the
	 *	data port.  Polling is performed until the MPU is truly
	 *	ready to receive the data
	 */

	while (inp(STATPORT) & NOTDRR)
		;
	outp(DATAPORT, data);
}

byte
putcmd1(command)
byte command;
{
	/*
	 *	This function puts out a single command byte the the MPU
	 *	and then expects a one character data byte to be returned
	 *	by the MPU (in addition to the normal MS_ACK message)
	 *	The functions putcmd() and getdata() are used.
	 */

	putcmd(command);
	return getdata();
}

mpuexcept(message)
byte message;
{
	/*
	 *	This function accepts a message data in the argument list
	 *	and attempt to act upon the data received.
	 *	The following high-level function calls MUST be defined:
	 *	dosavedata(message)	- saves data into record buffer
	 *	doplayreq(message)	- process a play request
	 *	dotimeoflow()		- process timing overflow data
	 *	docondreq()		- process conductor request
	 *	doallend()		- all tracks finished playing
	 *	doupdclock()		- update clock count
	 *	dosystemrx()		- save system (exclusive) data
	 *	dopanic()		- Danger Danger Will Robinson!
	 */

	if (message < MS_TRACKREQ)
		dosavedata(message);
	else if ((message & 0xf8) == MS_TRACKREQ)
		doplayreq(message);
	else
		switch(message)
		{
		case	MS_TIMEOVERFLOW:
			dotimeoflow();
			break;
		case	MS_CONDUCTREQ:
			docondreq();
			break;
		case	MS_ALLEND:
			doallend();
			break;
		case	MS_CLOCKOUT:
			doupdclock();
			break;
		case	MS_ACK:
			/* This shouldn't be here with current impl */
			/*
			doackrx();
			*/
			break;
		case	MS_SYSTEM:
			dosystemrx();
			break;
		default:
			dopanic(message);
			break;
		}
	/* finished processing exception, back to caller */
}
