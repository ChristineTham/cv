/*
 *	MIDI.H
 *
 *	MIDI (Musical Instrument Digital Interface) v1.0 Data Format
 *	definitions for Channel and System messages.
 *
 *	christie
 */

/* Channel Voice messages */
#define MIDI_NOTEOFF	0x80		/* Note Off message */
#define MIDI_NOTEON	0x90		/* Note On message */
#define MIDI_AFTOUCH	0xa0		/* Polyphonic Key Pressure */
					/* (After Touch) */
#define MIDI_CTRLCHANGE	0xb0		/* Control Change */
#define MIDI_PROGCHANGE	0xc0		/* Program Change */
#define MIDI_CHPRESSURE	0xd0		/* Channel Pressure (After Touch) */
#define MIDI_PWCHANGE	0xe0		/* Pitch Wheel Change */

/* Channel Mode messages (MIDI_CTRLCHANGE) */
#define CC_LOCAL	122		/* Local Control */
#define CC_ALLNOTESOFF	123		/* All Notes Off */
#define CC_OMNIOFF	124		/* Omni Mode Off */
#define CC_OMNION	125		/* Omni Mode On */
#define CC_MONOON	126		/* Mono Mode On (Poly Mode Off) */
#define CC_POLYON	127		/* Poly Mode On (Mono Mode Off) */

/* System Messages */
#define MIDI_SYSTEM	0xf0		/* System Exclusive follows */

/* System Common Messages */
#define SC_SONGPTR	0xf2		/* Song Position Pointer */
#define SC_SONGSELCT	0xf3		/* Song Select */
#define SC_TUNEREQ	0xf6		/* Tune Request */
#define SC_EOX		0xf7		/* EOX - End of Exclusive Mode */
