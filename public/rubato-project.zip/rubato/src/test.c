
/*
 *	TEST.C
 *
 *	Very brief testing module for mpu401io.c
 */

#include <stdio.h>
#include "mpu401.h"

/* dummy functions */
dosavedata(mess)
byte mess;
{
	printf("Save Data found! Value = %x\n",mess);
}

doplayreq(mess)
byte mess;
{
	printf("Play request found! Value = %x\n",mess);
}

dotimeoflow()
{
	printf("Timing Overflow!\n");
}

docondreq()
{
	printf("Conductor Request!\n");
}

doallend()
{
	printf("All End!\n");
}

doupdclock()
{
	printf("Clock Message\n");
}

dosystemrx()
{
	printf("System Message follows ...\n");
}

dopanic()
{
	printf("Panic!\n");
}

main()
{
	/* GOTOs considered labor-saving */

	byte choice;

menu:	puts("\n\nMPU 401 Low Level Test Menu");
	puts("\nSelect One of the Following");
	puts("\t[1]Send MPU Command");
	puts("\t[2]Receive MPU data");
	puts("\t[3]Send MPU data");
	puts("\t[4]Exit this program");
select:	printf("\nSelect your choice:");
	scanf("%d", &choice);
	putchar('\n');
	switch (choice)
	{
	case	1:
		dosendcmd();
		break;
	case	2:
		dogetdata();
		break;
	case	3:
		dosenddata();
		break;
	case	4:
		exit(0);
	default:
		puts("That was not a valid choice");
		goto select;
	}
	goto menu;
}

dosendcmd()
{
	byte cmd;

	printf("Enter MPU Command in Hex:");
	if (scanf("%x",&cmd) > 0)
		putcmd(cmd);
}

dogetdata()
{
	int count;

	printf("Data received is %x\n",getdata());
}

dosenddata()
{
	int count;
	byte data;

	printf("Data to send:");
	if (scanf("%x",&data) > 0)
		putdata(data);
}
