/*
 *	INIT.C
 *
 *	Initialization and Option setting for the MPU401 Sequencer Program.
 */

#define MAXCHAN 4

#include <stdio.h>
#include "mpu401.h"
#include "sequence.h"

byte chref;
byte chchan[MAXCHAN];
bool bender;
byte metronome, timebase, tempo, laccchan, haccchan;

char *gets();

doinit()
{
	int choice;

	for (;;)
	{
		puts("\nOPTIONS MENU\n");
		puts("Available functions");
		puts("\t[1]Reset MPU-401");
		puts("\t[2]Set Channel Reference Tables");
		puts("\t[3]Metronome Control");
		puts("\t[4]Bender option");
		puts("\t[5]Set Timebase & Tempo");
		puts("\t[6]Set Acceptable Channels");
		puts("\t[7]Exit back to main menu");
initsel:	printf("Select choice:");
		fflush(stdout);
		if (gets(ibuf) != NULL && *ibuf)
			choice = atoi(ibuf);
		switch (choice)
		{
		case	1:
			setdefs();
			break;
		case	2:
			setchanref();
			break;
		case	3:
			setmetro();
			break;
		case	4:
			setbender();
			break;
		case	5:
			settt();
			break;
		case	6:
			setaccchan();
			break;
		case	7:
			return;
		default:
			goto initsel;
		}
	}
}

setdefs()
{
	register int i;

	chref = 0xf;
	for (i = 0; i <= 3; ++i)
		chchan[i] = i;
	bender = FALSE;
	metronome = 1;
	timebase = 120;
	tempo = 100;
	laccchan = 0xff;
	haccchan = 0xff;
}

setchanref()
{
	register int i;

	for (i = 0; i <= 3; ++i)
	{
		printf("Channel Reference %c (y) On (n) Off", i + 'A');
		printf(" [Default %s] ?", ((chref & (1 << i)) ? "On" : "Off"));
		fflush(stdout);
		if (gets(ibuf) != NULL && *ibuf)
		{
			if (*ibuf == 'y')
				chref |= 1 << i;
			else
				chref &= !(1 << i);
		}
		if (chref & (1 << i))
		{
			int cmd;

			switch (i)
			{
			case	0:
				putcmd(SW_ONCRTA);
				break;
			case	1:
				putcmd(SW_ONCRTB);
				break;
			case	2:
				putcmd(SW_ONCRTC);
				break;
			case	3:
				putcmd(SW_ONCRTD);
				break;
			}
			printf("Set Channel Reference %c", i + 'A');
			printf(" to MIDI Channel [Default %d]:", chchan[i] + 1);
			fflush(stdout);
			if (gets(ibuf) != NULL && *ibuf)
				chchan[i] = atoi(ibuf) - 1;
			chchan[i] %= 16;
			switch (i)
			{
			case	0:
				cmd = SW_REFACH;
				break;
			case	1:
				cmd = SW_REFBCH;
				break;
			case	2:
				cmd = SW_REFCCH;
				break;
			case	3:
				cmd = SW_REFDCH;
				break;
			}
			putcmd(cmd | chchan[i]);
		}
		else
			switch(i)
			{
			case	0:
				putcmd(SW_OFFCRTA);
				break;
			case	1:
				putcmd(SW_OFFCRTB);
				break;
			case	2:
				putcmd(SW_OFFCRTC);
				break;
			case	3:
				putcmd(SW_OFFCRTD);
				break;
			}
	}
}

setmetro()
{
	printf("Current Default is %d\n", metronome);
metsel:	puts("Select one of the following:");
	puts("\t[1]No metronome");
	puts("\t[2]Metronome without accents");
	puts("\t[3]Metronome with accents");
	puts("Any other entry exits back to options menu");
	printf("Choice:");
	fflush(stdout);
	if (gets(ibuf) != NULL && *ibuf)
		metronome = atoi(ibuf);
	switch (metronome)
	{
	case	1:
		putcmd(SW_OFFMETRO);
		break;
	case	2:
		putcmd(SW_ONMETRONA);
		break;
	case	3:
		putcmd(SW_ONMETROACC);
		break;
	default:
		puts("That was not a legal choice!");
		goto metsel;
	}
}

setbender()
{
	printf("Current Default is %c\n", (bender) ? 'y' : 'n');
	printf("Do you want to save bender messages? (y or n) ");
	fflush(stdout);
	if (gets(ibuf) != NULL && *ibuf)
		bender = (*ibuf == 'y');
	if (bender)
		putcmd(SW_ONBENDER);
	else
		putcmd(SW_OFFBENDER);
}

settt()
{
	printf("Current Timebase is %d\n", timebase);
	printf("Current Tempo is %d\n", tempo);
tbsel:	printf("Enter new timebase: ");
	fflush(stdout);
	if (gets(ibuf) != NULL && *ibuf)
		timebase = atoi(ibuf);
	switch (timebase)
	{
	case	48:
		putcmd(SETTB_48);
		break;
	case	72:
		putcmd(SETTB_72);
		break;
	case	96:
		putcmd(SETTB_96);
		break;
	case	120:
		putcmd(SETTB_120);
		break;
	case	144:
		putcmd(SETTB_144);
		break;
	case	168:
		putcmd(SETTB_168);
		break;
	case	192:
		putcmd(SETTB_192);
		break;
	default:
		puts("Illegal Timebase!");
		puts("Select one of 48, 72, 96, 120, 144, 168, 192");
		goto tbsel;
	}
temsel:	printf("Enter new tempo (in bpm): ");
	fflush(stdout);
	if (gets(ibuf) != NULL && *ibuf)
		tempo = atoi(ibuf);
	if (tempo <= 0 || tempo > 255)
	{
		puts("Tempo must be a positive number from 1 to 255!");
		goto temsel;
	}
	putcmd(ST_TEMPO);
	putdata(tempo);
}

setaccchan()
{
	register int i;

	puts("Currently acceptable channels");
	for (i = 0; i <= 7; ++i)
	{
		if (laccchan & (1 << i))
			printf("Channel %2d ", i + 1);
		else
			printf("           ");
		if (haccchan & (1 << i))
			printf("Channel %2d\n", i + 9);
		else
			putchar('\n');
	}
	for (i = 0; i <= 7; ++i)
	{
		printf("Accept Channel %2d? (y or n) ", i + 1);
		fflush(stdout);
		if (gets(ibuf) != NULL && *ibuf)
		{
			if (*ibuf == 'y')
				laccchan |= (1 << i);
			else
				laccchan &= !(1 << i);
		}
	}
	for (i = 0; i <= 7; ++i)
	{
		printf("Accept Channel %2d? (y or n) ", i + 9);
		fflush(stdout);
		if (gets(ibuf) != NULL && *ibuf)
		{
			if (*ibuf == 'y')
				haccchan |= (1 << i);
			else
				haccchan &= !(1 << i);
		}
	}
}
