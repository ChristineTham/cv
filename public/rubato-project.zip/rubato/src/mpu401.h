/*
 *	MPU401.H
 *
 *	Include file for constants defining commands and port values in the
 *	Roland MPU 401 MIDI Processing Unit.
 *
 *	christie
 */

/* Some useful constants */
#define FALSE 0
#define TRUE (!FALSE)

/* Some useful type definitions */
typedef char		bool;	/* simulated boolean type */
typedef unsigned char	byte;	/* 8 bit value */
typedef unsigned short	word;	/* 16 bit word */
typedef unsigned long	lword;	/* 32 bit word */

/* port values for the MPU 401 as seen through the IBM PC interface card */
#define STATPORT 0x331		/* port for reading status */
#define COMPORT STATPORT	/* the port for sending commands */
#define DATAPORT 0x330		/* port for sending and receiving data */

/* Status bits in STATPORT */
#define NOTDSR 0x80		/* NOT Data Set Ready - if this bit is set */
				/* then MPU has no data to send */
#define NOTDRR 0x40		/* NOT Data Receive Ready - if set then */
				/* MPU401 not ready to receive data */

/* MPU Marks */
#define M_NOP		0xf8	/* No Operation */
#define M_MEASUREEND	0xf9	/* Measure End Mark */
#define M_DATAEND	0xfc	/* Data End Mark */

/* MPU Messages */
#define MS_TRACKREQ	0xf0	/* Track Request */
				/* Low 3 bits denote actual track requesting */
#define MS_TIMEOVERFLOW	0xf8	/* Timing Overflow */
#define MS_CONDUCTREQ	0xf9	/* Conductor Data Request */
#define MS_ALLEND	0xfc	/* All End */
#define MS_CLOCKOUT	0xfd	/* Clock to Host */
#define MS_ACK		0xfe	/* ACK - Acknowledge of Command Reception */
#define MS_SYSTEM	0xff	/* System Message follows */

/* MPU Commands - Mode Changes */
#define MO_NOP		0x00	/* NOP - No Operation */
#define MO_STOPPLAY	0x05	/* Stop Playing */
#define MO_STARTPLAY	0x0a	/* Start Playing */
#define MO_CONTPLAY	0x0b	/* Continue Playing */
#define MO_STOPREC	0x11	/* Stop Recording */
#define MO_STOPDUB	0x15	/* Stop Overdubbing */
#define MO_RECSTANDBY	0x20	/* Record Stand-by */
#define MO_STARTREC	0x22	/* Start Recording */
#define MO_CONTREC	0x23	/* Continue Recording */
#define MO_STARTDUB	0x2a	/* Start Over Dub */
#define MO_CONTDUB	0x2b	/* Continue Over Dub */

/* MPU Commands - Initialization Switches */
#define SW_NOALLNOFF	0x30	/* No All Note Off messages sent */
#define SW_NOREALTIME	0x32	/* No Real Time messages sent to MIDI OUT */
#define SW_NOTHRU	0x33	/* All MIDI Thru functions cancelled */
#define SW_TIMINGBYTE	0x34	/* Enable Dummy Timing Bytes for messages */
#define SW_MODEMESS	0x35	/* Enables MIDI Mode messages to be sent */
#define SW_TACTSENSE	0x36	/* Allows Active Sensing to go Thru */
#define SW_TEXCL	0x37	/* Allows System Exclusive mess. to go Thru */
#define SW_COMMON	0x38	/* Allows Common messages to be sent */
#define SW_REALTIME	0x39	/* Allows Real Time messages to be sent */

/* MPU Commands - Special Function switches */
#define SW_UART		0x3f	/* Enter UART Mode */

/* MPU Commands - Channel Reference Tables */
#define SW_REFACH	0x40	/* Set Reference Table A to MIDI Channel */
#define SW_REFBCH	0x50	/* Set Reference Table B to MIDI Channel */
#define SW_REFCCH	0x60	/* Set Reference Table C to MIDI Channel */
#define SW_REFDCH	0x70	/* Set Reference Table D to MIDI Channel */

/* MPU Commands - Switches */
#define SW_USEINTCLK	0x80	/* Use INTERNAL clock */
#define SW_USEFSKCLK	0x81	/* Sync Clock to FSK timing from TAPE IN */
#define SW_USEMIDICLK	0x82	/* Sync Clock to MIDI Clock from MIDI IN */
#define SW_ONMETRONA	0x83	/* Turn metronome on without accents */
#define SW_OFFMETRO	0x84	/* Turn metronome off */
#define SW_ONMETROACC	0x85	/* Turn metronome on with accents */
#define SW_OFFBENDER	0x86	/* Disables Bender messages to host */
#define SW_ONBENDER	0x87	/* Allows sending of bender messages to host */
#define SW_OFFVTHRU	0x88	/* Disables MIDI Thru of acceptable channels */
#define SW_VOICETHRU	0x89	/* Allow all MIDI IN Voice mess. to go thru */
#define SW_OFFDSTOPR	0x8a	/* Disables sending of Data in Record Stop */
#define SW_ONDSTOPR	0x8b	/* Enables send of Data in Record Stop */
#define SW_OFFME	0x8c	/* Disables sending of Measure End marks */
#define SW_ONME		0x8d	/* Enables sending of Measure End marks */
#define SW_OFFCONDUCT	0x8e	/* Disables Conductor track requests */
#define SW_ONCONDUCT	0x8f	/* Enables Conductor track requests */
#define SW_OFFRTM	0x90	/* Disables Real Time Message control */
#define SW_ONRTM	0x91	/* Enables Real Time Message control */
#define SW_FSK2INT	0x92	/* Sets resolution of FSK to Internal Clock */
#define SW_FSK2MIDI	0x93	/* Sets resolution of FSK to MIDI Clock */
#define SW_OFFCLK2HST	0x94	/* Disables Clock data to host */
#define SW_ONCLK2HST	0x95	/* Enables Clock data to host */
#define SW_OFFEX2HST	0x96	/* Disables Exclusive data to host */
#define SW_ONEX2HST	0x97	/* Enables Exclusive data to host */
#define SW_OFFCRTA	0x98	/* Disables Channel Reference Table A */
#define SW_ONCRTA	0x99	/* Enables Channel Reference Table A */
#define SW_OFFCRTB	0x9A	/* Disables Channel Reference Table B */
#define SW_ONCRTB	0x9B	/* Enables Channel Reference Table B */
#define SW_OFFCRTC	0x9C	/* Disables Channel Reference Table C */
#define SW_ONCRTC	0x9D	/* Enables Channel Reference Table C */
#define SW_OFFCRTD	0x9E	/* Disables Channel Reference Table D */
#define SW_ONCRTD	0x9F	/* Enables Channel Reference Table D */

/* MPU Commands - Host Requests */
#define RQ_PLAYCNT	0xa0	/* Request Play Counter of track */
#define RQ_RECCNT	0xab	/* Request and clear Record Counter */
#define RQ_TEMPO	0xaf	/* Request Current Tempo value */

/* MPU Commands - Clear Functions */
#define CL_RELTEMPO	0xb1	/* Reset Relative Tempo to 1:1 */
#define CL_PLAYCNT	0xb8	/* Clear all Play and Conductor Counters */
#define CL_PLAYTABLE	0xb9	/* Clears play tables and reference tables */
#define CL_RECCNT	0xba	/* Clears record counter */

/* MPU Commands - Set Timebase */
#define SETTB_48	0xc2	/* Set Internal Timebase to 48 bpm */
#define SETTB_72	0xc3	/* Set Internal Timebase to 72 bpm */
#define SETTB_96	0xc4	/* Set Internal Timebase to 96 bpm */
#define SETTB_120	0xc5	/* Set Internal Timebase to 120 bpm */
#define SETTB_144	0xc6	/* Set Internal Timebase to 144 bpm */
#define SETTB_168	0xc7	/* Set Internal Timebase to 168 bpm */
#define SETTB_192	0xc8	/* Set Internal Timebase to 192 bpm */

/* MPU Commands - Send MIDI commands */
#define SENDVOICE	0xd0	/* Send MIDI Voice Command to Track */
#define SENDSYSTEM	0xdf	/* Send System Exclusive Message or Common */

/* MPU Commands - Set Conditions and Values */
#define ST_TEMPO	0xe0	/* Set Tempo to bpm value */
#define ST_RELTEMPO	0xe1	/* Set Relative Tempo value */
#define ST_GRADUATION	0xe2	/* Set rate of tempo change */
#define ST_MIDI_METRO	0xe4	/* Set # of MIDI Clocks per metronome beep */
#define ST_METRO_MEAS	0xe6	/* Set # of beats per measure */
#define ST_4INT_CLK	0xe7	/* Set 4 * # int clocks per clock to host */
#define ST_ACTIVETRK	0xec	/* Set active track numbers */
#define ST_PLAYCNT	0xed	/* Set 'Send Play Counter' track numbers */
#define ST_ACCEPTCHL	0xee	/* Set Acceptable Channels 1 - 8 */
#define ST_ACCEPTCHH	0xef	/* Set Acceptable Channels 9 - 16 */

/* MPU Commands - Reset */
#define MPURESET	0xff	/* Master MPU401 Reset */
