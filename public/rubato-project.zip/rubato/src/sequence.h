/*
 *	SEQUENCE.H
 *
 *	defines useful global variables
 */

extern char ibuf[];

extern byte chref;
extern byte chchan[];
extern bool bender;
extern byte timebase;
extern byte tempo;
extern byte laccchan, haccchan;
