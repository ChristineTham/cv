/*
 *	SEQUENCE.C
 *
 *	Simple MIDI sequencer program that can record and play back a single
 *	track.  Up to 32K of data may be stored as this program uses only
 *	the small memory model.  It is anticipated at the memory size
 *	for storage will hopefully increase to at least 64K per track if
 *	the large data model is used.
 *
 *	christie
 */

#define MSIZE 32767
#define IBUFSIZ 80
#define ERROR -1

#include <stdio.h>
#include <fcntl.h>
#include <conio.h>
#include <io.h>
#include "mpu401.h"

char ibuf[IBUFSIZ];
char fname[IBUFSIZ];
char outbuf[BUFSIZ];

byte *memory;
byte *mptr;
int mused;
bool playing = FALSE;
bool insave = FALSE;

char *malloc();
byte mread();
byte getdata();
char *gets();

main()
{
	int choice = 0;

	/* magic statement that speeds up stdout */
	setbuf(stdout, outbuf);
	setdefs();
	putcmd(MPURESET);
	mused = 0;
	mptr = memory = (byte *)malloc(MSIZE);
	for (;;)
	{
		puts("\nSIMPLE MIDI 1 TRACK RECORD/PLAYBACK SEQUENCER");
		puts("(c) 1986 Chris Tham\n");
		puts("\nAvailable functions:");
		puts("\t[1]Set Options");
		puts("\t[2]Record track");
		puts("\t[3]Playback track");
		puts("\t[4]Clear memory");
		puts("\t[5]Dump memory");
		puts("\t[6]Load track");
		puts("\t[7]Save track");
		puts("\t[8]Exit this program");
select:		printf("Select choice:");
		fflush(stdout);
		if (gets(ibuf) != NULL && *ibuf)
			choice = atoi(ibuf);
		switch (choice)
		{
		case	1:
			doinit();
			break;
		case	2:
			dorecord();
			break;
		case	3:
			doplay();
			break;
		case	4:
			doclear();
			break;
		case	5:
			dodump();
			break;
		case	6:
			doload();
			break;
		case	7:
			dosave();
			break;
		case	8:
			exit(0);
		default:
			puts("That was not a legal choice!");
			goto select;
		}
	}
}

dorecord()
{
	register byte c;

	insave = TRUE;
	putcmd(MO_STARTREC);
	/* allow some slack at the end */
	while (mused < MSIZE - 10)
	{
		mpuexcept(getdata());
		if (kbhit())
		{
			(void)getch();
			break;
		}
	}
	putcmd(MO_STOPREC);
	while ((c = getdata()) != MS_ALLEND)
		msave(c);
	msave(c);
	printf("Memory used %d bytes\n", mused);
	insave = FALSE;
}

doplay()
{
	playing = TRUE;
	mptr = memory;
	putcmd(ST_ACTIVETRK);
	putdata(1);
	putcmd(CL_PLAYCNT);
	putcmd(MO_STARTPLAY);
	while (playing)
	{
		mpuexcept(getdata());
		if (kbhit())
		{
			(void)getch();
			break;
		}
	}
	putcmd(MO_STOPPLAY);
}

doclear()
{
	mused = 0;
	mptr = memory;
	playing = FALSE;
}

dodump()
{
	register int i;

	for (i = 0, mptr = memory; i < mused; ++i)
		printf("%02x ",*mptr++);
	putchar('\n');
}

doload()
{
	register int fd;

	printf("Filename to load: ");
	fflush(stdout);
	if (gets(fname) != NULL && *fname)
	{
		if ((fd = open(fname, O_RDONLY)) == ERROR)
		{
			printf("load: error opening %s\n", fname);
			return;
		}
		mptr = memory;
		if ((mused = read(fd, memory, MSIZE)) == ERROR)
		{
			printf("load: error reading %s\n", fname);
			close(fd);
			return;
		}
		printf("Memory loaded: %d bytes\n", mused);
		close(fd);
	}
}

dosave()
{
	register int fd;
	register int fsize;

	printf("Filename to save: ");
	fflush(stdout);
	if (gets(fname) != NULL && *fname)
	{
		if ((fd = open(fname, O_WRONLY | O_TRUNC | O_CREAT | O_EXCL)) == ERROR)
		{
			printf("save: error opening %s\n", fname);
			return;
		}
		if ((fsize = write(fd, memory, mused)) == ERROR)
		{
			printf("save: error writing %s\n", fname);
			close(fd);
			return;
		}
		if (fsize != mused)
			printf("save: warning: only %d bytes written\n", fsize);
		close(fd);
	}
}

dotimeoflow()
{
	msave(MS_TIMEOVERFLOW);
}

docondreq()
{
	puts("Conductor request is not implemented!");
}

doallend()
{
	puts("All tracks finished playing");
	playing = FALSE;
}

doupdclock()
{
	puts("Clock received");
}

dosystemrx()
{
	puts("System Data Requests not implemented!");
}

dopanic()
{
	puts("PANIC!: internal error");
}

dosavedata(mess)
byte mess;
{
	static int runstat;

	msave(mess);
	if (mess == MS_TIMEOVERFLOW)
		return;
	switch (mess = getdata())
	{
	case	M_NOP:
		/* This situation does not occur */
		break;
	case	M_MEASUREEND:
	case	M_DATAEND:
		msave(mess);
		break;
	default:
		msave(mess);
		if ((int)mess >= 0x80)
		{
			runstat = mess;
			msave(getdata());
			if ((int)mess < 0xc0 || (int)mess > 0xdf)
				msave(getdata());
		}
		else
			if (runstat < 0xc0 || runstat > 0xdf)
				msave(getdata());
	}
}

msave(data)
byte data;
{
#ifdef DEBUG
	printf("Saving %x\n", data);
#endif
	if (insave)
	{
		*mptr++ = data;
		mused++;
	}
}

doplayreq(track)
byte track;
{
	static int runstat;
	byte mess;

	/* Only track 1 supported */
	if ((track & 7) != 0)
		puts("Illegal track!");
	putdata(mess = mread());
	if (mess == MS_TIMEOVERFLOW)
		return;
	switch (mess = mread())
	{
	case	M_NOP:
		/* This situation does not occur */
		break;
	case	M_MEASUREEND:
	case	M_DATAEND:
		putdata(mess);
		break;
	default:
		putdata(mess);
		if ((int)mess >= 0x80)
		{
			runstat = mess;
			putdata(mread());
			if ((int)mess < 0xc0 || (int)mess > 0xdf)
				putdata(mread());
		}
		else
			if (runstat < 0xc0 || runstat > 0xdf)
				putdata(mread());
	}
}

byte
mread()
{
#ifdef DEBUG
	printf("Getting %x\n", *mptr);
#endif
	return(*mptr++);
}
