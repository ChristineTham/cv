.SA 1
.TL
RUBATO High Level Language\*(EM
A Tutorial Introduction
.AF "University of Sydney"
.ds Ba "Basser Department of Computer Science
.AU "Chris Tham" CT Ba
.AT "CS Honours 1987" "Basser Department of Computer Science"
.MT 4 1
.AS 0
A brief and casual introduction to the RUBATO High Level Language (RHL)
is presented in this paper.  The RHL allows a user to enter music into
the RUBATO system for subsequent performance.  Musical pieces written in RHL
are suitable for processing by the RUBATO compiler, and bear many
resemblances to modern, block-structured computer languages.
.br
.sp
Date Printed: \*(DT
.AE
.OK "music performance" "compiler construction" "concurrent processing" "MIDI"
.nr Cl 3
.H 1 "INTRODUCTION"
The RUBATO high level language is a music input language that is closely
modeled on conventional music notation.  However, it is a typographical
language rather than a pictorial language, and contains additional features
such as variables, 'templates' or procedures, dynamic block structured
scoping and concurrency which are typical of modern computer languages.
This paper presents a user's tour through
some of the features of RHL.  The discussion will
be strictly casual, with the intention of becoming more formalized in the
future.  The target audience will be persons familiar with at least one other
programming language such as Pascal or C, and with a minimal background in
music theory.  Some implementation hints may also be discussed.
.H 1 "SOME ASSUMPTIONS"
.P 1
The RUBATO High Level Language has been designed so that music pieces written in
conventional music notation can be transcribed into the format required by
the language with a minimal amount of effort.  Hence, the RUBATO model of
music is conceptually similar to that employed in the stave model where
notes are distinct entities possessing attributes such as pitch, duration
and dynamics (loudness).
.P 1
In order to facilitate the keying in of notes into the RUBATO system and to
minimize the amount of typing required to transcribe a piece of music, some
assumptions about the nature of music were made.  These assumptions guided
the design of the language:
.H 2 "PRINCIPLE OF LOCALITY"
Music is composed of notes which are locally homogeneous.  In a local
section of a musical piece, all notes typically lie relatively close to one
another in pitch, and usually have similar attributes.  For example, all
notes in a phrase or melody are likely to be spaced equally apart in time
(have equal lengths and durations).  A language that exploits this feature
will simplify the keying in of musical phrases by employing default
attributes so that they need not be keyed in for every note.
.H 2 "REPETITION & HIERARCHY"
A musical piece is not usually
.I atonal
(i.e. ever-changing with no repetition of previous material).  Most music
have parts which are repeated over and over again, possibly with
variations.  Even in cases where the melody does not repeat, the rhythmic
pattern of the notes may be replicated.  A music input language should be
able to handle repetitions in form as well as content intelligently.
.H 2 "POLYPHONY OF PARTS"
A piece of music does not usually consist of a single thread of notes but
can be advantageously viewed as the parallel progression of many threads of
notes all playing simultaneously.  The performance of the musical piece can
be regarded as the simultaneous performance of many individual parts or
.I voices .
It would be cumbersome if all such voices have to be keyed in
intermingled with each other in a linear fashion.  It should be possible
for each individual part to be keyed in separately and then merged by the
music system.  The binding of parts into a musical piece should be done as
late as possible so that parts can be reused for other pieces of music.
.H 1 "NOTES AND ATTRIBUTES"
.P 1
We begin with the simplest object of all, the note.  Music can be viewed as
a sequence of independent
.I notes
(which may or may not overlap) played in a given time frame.  In the RUBATO High
Level Language, a note can be specified by
its pitch and any other attributes that may be tacked on as belonging to
the note.  The only required attribute is the pitch.  If the other
attributes are not specified, they will default to the current settings.
A note description, then, consists of a pitch descriptor followed by other
attributes separated by white space on a single text line.
.P 1
Currently, attributes of a note that may be specified are:
.DL
.LI
.I Pitch
(this will be relative to the current key signature)
.LI
.I Delay
(time interval before next note, relative to the current tempo)
.LI
.I Duration
(time interval in which the note will sound, relative to the delay time)
.LI
.I Velocity
('loudness' or 'intensity' of note struck, only applicable when note is
initially turned on)
.LI
.I Pressure
('force' applied to note as it is being played, may vary continuously in
between notes) (PROVISIONAL)
.LI
.I Patch
(or timbre of the note) (PROVISIONAL)
.LI
.I Channel
(MIDI Channel number) (PROVISIONAL)
.LE
.P 1
Each attribute of a note, if not specified explicitly, will default to a
previously defined 'default' value.  At any given time in an
.I "RHL score"
(source code containing a piece of music written in the RHL language)
the compiler keeps a list of default values for each attribute.  If the
next note is specified with an attribute value differing from the default,
the compiler will use the new value in place of the default.  Otherwise,
the default value will automatically be inserted for the specified
attribute.  Default values do not change from note to note.  However, the
default values may be changed at any point in the score through the
.I default
statement (more about this later).
.H 1 "PITCH SPECIFICATION"
.P 1
The pitch of a note may be specified in two distinct (but complementary)
ways in RHL.
.H 2 " Using the noteval built-in function"
.P 1
A pitch specification consisting of
.DS
.BI noteval( expr )
.DE
where
.I expr
is any valid integer arithmetical expression, will substitute into the
score the pitch of the note corresponding to the value of the expression.
.P 1
For example,
.DS
.B "noteval(60)"
.DE
will insert the pitch corresponding to Middle C of the piano keyboard into
the score[\*F].
.FS
For information between the correspondence between noteval numbers and keys
on the piano keyboard, refer to Appendix A.
.FE
.H 2 "Using alphabetic key specifiers"
.P 1
Pitches may also be specified using the
letters 'a', 'b', 'c', 'd', 'e', 'f', and 'g'.  These
letters corresponding to conventional pitches of the
keys
in music theory.  All pitches thus specified lie within one octave
stretching from 'c' to 'b'.  The actual octave that the keys will lie in is
dependent upon the current default octave value.  There are two distinct
default octave values at any time, the actual default octave used by the
compiler depends on whether the pitch was specified using lowercase or
uppercase characters.
.P 1
To venture outside the range of the two default octaves, it is necessary to
give additional information to the pitch specification.  This is
accomplished by specifying the pitch as
.DS
.IB key ^ expr
.DE
where
.I key
is the pitch character and
.I expr
evaluates to an integer.
For example,
.DS
.B "c^2"
.DE
corresponds to the C key two octaves above the current (lowercase) default
octave.  Similarly,
.DS
.B "F^-1"
.DE
corresponds to the F key one octave below the current (uppercase) default
octave.
.P 1
Shorthand notation for
.B ^1
and
.B ^-1
are the quote (') and backquote (`) characters.  Hence,
.DS
.B a'
.DE
is equivalent to
.DS
.B a^1 .
.DE
.P 1
An absolute octave specification may also be given:
.DS
.IB key ( expr )
.DE
where
.I key
corresponds to the pitch character and
.I expr
is a valid expression that evaluates to an integer in the range -2 to 8.
Musically useful values range from 0 to 7 and correspond to the range of
the piano keyboard.  Hence, the middle octave of the piano keyboard is
octave 4 and middle C is equivalent to
.B C(4) .
Note that
.B g(5)
is equivalent to
.B G(5)
as the case of the key has no significance when the absolute octave is
specified.
.H 2 "Accidentals and Key Signatures"
.P 1
All key specifications using key characters such as 'C', 'D' and so on will
be compiled based on the current
.I "key signature" .
The signature of a musical piece governs which keys will be
.I augmented
and
which keys will be
.I diminished
[\*F].
.FS
To augment a key is to increase its pitch by a semitone and to diminish a
key is to decrease it by a semitone.
.FE
.P 1
The key signature of a sequence of note statements in RHL is specified
using the
.B #key
statement.  For example,
.DS
.B "#key F"
.DE
or
.DS
.B "#key F major"
.DE
will indicate that all notes after the statement are considered to be in
the key of F major,
.DS
.B "#key G minor"
.DE
will indicate that all notes following will be in G minor and so on.
If no key signature is specified, the key of C major is assumed.
.P 1
To override the action of the default key signature,
.I accidentals
may be added to the key character.  As an example,
.DS
.B "g#"
.DE
stands for the G key augmented by one semitone (G-sharp),
.DS
.B "B$"
.DE
corresponds to B-flat and
.DS
.B "e%"
.DE
is E-natural (this only works if the key signature already augments or
diminishes the key E, otherwise, no effect is produced).
.P 1
Note that the same effect can also be achieved using expressions in the
pitch descriptions:
.DS
.B "d+1"
.DE
is equivalent to
.DS
.B "d#"
.DE
.H 2 "More Examples"
.P 1
A couple more examples will hopefully make this a lot clearer.
.VL 20 0
.LI "c"
plays the C note at the current default (lowercase) octave and attribute
settings.
.LI "c(4)"
plays the C note at the 4th octave at the current default settings.
.LI "C#'"
plays the C-sharp note one octave above that of the current uppercase
default octave.
.LI "c + 1 + 12"
plays the same note as the previous example, but uses expressions rather
than short notation.
.LI "noteval(64 + 36)"
plays the note with the MIDI pitch value of 100.
.LE
.H 1 "DELAY ATTRIBUTE"
.P 1
This attribute controls the length of time that separates the start of this
note and the start of the next note.
Delays are always given as a fraction of a unit of time known as the
.I "unit delay" .
The unit delay is equivalent to the 'counting unit' employed while playing
the musical piece and is related to the 'beat' of the music.  Unit delays
are always relative to the current
.I tempo
(or rate of music) and are usually a nice multiple of a quantity known as the
.I "tempo unit"
which is the basic quantity used to measure time.
By default, the unit delay consists of 128 tempo units and
may be considered as being equal to one whole note
(also known as a
.I breve ).
A unit delay in the key of E will be specified as
.DS
.B "e unit"
.DE
where
.B unit
stands for the unit delay.  The reader may choose to think, if she wishes,
of the unit delay as being equivalent to a whole note.  Normally, the unit
delay is set to whatever unit is convenient as a 'counting' unit or beat of
the musical piece.
.I Crochets
correspond to quarter notes and may be specified thus (assuming the unit
delay equals a whole note):
.DS
.B "a unit/4"
.DE
.P 1
Alternative, the short form
.B :
may be subsituted for
.B 'unit/'
and
.B .
may be substituted for
.B 'unit*' .
Hence
.DS
.B "F unit/2 + unit*4"
.DE
is equivalent to
.DS
.B "F:2+.4"
.DE
and
.DS
.B "A unit * 3 / 2"
.DE
may also be specified as
.DS
.B "A.3/2" .
.DE
.P 1
For the rest of the discussion we will assume that the unit delay is
regarded as being equivalent to the whole note.
.H 1 "DURATION ATTRIBUTE"
.P 1
The duration attribute corresponds to the length of time that the note
will 'sound', and is always given relative to the delay attribute.  For
example, a duration of 0 is the shortest possible duration (note will be
effectively turned off immediately after it is turned on) whereas a
duration of 100 means the note will sound for the length of its delay time
(i.e. until the next note comes along).  Durations longer than a 100 means
the note played will overlap with the next note.  The maximum duration
value that can be specified is 200 (actually, 255, but we won't quibble
over this) which corresponds to a note with a duration twice that of the
delay time until the next note.
.P 1
Durations may be specified using the
.RB ' ! '
character or the
.B duration()
function.  For example,
.DS
.B "c:2!56"
which is equivalent to
.B "c unit/2 duration(56)"
.DE
will play a C half-note with a duration value of 56% of the delay time.
The default duration
is 75.
.P 1
A quick way to change the duration for a given note is to use the
.I "staccato (!.)"
and
.I "legato (!_)"
operators.
.DS
.B "c!_"
.DE
will effectively set the duration of the C note to 100 (maximum duration)
and
.DS
.B "c!."
.DE
will set it to 25 (a quarter of the delay time).  The duration values of
the staccato and legato operators may be changed through the
.B default
statement.
.H 1 "VELOCITY"
.P 1
This attribute corresponds to the force applied to the note as it is being
played on a conventional musical instrument.  This usually results in the
note sounding louder of softer, but may also affect the timbre of the note.
For example, a brass instrument will play a note louder and also brighter
in tone if the player blows harder into the mouthpiece.  Within the context
of MIDI, the loudness value of a note corresponds to the MIDI velocity
value.
.P 1
Velocity descriptors of a note begin with a ';' symbol or uses the
.B velocity()
function.
The ';' symbols indicates relative velocity value.  To get absolute
velocity values, you need to use the ';@' combination.
For example,
.DS
.B g$:4;20
.DE
will play the G flat crochet note at a velocity value of 20 above that of
the default.  Using absolute values,
.DS
.B "A# :8 ;@p"
which is equivalent to
.B velocity(p)
.DE
will play the A sharp quaver note at
.I pianissimo
(soft) velocity.  Standard dynamic musical symbols such as 'f', 'ff', 'mp'
may also be used to specify absolute velocity values or, alternately, a
integer expression may be substituted.
.P 1
Velocity values normally range from 0
(no sound) to 127 (very very loud).  The
.B scalev
statement may be used to change velocity values en masse after they have
been entered.  For example,
.DS
.B "scalev 40, 80 to 30, 90"
.DE
will scale ALL velocity information during performance in such a way that
all velocity values (absolute or computed from relative) from 40 to 80 so
that they will be from 30 to 90.  Velocity value outside the scaling range
will be untouched.
.P 1
Shorthand for
.B ";10"
useful for accenting a particular note, is the '>>' operator.
hence:
.DS
.B "d>>"
.DE
is equivalent to
.DS
.B "d;10"
.DE
.P 1
The amount of velocity increase achieved by the '>>' operator
may be changed through the
.B default
statement.
.H 1 "ADDITIONAL PROVISIONAL ATTRIBUTES"
.P 1
Provisional attributes are attributes which may or may not be implemented
in the initial RHL compiler but are considered useful for additional
musical expression.  These are always specified using absolute integer values
rather than relative and begin with the following symbols:
.AL
.LI
Pressure ('&')
.LI
Patch Number ('?')
.LI
MIDI Channel Number ('|')
.LE
.H 1 "DEFINING A NOTE"
.P 1
Notes may be 'named', i.e. declared, and then later 'invoked' with the name
by which the note was declared.  For example, the statement
.DS
.B "note funny = e%^2:16!80;20"
.DE
will declare a note called funny which is an E natural semiquaver note two
octaves above the default lowercase octave with a duration value of 80% and
a relative velocity value of 20 above default.
.DS
.B funny
.DE
will play the note called 'funny' which has been thus defined.
.H 1 "ARITHMETIC EXPRESSIONS"
.P 1
As can be seen from the previous examples, a note may contain an expression in
place of an integer value in any attribute description.
Hence quite complex notes can be defined.  What, then, constitutes a valid
expression in RHL?
.P 1
Arithmetic expressions in RHL evaluate to integer (i.e. numbers without a
fractional component or whole numbers) values and correspond to standard
mathematical algebraic expressions.  Thus, the '+', '-', '*', and '/'
operators work just as you would expect, along with the '(' and ')'
grouping symbols.  In addition, operators typical in most computer
programming languages such as 'and', 'or', 'not' (these work on the binary
representation of integers) can be used.  The 'mod' operator will give the
remainder of a division.
.P 1
The comparison operators may also be used.  These are the '>', '<', '>=',
'<=', '==', '<>' operators, and they work as per most programming
languages, but the result of the comparison is nonzero if the comparison is
true, otherwise the result is zero.
.P 1
In evaluating an arithmetical expression, operator precedence is enforced.
For example, the '*' operator takes precedence over the '+' operator and
the only way to change the order of evaluation of expressions is to use
parentheses for grouping of operands.  The precedence of operators in RHL
is similar to the precedence of equivalent operators in the 'C' programming
language.
.P 1
A function called random may also be used effectively in attribute
expressions.  For example specifying an attribute of random(:8) will
generate a random delay time up to a quarter note in delay time.
.H 1 "BLOCK STRUCTURING"
.P 1
A phrase is simply a set of notes to be played in sequential order (i.e.
each one after the previous note), each on a different line,
delimited by braces:
.DS
{
	c
	d
	e
	f
	g
}
.DE
The above phrase can be made more concise by concatenating the notes onto
one line.
.DS
{ c d e f g }
.DE
.P 1
Phrases may possess attributes just as notes do, a phrase with attribute
descriptors will override the default settings for all notes within the
phrase.  If notes within a phrase also have attribute descriptors, then
these values override the attribute descriptors belonging to the phrase.
For example,
.DS
{
	c
	d
	e:4
	c
	e
	c
	e:2
} :8;@mf
.DE
means that all notes within the phrase will be quaver notes with 'mf'
(mezzo-forte) velocity values unless overridden (as in the case of the E
notes).
.P 1
Chords are rather similar to phrases, except they are delimited by square
brackets ('[' and ']'):
.DS
[ c e g ] :2;@f
.DE
In the above example, all the notes in the chord, i.e. C, E and G, will be
played simultaneously and end simultaneously.
Note that chords may also have attributes, these attributes apply
to all notes within the definition of the chord.  If a note within a chord
contains different delay or duration attributes, that particular note will
start at the same time as the other notes in the chord but will end at a
different time.
.P 1
A phrase or a chord can be named and then referenced by the name, as well
as contain nested blocks:
.DS
phrase ditty =
{
	chord cmajor = [ c e g ] unit

	cmajor
	{
		c
		d
		e
		f
		g
		a
		b
	}
	cmajor
} :8
.DE
The above example defines a phrase called
.I ditty
which contains the chord definition
.I cmajor
which is played at the beginning and the end of the phrase.  Note that the
definition of the phrase or chord does not imply that the phrase or chord
will be played, this must be done explicitly by 'invoking' the phrase or
chord.
.P 1
A
.I block
is simply an entity which may contain other blocks, such as a phrase or a
chord.  Phrases and chords are automatically blocks.  In the above example,
the phrase 'ditty' is a block containing the definition of two other blocks,
one of which is the chord called cmajor and the other is an unnamed phrase.
The performance of 'ditty' entails playing 3 blocks, two 'cmajor' blocks
and the unnamed phrase.
.P 1
There are also integer variables which can be defined and set to any
attribute value within a block.  A variable name is declared using the
.B var
statement and then initialized to the result of an integer expression.  If
the value of a variable needs to be changed after it has been declared, the
.B set
statement is used.  Variables are invoked by the name in which they are
declared.
.DS
{
	var	highnote = c[7]
	var	longduration

	set longduration = .10

	highnote longduration
	d longduration
}
.DE
Variables, named notes, phrases and chords are local to the block.
.H 1 "CHANGING DEFAULT ATTRIBUTES"
.P 1
Default values may be set that will apply to the rest of the block until
changed:
.DS
#key c major
{
#default c[4]
#default C[5]
#default :4!78;@pp
#measure :4*4
	key f#

	phrase ascend = { f g a b C }
	phrase descend = { C b a g f }

	ascend
	ascend
	descend
}
.DE
In the above example, the rest of the block will be in the F-sharp key with
4/4 time signature (as indicated by the
.I measure
statement).  The default octave values for the uppercase and lowercase
notes are defined separately.
Note that the notes themselves will be defined in the key of c
major.  The transcription is automatically done by the RHL compiler.
Notes will normally be quaver notes and will be very soft in
loudness (pp).  Two phrases are defined, 'ascend' and 'descend' and also
played.
.P 1
The unit delay value can also be changed.  Unit delay values are in terms
of units of tempo.  By default, the unit delay is 128 which corresponds to a
whole note.  The unit delay may be changed absolutely or relatively:
.DS
#default unit = 64
#default unit = unit/2
.DE
.P 1
Other default values that may be changed are the default values for
the '>>' (stress), '!.' (staccato) and '_' (legato) descriptors.
.DS
#default >> = 20
#default !. = 10
#default !_ = 50
.DE
The above examples will set '>>' to be equivalent to ';20', '!.' to
be equivalent to '!10' and '!_' to be equivalent to '!50'.
.H 1 "CONTROL FLOW"
.P 1
Certain keywords in RHL are interpreted as control flow statements.  These
statements change the flow of execution of a RUBATO score, which is
normally sequential.  The change in control flow may be unconditional (as
in the
.B goto
statement, or depending on the result of an arithmetical expression (such
as in the
.B if
statement).
.P 1
The control flow statement syntax and keywords accepted by the RHL compiler
are:
.H 2 "if-then-else"
.P 1
.DS
Syntax:
.BI "if " expression " then " statement1
.BI "if " expression " then " statement1 " else " statement2
.DE
.P 1
The
.I expression
is evaluated.  If the result is true (nonzero value)
.I statement1
is executed.  If the result is false (zero value) the next
statement is executed or, if the
.B else
keyword is present,
.I statement2
is executed.
.H 2 "while-do"
.P 1
.DS
Syntax:
.BI "while " expression " do " statement
.DE
.P 1
The
.I expression
is evaluated.  If the result is true, then
.I statement
is executed.  The
.I expression
is then reevaluated.
.I Statement
will be rexecuted until the
.I expression
evaluates to false (0), at which point control will be passed onto the next
statement after the
.B while-do
statement.
.H 2 "do-while"
.P 1
.DS
Syntax:
.BI "do " statement " while (" expression )
.DE
.P 1
The
.I statement
is executed.  The
.I expression
is then evaluated.  If the result is true, the
.I statement
is reexecuted.  This continues until the
.I expression
evaluates to false.  Control then passes to the next statement.
Note that the parentheses around
.I expression
are necessary.
.H 2 "repeat"
.P 1
.DS
Syntax:
.BI "repeat (" expression ") " statement
.DE
.P 1
The
.I statement
is repeated
.I expression
number of times.  Within the context of
.I statement
the integer variable
.B count
is defined.  This is initially set to 1, and is incremented every time
.I statement
has been executed.  Hence it represents a counter of the number of times
.I statement
has been executed.  The parentheses are again necessary.
.H 2 "for-do"
.P 1
.DS
Syntax:
.B for
.B "("
.IB "	init_statement" ;
.IB "	expression" ;
.I "	loop_statement"
.B ") do"
.I "	statement"
.DE
.P 1
The
.I init_statement
is executed, and then
.I expression
is evaluated.  If the result is true,
.I statement
is executed.  After this,
.I loop_statement
is executed and
.I expression
is reevaluated.  If the result is still true,
.I statement
and
.I loop_statement
are re-executed.  This is continued until
.I expression
evaluates to false.
.H 2 "goto"
.P 1
.DS
Syntax:
.BI "goto " label
.DE
.P 1
A label is simply a symbol to mark a location in the RUBATO score.  Labels are
declared using the
.I label
statement thus:
.DS
.BI "label " name
.DE
where
.I name
is the identifier corresponding to the label's name.
.P 1
The
.B goto
statement, known to long suffering computer programmers the world over as
"Dijkstra's curse", simply causes control to pass to the statement following
the label it references.
.H 2 "A simple example"
.P 1
The following simple example will hopefully make the flavor of the above
control flow statements clarified.
.DS
{
	var	aa = random(:2)

	if aa < :4 then
	{
		c
		[ e g ]
	}
	else
	{
		while aa < :4 do
		{
			c aa
			set aa = aa - 1
		}
	}
}
.DE
.H 1 "ENVELOPES"
.P 1
Envelopes are means by which attribute values may be changed continuously
over a period of time.  An envelope MUST be declared beforehand and will
take effect once invoked.
.P 1
An
.I envelope
is declared by enclosing pairs of integer values separated by
the ',' character
within braces ('{' and '}').  The first element of each pair is the delay
time by which the value of the second element must be reached.  For
example,
.DS
envelope crescendo =
{
	0, ;0,
	:4 * 10, ;50
}
.DE
.P 1
This means that initially, the velocity of notes played will be at the
default setting (';0').  After a period of 10 crochet notes, velocity of
notes played will be at a value of 50 higher than the default.  In between,
notes played will have velocity values in between the two extremes.
.P 1
The playback 'speed' of the piece of music can be also controlled by
envelopes through changing the
.I rate
attribute.  A rate of 100 indicates normal speed, rates smaller than a 100
slows the speed of playback proportionately and rates greater than 100 up to
255 speeds up playback.  Hence, a rate value of 50 will half the tempo
(without actually changing the tempo value) whereas a rate of 200 will double
the tempo.  Rates are specified using the '~' character.
.P 1
As an example,
.DS
envelope ritardando =
{
	0, ~100,
	:2, ~50,
	:2, ~100
}
.DE
will slow down the rate of playback from normal speed to half speed after
a delay time of unit/2, and then increase it back to normal after another
unit/2.
.H 1 TEMPO
.P 1
The tempo of a piece is the unit in which delay times are measured in.  The
.B tempo
statement will set the tempo of piece relative to tempo units.  Remember
that unit delays are expressed in terms of tempo units.
For example,
.DS
.B tempo :4 = 100
.DE
will set the tempo to 100 crochets per minute.  The RHL compiler operates
thus:
.DS
In one minute (or 60 seconds), there are
	100 unit/4 = 100 * 128 / 4
		   = 3200 tempo units.
Hence, 
	1 tempo unit = 60 / 3200 seconds
		     = 18.75 microseconds.
.DE
.H 1 "TEMPLATES & PROCEDURES"
.P 1
A
.I procedure
is analogous to a subroutine call in a computer programming language.
A procedure definition can take parameters passed by the caller.  These
parameters may be variables, notes, chords or phrases and can be used
within the definition of the procedure.  Once passed, the value of any
scalar parameter (currently only variables) may be changed without affecting the
caller's values.  In other words, variables are passed by value and
behave like locally defined variables.  Notes, chords and phrases are
passed by a pointer to their data structure and may not be modified.
.P 1
.DS
Syntax:
.BI "procedure " name ( parameters ") " block
.DE
.P 1
The
.I name
of a procedure is the symbol by which it will later be accessed through.
The
.I parameters
are simply variables, notes, chords or phrases declarations separated by
the ',' character.  The
.I block
is the series of statements that will be executed by the procedure when
invoked.
.P 1
For example,
.DS
procedure playtwice(phrase p)
{
	p
	p
}
.DE
will play a phrase twice in succession.  A more general procedure could be
written to play a phrase n number of times:
.DS
procedure playmany(phrase p; var n)
{
	repeat (n) p
}
.DE
or, using the
.B for
statement:
.DS
procedure playmany2(phrase p, var n)
{
	var i

	for (set i = 0; i < n; set i = i + 1)
		p
}
.DE
.P 1
A procedure with no parameters is declared with nothing in between the
parentheses, but the parentheses must still be included in the definition.
.P 1
.I Templates
are conceptually similar to procedures but much simpler to
understand.  A template is simply a procedure with implied parameters.  An
example will make this clear:
.DS
template mybar { :8, :4, :4;20, :8 }
.DE
If this is invoked as
.DS
mybar(c, d, e, f)
.DE
this would be equivalent to the phrase
.DS
{
	c:8
	d:4
	e:4;20
	f:8
}
.DE
.H 1 "OTHER FEATURES WHICH MAY BE IMPLEMENTED"
RUBATO will also have synchronization primitives.  Currently, semaphores
and message passing functions are being considered for inclusion in RUBATO.
.H 1 "FITTING IT ALL TOGETHER"
.P 1
So, how do we construct a RUBATO score given the above syntax rules and
descriptions?
.P 1
The main body of the RUBATO score is considered to belong to an entity
known as the
.I conductor .
Phrases, chords, procedures, templates, notes, and variables can be defined
to the conductor, and will be global to all other blocks (i.e. known to).
Typically, a RUBATO score will consist of a list of definitions followed by
a series of statements to specify which definitions to invoke in order to
play a piece of music.
.P 1
The
.B track
statement may be used to advantage here.  The syntax is
.br
.B track
.I procedure_name
.br
which will invoke
.I procedure_name
as a concurrent process which will execute in parallel to the conductor
process.  More than one procedure may be invoked in this manner and all
such procedures will run concurrently within the limitations of the
hardware.
.H 1 "A NOTE ON THE IMPLEMENTATION OF THE RHL COMPILER"
.P 1
Notes attributes are simply integers greater than 16 bits in width.  The
lower eight bits are used to specify the value of the attribute and the
other bits are used to distinguish between attributes.  Only 8 bits are
needed to specify an attribute due to MIDI's inherent 8 bit design.  The
only attribute that could conceivably need more than 8 bits for
representation is the delay attribute.  Hence, the sign bit of a
machine word can be used to distinguish between duration/length attributes
(in which the whole word is significant, except for the sign bit), and
other attributes (including pitch) in which only the lower 8 bits are used
to specify the attribute value, and all higher bits are used to distinguish
between attributes.
.P 1
Given the above insight, it can be readily seen that the RHL can be easily
parsed by a recursive descent parser provided a suitable preprocessing or
tokenizing phase is undergone beforehand.  Hence the compiler can be
designed in a relatively small period of time.  Variables and expressions
will have to be evaluated by the player rather than the compiler, hence the
player will probably need a stack based architecture.
.TC
.CS
