.SA 1
.TL CSHons87 Project1
LITERATURE REVIEW \*(EM
A Comparative Survey of Music Input Languages and Computer-based Music
Performance Systems
.AF "University of Sydney"
.ds Ba "Basser Department of Computer Science
.AU "Chris Tham" CT Ba
.AT "CS Honours 1987" "Basser Department of Computer Science"
.MT 4 1
.AS 0
There are currently a wide variety of diverse methods of entering music into
a computer in
a format suitable for musical analysis and/or performance.  Conventional
music notation has been found to be less than ideal for computer-based
musicological analysis and performance, hence a variety of musical
notation languages have been developed.  This essay attempts to look at the
existing approaches to music notation and input languages and also to compare
between
the features of different designs and the restrictions due to paradigms
employed in the designs.  A review of music performance systems employing
one or more of the above input languages will also be covered.
.AE
.OK "music notation" "music input languages" "music performance" "MIDI"
.nr Ej 1
.nr Hc 1
.nr Cl 3
.PF "''Date Printed: \\*(DT''"
.H 1 INTRODUCTION
.P 1
It is inevitable that not long after work had begun in the field of
computer music research, the notion of programming languages specifically
designed for musical applications began to develop.  Solving musical
problems and music generation with computers involves questions of
efficiency, representation and modelling(\*F).
.FS
.B " " [ "Loy 1985" ]
p. 235
.FE
While it is possible for a composer to sucessively modify a composition
program written in an existing programming language, or use a set of
library routines that implement common operations on musical data
structures(\*F),
.FS
see
.br
R. Dannenberg,
"Moxc : real-time programming package",
.B " " [ "Dannenberg 1986" ]
.br
for more details on a set of library functions that allow musical programs
to be written in the C Programming language based on
.I Moxie .
.FE
writing a programming language as the embodiment of musical paradigms will
allow a wide range of compositional strategies to be realized(\*F).
.FS
.B " " [ "Loy 1985" ]
p. 238
.FE
.P 1
This review will attempt to assess existing music input languages, music
generation and performing languages, as well as musical programming
languages that implements musical data types and operations and allow a
representation of time in a musical composition.  The languages surveyed
will be presented here in a nondeterministic order, although some effort
have been made to present languages related to one another in sequence for
easy comparison.
.P 1
An attempt must be made at this point to comment on the conventional music
notation of notes on staves(\*F)
.FS
My reference to CMN is from
.br
G. Read,
.I "Music Notation" ,
"A Manual of Modern Practice",
Allyn & Bacon, Inc. (1964)
.FE
(hereinafter referred to by the initials 'CMN').
While it is certainly possible to design
graphical editors that display and edit musical scores using ordinary
music notation, CMN is far from ideal for representing music on a computer.
First of all, CMN quantizes the continuous musical stream into discrete
.I notes ,
which are event specifications with pitch and duration (rhythm) attributes.
However, additional information such as loudness and timbre are specified
indirectly in an often inconsistent manner.  Furthermore, the information
on a printed score in CMN is incomplete in that additional rules are
usually interpreted in performance.  This includes articulation and
dynamics rules.  Performance directives in CMN are usually specified in a
nonsystematic way which makes the design and implementation of a
substantially complete music editor a non-trivial exercise in artificial
intelligence techniques(\*F).
.FS
see
.br
C. Roads,
"Research in Music and Artificial Intelligence",
.I "ACM Computing Surveys" ,
Vol 17 No. 2, June 1985
.br
for a discussion of artificial intelligence research in computer music.
.FE
.P 1
For this reason, it is usual for compromises to be made.  A music input
language is often devised as an intermediary means of allowing musical
information to be represented in the computer.  The musical information may
then be used for musical analysis, computer music typesetting, or even
music generation and performance.  Music input languages may sometimes be a
limited subset of CMN with irregularities removed and simplifications
effected, but often they are representations of musical scores in
alphanumeric form suitable for interactive terminal input or keypunching.
.P 1
In this review, a selection of music input languages is presented and
discussed.  The paradigms employed in their design are
highlighted, as well as the effect on the subsequent 'style' of the
language.  Currently, a wide variety of models to represent musical data
are used, including mathematical (stochastic, combinatorial and statistic),
linguistic, algorithmic, process (object oriented) and models derived from
artificial intelligence(\*F).
.FS
.B " " [ "Loy 1985" ]
p. 238
.FE
.H 1 "MUSIC N"
Early programs developed for computer music synthesis, generation and
performance often use the "note as an acoustic specification" model.  This
is mainly due to the history of acoustic experimentations in electronic
music moving into the digital computer domain.  The interest on timbre was
a primary impetus in the growth of electronic music and, later on,
computer music synthesis.  Hence, most computer music notations define a
musical note as the "specification of an acoustic event" rather than
through the use of CMN.  The advantage of specifying music as a collection
of acoustic parameters that is synthesized into waveforms is the freedom of
expression beyond that of conventional musical instruments.  However, every
detail of a music performance had to be specified in painstaking detail.
.P 1
The first, and most influential, of these family of programs were a suite
of programs, named Music I to Music V, developed under Max Mathews et al at
AT&T Bell Laboratories.  These programs spawned a whole tree of descendants
with similar names such as Music 4B, Music 4BF, Music 10 etc(\*F).  I will
.FS
see
.br
H. S. Howe Jr.,
"Detailed Description of a Computer Sound Generating Program: MUSIC 4BF",
.I "Electronic Music Synthesis" ,
"Concepts, Facilities, Techniques",
J. M. Dent & Sons (1975)
pp. 175 - 248
.br
and
.br
J. E. Rogers,
"The Uses of Digital Computers in Electronic Music Generation",
.I "The Development and Practice of Electronic Music" ,
Prentice-Hall, Inc. (1975)
pp. 189 - 285
.FE
simply take Music V as a role model and refer to the whole class of
programs for the remainder of this essay as MUSIC N.
.H 2 "Music V"
The Music V environment is a fast general purpose computer with mass
storage and digital-to-analogue converters.  Music V takes a set of
synthesis algorithms and note specifications as input, generates waveform
samples for the entire musical score onto tape.  An auxiliary program then
reads the samples off the tape and sends them across to the
digital-analogue converters, hence producing music.
.P 1
Synthesis algorithms are specified by interconnecting
.I "unit generator"
modules resulting in an
.I instrument .
A series of note statements containing a list of expressions specifying the
note parameters are than parsed by Music V and converted into waveforms
using the instruments defined previously.
.P 1
Music V processes its input in three passes: a parameter conversion pass, a
note sorting pass, and the actual synthesis pass.  Instruments can be
.I reentrant
(i.e. the same instrument may be playing more than one note), a feature new
to Music V and not present in Music IV.
.P 1
In pass I, the score is read and data statements are interpreted into
operations.  Statements are free form in that they are terminated by
semicolons and more than one statement may coexist on the same line.  The
first field is the operation code, the second the
.I "action time"
that specifies when the operation is to be done.  Further fields are
specific to the operation type.  Fields are separated by white space or
commas.
.P 1
The operation code is a three letter mnemonic which is converted to a
numeric equivalent.
.VL 10 0
.LI " (1) NOT"
plays a note using a defined instrument
.LI " (2) INS"
defines an instrument using unit generators
.LI " (3) GEN"
specify generating function for unit generators
.LI " (4) SV3"
Set variable for pass III
.LI " (5) SEC"
End section
.LI " (6) TER"
terminate piece (Music V input score)
.LI " (7) SV1"
Set variable in pass I
.LI " (8) SV2"
Set variable in pass II
.LI " (9) PLF"
Execute subroutine in pass I
.LI "(10) PLS"
Execute subroutine in pass II
.LI "(11) SI3"
Set integer in pass III
.LI "(12) SIA"
Set integer in all passes
.LI "(13) COM"
Comment operation
.LE
.P 1
After pass I, a temporary file is created which is passed on to pass II.
Each statement is then sorted by action time in ascending order and a
metronome function is applied to distort the time scale.
.P 1
Finally, pass III computes the actual acoustic samples by organizing unit
generators into instruments and playing the instruments(\*F).
.FS
.B " " [ "Mathews 1969" ]
pp. 116 - 122.
.FE
.H 2 Summary
MUSIC N's complete lack of structure in the event (note) specifications
allowed new approaches to composition.  However, the acoustical model can
sometimes constrain musical composition.  Transcribing from CMN to MUSIC N
is possible but is quite tedious for humans(\*F).  MUSIC N does not operate in
.FS
see
.br
M. V. Mathews, L. Rosler,
"Graphical Language for the Scores of Computer-generated Sounds",
.I "Music By Computers" ,
H. V. Foerster, J. W. Beauchamp (eds),
John Wiley & Sons, Inc. (1969)
pp. 84 - 116
.br
for a graphical interface to MUSIC IV.
.FE
real time, and often a 1 minute composition may take up to 20 minutes of
computation.  Performance interpretation, missing from CMN, is very
difficult to code on MUSIC N, and the implicit assumption of notes as static
entities that cannot vary once instantiated is not valid for certain types
of music.
.H 1 MUSPEC
.P 1
MUSPEC
.B " " [ Citron ; "Lincoln 1970" ]
is a high-level tool in musical composition.  It may also
be used as a music input language.
The paradigms employed in MUSPEC are musicological rather than numerical in
nature, but MUSPEC is not a true musical input language.  Input data into
MUSPEC is only casually related to musical notation.  Instead, the user is
expected to think in terms of musical ideas such as pitches in tone
systems, chord structures and rhythms.
.P 1
MUSPEC grew out of research on the use of computers in aural pattern
recognition(\*F).
.FS
J. Citron & A. Hurwitz,
.I "Use of computers in aural pattern recognition" ,
IBM Los Angeles Scientific Center Report 35.017 (1966)
.FE
As a result, MUSPEC views a musical composition as "... a voiced harmonic
continuity and its subsequent melodization."(\*F)
.FS
.B " " [ "Lincoln 1970" ]
p. 98
.FE
.P 1
The output of MUSPEC is a printed listing of notes and time durations, but
not in musical notation.
There are currently no means
of performing (realizing) MUSPEC output as MUSPEC does not
feature supporting hardware for musical performance.  The only way of
"listening" to MUSPEC output is to transcribe the results into conventional
music notation for instrumental performance, or into a computer music
performance system.
.P 1
MUSPEC has been used to generate and compare the musical characteristics of
persistent lines of chemical substances, phases of seismic disturbances,
electrocardiograms, stellar luminosity plots and other phenomenological
recordings(\*F).
.FS
.B " " [ "Lincoln 1970" ]
p. 98
.FE
In fact, the name MUSPEC is derived from the projected use of the program
as a "MUsical SPECtroscope".
.P 1
MUSPEC input is divided into two
.I blocks: a declarative block and a 'executable' block.
.H 2 "Stylistic Control Information Block"
.P 1
This is the declarative section of the input.  Some possible declarations
are:
.H 3 "Tonal System"
This is the pitch system of the music, given in user-defined symbols.  Note
that MUSPEC translates the symbols into numbers for internal processing and
reconverts the resultant numbers back into symbols for output.  The actual
significance of the symbols as pitches in some musical scale is ignored by
MUSPEC itself.  An example of a tonal system declaration is:
.P
TONSYS C DF D EF E F GF G AF A BF B
.P
which defines the twelve-tone scale.
.H 3 "Root Tone Scale"
This is the allowed set of root tones upon which chords may be constructed.
The entries are numeric offsets to the symbols named in the TONSYS
statement.
.P
ROOTS 1 3 5 6 8 10 12
.H 3 "Root Tone Cycles"
CYCLES 5 2 3 5 2 5
.P
gives the allowed root progressions according to the root tone scale in
ROOTS.
.H 3 "Harmonic Structure"
Structures are numbers which enumerate intervals in the TONSYS scale
separating consecutive notes in the structure.  For example,
.P
STRCTR 4 3 3
.P
specifies a seventh chord on allowable root tones.  Structures are used for
harmonic composition as well as melodization.
.H 3 "Harmonic Continuity"
Voicing statements specifies the harmonic continuity of the music and
control the voice leading between chords.  The entry of a particular
voicing position specifies the structure note of the next chord which the
note in the current structure component must move to.  An example is
.P
VOICNG 1 3 4 2
.P
The first chord is voiced using either CHORD1 or CHORDP.  For example,
.P
CHORD1 1 3 4 2
.P
states that the initial reference choird is ordered root, third, fourth and
second structure tone.  CHORDP will cause structures and root tones to be
"phased" in calculations.
.H 3 "Rhythmic Groupings"
Basic Rhythmic Group specifies and overall or "macrothythmic" control:
.P
BSCGRP 2,6/\-1,4/1,3,2
.P
establishes 2 units of time with a maximum of 6 attacks,
1 unit of time with a chord change (as indicated by the minus sign) and
maximum 4 attacks, and 1 unit of time
with a maximum of 3 attacks and a minimum of 2 attacks.
.P
"Microrhythmic" attack patterns are specified as relative duration groups,
i.e. duration is an integer with respect to a minimum value.  A negative
duration value indicates a rest:
.P
RELDUR 3 1 2 2 -1 3 2 2
.H 3 "Melody"
A MELODY statement is a string of integers representing notes selected from
interval structures.
.H 2 "Selector Control Function Block"
.P 1
The second data block may contain any set of numbers at all, whether
abstractly chosen or purposely contrived.  This block begins with a line
with the word LINES starting in column one.  The numbers in the line data
are used to select material from the musical data.  First, a root tone
cycle is selected from available CYCLE scales, followed by voicing choice,
macro- and microrhythmic selection and melody.  Hence, each set of numbers
of a line triggers a set of selections and corresponds to the 'executable'
section of a programming language.
.H 2 "Summary"
.P 1
One of the reasons behind the implementation of MUSPEC was to allow
composers and arrangers to communicate musical thoughts in a relatively
high level to the computer, and in this respect it is fairly successful.
MUSPEC employs a different set of paradigms from conventional music input
languages (which are based on traditional music notation) hence converting
from musical scores into MUSPEC input requires a bit of thought.  The
biggest disadvantage of MUSPEC (which it shares with some other music input
languages) is the lack of ability for the computer to 'play' music
written in MUSPEC, but it is not inconceivable to develop a music performance
system that plays MUSPEC output.  MUSPEC lacks essential musical attributes
such as timbre and loudness, and until these features are added to the
language it will remain primarily a compositional tool.
.H 1 MIR
.P 1
.I MIR
(Musical Information Retrieval)
is a language developed in order to assist musicologists in "... answering
internal-evidential questions about ... (musical scores)".
.B " " [ "Kassler" ; "Lincoln 1970" ]
Hence, it is primarily an analysis tool rather than a music input language.
In theory, any query relating to the symbols of musical notation such as
notes, rests, clefs and so on can be formulated as an MIR program.
.P 1
MIR is written as a
.I macro-language
of FAP (FORTRAN Assembly Program) and individual MIR instructions can be
viewed as direct commands to a machine that performs specific operations on
musical data(\*F).
.FS
.B " " [ "Lincoln 1970" ]
p. 301
.FE
At any given time, this virtual machine can hold at most one note and all
its related attributes.  This is called the
.I "current note" .
.H 2 "Note attributes"
The following is representative of the type of data pertaining to a
note:
.VL 25 0
.LI "LYNENO, MEASNO, NOTENO"
line, measure & note number of current note
.LI "REGCL, NOTECL, SEMITO"
denotes the register class (octave), note class (pitch) and semitones above
a 'base' note.
.LI "DURAT, DURINT, DURNUM"
specifies the duration of the note.
.LI "MESINT, SYSINT"
specifies the measure and system "attack" time for the note.
.LI "CLEF, KEYSIG"
specifies the clef and key signature of the note.
.LE
In addition, a note also contains attributes such as dynamic mark values,
timbre, title, author, publisher of composition and so on.
.H 2 "MIR instructions"
.P 1
MIR instructions consists of three fields:
.I location
(or symbolic address),
.I operation
(or instruction type),
and
.I variable
(object acted on by operation).
Hence MIR programs are very similar in spirit and style to assembly
language programs on computers.  There are instructions such as TOSECT,
TOMEAS, TOLYNE, TONOTE etc. which directs processing to a certain position
in the composition, arithmetic instructions, logical instructions and
output instructions that allow queries to be made on a musical composition.
.H 2 "Summary"
MIR is not a music input language, ad hence does not feature a means
whereby music is transcribed into the system (this can be done by a
suitable music input language(\*F)).
.FS
The companion music input language to MIR is called IML, which is not
discussed here.  See
.br
T. Robison,
"IML \*(EM MIR : A Data-Processing System for the Analysis of Music",
in 
H. Heckmann (ed),
.I "Elektronische Datenverarbeitung in der Musikwissenschaft",
Regensburg, Gustav Bosse Verlag (1967)
.br
and
.br
A. Mendel,
"Some Preliminary Attempts at Computer Assisted Style Analysis in Music"
published in
.I "Computers and the Humanities"
Vol 4 No 1 Sept 1969 pp. 41-52
.br
for more information on IML.
.FE
It is interesting however in that it
treats a musical composition as an information database on which inferences
may be made and queries can be formulated.
A conversion program exists that converts the MIR database to a MUSIC IV
program
which allows "proof-hearing" of the contents of MIR scores and greatly
enhance the usefulness of MIR.
The biggest advantage of MIR is its programmability and flexibility, its
biggest disadvantage its cumbersome assembly syntax.
.H 1 "PILE"
.P 1
PILE
.B " " [ Berg ; "Roads 1985" ]
is a real-time, direct sound synthesis language on the DEC PDP-15
computer.  It produces several layers of sounds simultaneously in
real-time.  It differs from the MUSIC N species of programs in that PILE
instructions are based on machine operations rather than an acoustical
model.  Hence PILE instructions typically represent "structured" assembly
languages rather than MUSIC N streams and in this respect PILE is more
closely related to MIR rather than MUSIC N.
.H 2 "PILE instructions"
.P 1
Each PILE instruction contains the name of an operation on one line and
further information on subsequent lines.  Instructions are terminated by
semicolons and must begin with white space, in order to differentiate
instructions from labels (another convention borrowed from the assembly
language world).  Music is generated from manipulating the contents of an
"accumulator" and then sending it to a hardware "channel".
.P 1
Besides the usual conditional, logical, arithmetic and branch instructions,
there are instructions to manipulate 'lists', the accumulator and external
devices.
.H 2 "Summary"
PILE can be a flexible means of generating music using a low-level machine
operations based method.
.B " " [ "Roads 1985" ]
pp. 169-172
explains, in a hierarchical example, how PILE can be used for FM synthesis
(\*F).
.FS
For a more complete description of the Frequency Modulation technique of
generating sounds, refer to
.br
J. Chowning,
"The Synthesis of Complex Audio Spectra by Means of Frequency Modulation",
originally from
.I "Journal of the Audio Engineering Society" ,
21(7) (1973).  Reprinted in
.B " " [ "Roads 1985" ].
.FE
.H 1 "SSSP Score Editing Tools"
.P 1
A set of tools for the Structured Sound Synthesis Project (SSSP) at the
University of Toronto has been developed which uses interactive computer
graphics to allow a composer to edit musical scores in a highly interactive
manner.
.B " " [ Buxton ; "Roads 1985" ]
It operates on a DEC PDP-11/45 running under the UNIX system(\*F)
.FS
D. Ritchie & K. Thompson, "The UNIX Time-Sharing System",
.I "Communications of the Association of Computing Machinery" ,
17(7), pp. 365-375
.FE
with
vector-drawing graphics displays and digitizing tablets.  Musical output
is produced through the SSSP Digital Synthesizer(\*F)
.FS
W. Buxton et al,
"An Introduction to the SSSP Digital Synthesizer" ,
reprinted in
.B " " [ "Roads 1985" ]
.FE
.H 2 "ludwig"
Ludwig(\*F) is a graphical score editor based on conventional music
.FS
W. Reeves et al,
"Ludwig : An example of interactive computer graphics in a score editor",
in
C. Roads (ed),
.I "Proceedings of the 1978 International Computer Music Conference" ,
vol 2, Northwestern University Press (1978)
.FE
notation.  A graphical representation of the score is displayed in
conventional music notation (or a subset thereof) and the current display
"window" into the music score can be scrolled in the horizontal direction.
Editing is performed through the digitizing tablet and editing operations
are based on recording tape technology in that the composer can perform a
.I splice
and
.I mix
of the score which corresponds to the relevant tape recorder operations.
In order to eliminate typing as much as possible, timbral colours and filenames can be selected by pointing at the appropriate menu item on the screen
through the digitizing tablet.
.H 2 "Scored"
.I Scored
is very similar to Ludwig but employs an alternative display
paradigm: music is displayed in "piano-roll notation" rather than using
conventional music notation symbols.  The internal data structure of
Scored is similar to Ludwig, the same information is essentially displayed
in a different form.
.H 2 "sced"
This is yet another representation of the same data structures, but the
approach used here is alphanumeric rather than graphical.  The primary
reason for the development of
.I sced
(\*F) seems to be to allow editing of scores on alphanumeric terminals.
.FS
W. Buxton,
"A tutorial introduction to SCED",
in
W. Buxton,
.I "Music Software User's Manual" ,
2nd edition, Computer Systems Research Group, University of Toronto.
.FE
.P 1
A new idea is introduced in sced which is the concept of
.I scope.
Ludwig and Scored are essentially "scopeless" editors; the composer either
deals with a note by itself or the score as a whole.  Sced however allows a
group of notes to be manipulated as a whole as a result of the editor
interface which resembles the UNIX text editor
.I ed(1) .
.H 2 "scriva"
This is the cumulative result of previous work in designing the above
editors.  Scriva(\*F)
.FS
W. Buxton,
"A tutorial introduction to SCRIVA",
in
W. Buxton,
.I "Music Software User's Manual" ,
2nd edition, Computer Systems Research Group, University of Toronto.
.FE
is a graphical score editor that can view a common data structure in one of
four different notation schemes: conventional music notation, piano-roll,
object highlighting and envelope highlighting.  Scope is built in by
allowing the composer to "lasso" or circle a set of notes and treat them as an
object.
.H 2 "Summary"
The SSSP score editing tools are an interesting set of programs in that
they are all related to one another and run on the same hardware but are
substantially different in their user interfaces and sophistication.  The
conclusion drawn by the authors are firstly, a graphical approach offers a
very congenial method of editing musical scores compared to conventional
alphanumeric music input languages.  Secondly, the concept of
.I scope
is an important one and foreshadows the heirarchical concept of music with
instances of the same phrase in a musical composition sharing the same
location in computer memory(\*F).
.FS
W. Buxton et al,
"The Use of Hierarchy and Instance in a Data Structure for Computer Music",
.I "Computer Music Journal" ,
2(4), 10-20 (1978) revised and updated in
.B " " [ "Roads 1985" ]
.FE
.P 1
The biggest disadvantage of a graphical user interface in a musical input
language is
the lack of programmability.  It is difficult to specify that a certain set
of notes is to be repeated at various positions in a musical composition
except by physically copying the set of notes.  Once copied, however,
modification done on the original set will no longer affect the copies.
.H 1 "INV"
.P 1
INV
.B " " [ Abbott ; "Roads 1985" ],
or "Invoke",
is a simple interpretive programming language that performs mixing and editing
operations to produce pieces of music.  It is only casually related to
music generation programs as it has no concept of music at all, it simply
"records" (samples a waveform) musical notes onto a hard disk and allows
mixing and editing of the waveform samples before producing them on the
output ('playback').  The language is a fairly low level language similar
in spirit but not in surface appearance to BASIC.
.H 2 "INV Programming"
On the lowest level, event structures and integer variables can be written
to and accessed.  Control flow and functions are called
.I activities .
There can be only one activity per line, corresponding to statements in a
programming language.  In addition, the following musically oriented
primitives are defined:
.DL
.LI
Send data from a disk file to a Digital-to-Analogue Converter.  This
produces sounds.
.LI
Record sounds via an Analogue-to-Digital Converter into a disk file.
.LI
Scale buffer contents using a scaling constant or function.
.LI
Produce a waveform at normalized amplitude.  FM synthesis may be used.
.LI
Add one buffer to another.
.LE
.P 1
User defined activities (called
.I macros
or
.I functions
are stored in a library.  During program execution, the interpreter fetches
the macros from disk and executes the macros until the end of the macro.
The calling-level stack is organized such that macro symbols are local to
the macro.
.H 2 Summary
INV is unique among all the other languages presented in this review in
that it has no concept of music at all.  The 'knowledge' of INV is limited
to that of recording and playing waveform samples, although a limited
waveform generation capability does exist.  However, INV
.I can
produce music, simply because it is a very fast ramdom-access tape
recorder.  If all the notes of a grand piano is recorded into INV and then
a selected set of notes are played in sequence, music can be produced.
.P 1
Another unique feature of INV is its capability of dealing with 'events'
regardless of their type using an 'event structure'.  This, plus
programmability, makes INV a flexible tool for generating music but the
prospective INV composer would be
hampered by INV's lack of musical knowledge.
.H 1 "PLAY"
.P 1
PLAY
.B " " [ Chadabe ; "Roads 1985" ]
is a program for music generation program that is not rooted in traditional
music notation but instead tries to to maximise flexibility in the
conceptualization of temporal processes.  It functions in two distinct
stages:
.AL
.LI
A
.I "design stage"
where it is necessary to specify
.I "data generators"
which output lists of numbers which can determine pitch, rhythm, envelope,
loudness etc., i.e. control the technical characteristics of the
synthesizer or internal variables.  Data generators can be interconnected
as modules with each other.  The timing of individual modules may vary and
one module may use another as a clock rather than the system clock.
.LI
The
.I "operation stage"
whereby the program plays music while the composer controls a chosen set of
variables in real time.  The interconnection of modules may be changed
during playback.
.LE
.H 2 "PLAY Components"
.P 1
PLAY consists of three subprograms which can be called in any order, even
during playback:
.AL
.LI
FUNCTION (or data input and editing): this allows numbers (which can be
notes) to be entered into the system.
.LI
PATCH: this allows the data lists specified in FUNCTION to be integrated
into modules which can then be interconnected.
.LI
PLAYBACK: this will operate the music generation component of PLAY.  The
other two components may also be called while this component is active,
allowing real time control over the music generation.
.LE
.H 2 Summary
PLAY is a flexible interactive music generating program that is clearly
descended from the MUSIC N model.  However, the interactive aspects of PLAY
make it easier to use than MUSIC N.
.H 1 "FORD-COLUMBIA INPUT LANGUAGE"
The Ford-Columbia Input Language
.B " " [ "Bauer-Mengelberg" ; "Brook 1970" ]
is the result of research to allow printing and typesetting of music under
computer control using photo-composition equipment.  Hence the emphasis was
to develop an alphanumeric means of encoding complete musical works
(including indications on how the music "looks" in conventional notation)
in such a manner that CMN can be completely recovered from the alphanumeric
code language.  Rather than encoding just incipits, or tones, or harmonies,
the Ford-Columbia language (hereinafter referred to as FCL)
is a representation of CMN in alphanumeric form.
.P 1
Although the initial application of FCL was in
phototypesetting specification, FCL has been used successfully for musical
analysis and comparative musicology(\*F)
.FS
.B " " [ "Suchoff" ; "Lincoln 1970" ]
.FE
and transcription of tablature to standard notation(\*F)
.FS
.B " " [ Hultberg ; "Lincoln 1970" ]
.FE
.H 2 "Elements of FCL"
.P 1
Notes in FCL are specified by their positions on the musical staff.  Each
position (irrespective of clef, key signature etc.) of a note on a staff is
encoded numerically.  Horizontal displacement between notes are regarded as
superfluous and two notes are separated by a single space in FCL.
.P 1
Initially, information such as clefs, time signatures and key signatures
are specified.  For example. "25!C" is the notation for the alto clef,
where 25 is the staff code of the clef and 'C' is the letter of the clef.
Similarly, time signatures are indicated by "!M3:4" for waltz timing, and key
signatures by "!K3#" for A-major.
.P 1
Notes are indicated with one letter mnemonic duration values, and stem
indication (normally redundant information, but required for CMN).  In
addition, dynamic marks, staccato, tenuto, staccatissimo, marcato, fermata
and other musicological symbols may all be specified.  Repeating passages
may be specified with a repeat code, or a macro-definition and expansion.
.H 2 Summary
FCL has proved to be a surprisingly useful and flexible tool for purposes
other than which it was designed for. It should not be too difficult to
design a music performance system that reads in scores in FCL provided only
a subset of the total information presented in FCL is actually used.  However,
the main disadvantage of FCL is its insistence on representing all aspects
of CMN, which makes the input language rather cumbersome for
non-typesetting applications.
.H 1 "PLAINE AND EASIE & ALMA"
A similar input language to FCL, but much more compact and easier to key
in, is the so called
.I Plain & Easie
code
.B " " [ Brook ; "Brook 1970" ]
which has been extended into ALMA
.B " " [ Murray ; "Brook 1970" ].
.H 2 P&E
.P 1
Plaine and Easie (abbreviated to P&E) is a simple means of notating music
alphanumerically but has a close relationship to CMN.  Pitch and rhythm can
be completely specified and extensions are available for dynamics,
phrasing, harmony, stemming etc.  After identifying the piece and composer,
P&E allows specification of clef, instrument, tempo, key signature and
meter in a manner similar to FCL.  Notes however are given in alphanumeric
symbols (A, B, C, ..., G for pitch values with accidentals) with duration
expressed as numbers.  Rests are indicated by hyphens and ties using the
underscore or plus character.  Triplets and unusual rhythmic groupings are
enclosed in parentheses preceded by total duration e.g. "4(8 C D E)".
Additional symbols such as accidentals, bar lines, trills and grace notes
can also be specified.
.H 2 "ALMA"
.P 1
ALMA is a much more sophisticated notation system based on P&E.  The amount
of information to be coded, as well as the ordering of the information and
choice of symbols, is ultimately up to the researcher but certain
mnemonically convenient symbols are suggested.  This allows most music in
CMN to be adequately transcribed into ALMA, with special notations and
symbols easily added to the extensible language.
.P 1
In ALMA, the two dimendional CMN is represented as a one dimensional string
of alphanumeric characters by multiple
.I "scan lines" ,
each scan line usually representing one musical voice.  The path of the scan is
the order of examining music notation.  Notes of pitch and duration may be
grouped into
.I groupettes
which may be manipulated as a single entity.  Attributes may give specific
musical information about the notes, change the meaning of future symbols
(e.g. key signatures) or control the scan.  Chords may be specified either
by enclosing chord members within the dollar sign ('$') symbol or using the
'<' symbol to indicate 'move scan back to start of previous note'.  In
other respects, ALMA notation is very similar to P&E.
.P 1
Attributes may be specified for groupettes, and may possess scope.  A large
variety of suggested attributes ensure that conventional CMN performance
symbols are adequately represented.  A powerful set of scan control
functions are also provided.
.H 2 Summary
P&E and ALMA are very compact music input languages designed primarily for
musical analysis and hence are essentially representations of CMN in a more
congenial form suitable for data entry.  A variety of music input languages
for musical analysis have been developed along the lines of P&E and ALMA
(\*F).  Performance systems for P&E is
.FS
see
.br
J. Wenker,
"A Computer Oriented Music Notation including Ethnomusicological Symbols",
.B " " [ "Brook 1970" ]
pp. 91 - 129
and
R. Jackson, P. Berzott,
"A Musical Input Language and a Sample Program for Musical Analysis",
.B " " [ "Brook 1970" ]
pp. 130 - 150
.FE
feasible but limited by the lack of additional notation in P&E.  A
performance system for ALMA would be difficult due to the wide range of
attributes available, the possible paths of scan control, and the
extensibility of the language.
.H 1 "ADAGIO"
Adagio(\*F)
.FS
R. Dannenberg,
"The Adagio Language",
.B " " [ "Dannenberg 1986" ]
.FE
is a very simple nonprocedural notation for scores.  Each note is specified
on a single line, with additional attributes such as duration, time of next
note, dynamics, voice and timbre.  Multiple notes may be joined together on
a single line by terminating each note with a semicolon (';').  Chords can be
represented by specifying that the next note starts on the same time as the
current note, or by separating notes by a comma ('.').
.P 1
In addition, global attributes such as tempo and rate (speed relative to
current tempo) as well as control change commands such as portamento
can also be set.  A useful method of entering multiple voices with
dissimilar timings or durations is by means of an easy "rewind time"
feature that treats the rest of input as starting at the same time as the
previous tempo or rate change or rewind command.
.P 1
Adagio is different from other languages in that it is reasonably close to
musical notation (employs similar models and paradigms) and yet Adagio is
mainly a performance language.  Adagio scores are not used for musical
analysis but are instead read in by the Adagio interpreter which converts
the notes into MIDI(\*F) commands for performance on suitably equipped
conventional commercially available music synthesizers.
.FS
MIDI is a standard interface between music synthesizers and computers that
will not be discussed in this review.  It stands for Musical Instrument
Digital Interface.  See
.br
.I "MIDI Musical Instrument Digital Interface Specification 1.0" ,
IMA (the International MIDI Association) (1983)
.FE
The primary advantages of Adagio are its flexibility and ease of use as
well as the performance aspects of the Adagio interpreter.  However, it is
sufficiently primitive compared to CMN as to make it unsuitable for musical
analysis.
.H 1 "CONCLUSIONS"
.P 1
In the course of this review we have witnessed a surprising large range of
music input languages, ranging from primitive low-level sound generating
programs like MUSIC N, INV, and PLAY through to musical analysis
languages like P&E and ALMA to musical typesetting control languages
such as FCL.  In between are programmable languages such as PILE and MIR
and at the compositional level I have reviewed MUSPEC.
.P 1
It can be seen that different approaches and models used in developing
music languages and music performance systems can lead to radically
different designs with different features and limitations.  In a sense, the
diversity of music input languages parallels the diversity of sound
synthesis.  What remains to come is a general purpose music language that
combines the best features of all the above languages mentioned and allows
music performance as well.  While this is not difficult, the challenge to
preserve simplicity on top of an overall approach may prove to be an
interesting problem in computer language design.
.H 1 "BIBLIOGRAPHY AND REFERENCE"
.AL
.LI
.B "Dannenberg 1986"
.br
R. B. Dannenberg,
.I "The CMU MIDI Toolkit" ,
Charles Ives Edition,
Center for Art and Technology,
Carnegie Mellon University (1986).
.LI
.B "Loy 1985"
G. Loy, C. Abbott,
"Programming Languages for Computer Music Synthesis, Performance, and
Composition",
.I "ACM Computing Surveys" ,
Vol 17 No 2, June 1985
pp. 235 - 266
.LI
.B "Mathews 1985"
M. V. Mathews,
"Music V Manual",
.I "The Technology of Computer Music" ,
The MIT Press (1969)
pp. 115 - 172
.LI
.B "Roads 1985"
C. Roads, J. Strawn (eds.),
.I "Foundations of Computer Music" ,
The MIT Press (1985).
.LI
.B "Berg;Roads 1985"
P. Berg,
"PILE \*(EM A Language for Sound Synthesis",
originally
.I "Computer Music Journal" ,
3(1): 30-41 (1979),
reprinted
.B " " [ "Roads 1985" ]
pp. 160 - 187
.LI
.B "Buxton;Roads 1985"
W. Buxton et al,
"The Evolution of the SSSP Score-Editing Tools",
originally
.I "Computer Music Journal" ,
3(4): 14-25 (1979),
reprinted
.B " " [ "Roads 1985" ]
pp. 376 - 402
.LI
.B "Abbott;Roads 1985"
C. Abbott,
"A Software Approach to Interactive Processing of Musical Sound",
originally
.I "Computer Music Journal" ,
2(1): 19-23 (1978),
reprinted
.B " " [ "Roads 1985" ]
pp. 512 - 522
.LI
.B "Chadabe;Roads 1985"
J. Chadabe, R. Meyers,
"An Introduction to the PLAY Program",
originally
.I "Computer Music Journal" ,
2(1): 12-18 (1978),
revised and updated
.B " " [ "Roads 1985" ]
pp. 523 - 538
.LI
.B "Lincoln 1970"
H. B. Lincoln (ed),
.I "The Computer and Music" ,
Cornell University Press (1970).
.LI
.B "Citron;Lincoln 1970"
J. P. Citron,
"MUSPEC",
.B " " [ "Lincoln 1970" ]
pp. 97 - 111
.LI
.B "Kassler;Lincoln 1970"
M. Kassler,
"MIR \*(EM A Simple Programming Language for Musical Information
Retrieval",
.B " " [ "Lincoln 1970" ]
pp. 299 - 327
.LI
.B "Brook 1970"
B. S. Brook (ed),
.I "Musicology and the Computer" ,
"Musicology 1966 - 2000 : A Practical Program",
"Three Symposia",
American Musicological Society,
Greater New York Chapter (1965-1966),
The City University of New York Press (1970).
.LI
.B "Bauer-Mengelberg;Brook 1970"
S. Bauer-Mengelberg,
"The Ford-Columbia Input Language",
.B " " [ "Brook 1970" ]
pp. 48 - 52
.LI
.B "Brook;Brook 1970"
B. S. Brook,
"The Plaine and Easie Code",
.B " " [ "Brook 1970" ]
pp. 53 - 56
.LI
.B "Gould;Brook 1970"
M. J. Gould, G. W. Logemann,
"ALMA : Alphanumeric Language for Music Analysis",
.B " " [ "Brook 1970" ]
pp. 57 - 90
.LE
.TC
.CS
