# Rubato

A reconstruction of the RUBATO project, CS Honours 1987, Basser Department of
Computer Science, University of Sydney. Sole author: Chris Tham.

RUBATO is a musical description language and a system for performing music on a
computer. The three documents in `doc/` are the project's own: a literature
review surveying music input languages, a design document, and a tutorial
introduction to the language itself.

## What is here, and why

The files came out of `CHRISTIE.ARJ`, a December 1992 archive wrapping a May 1990
snapshot, and are extracted verbatim in `../christie/`. That tree is organised by
archive member — an artefact of how the backup was packed. This directory
regroups the same files by project.

| Here | From | Evidence |
| :-- | :-- | :-- |
| `doc/` | `christie/hons/doc/` | `.AU "Chris Tham" … .AT "CS Honours 1987" "Basser Department of Computer Science"` |
| `src/` | `christie/hons/mpu/` | see below |
| `drafts/` | `christie/music/`, `christie/work/proj/`, `christie/hons/musnotes/` | earlier drafts of the same three documents |

`src/` is assigned on the design document's own statement of its implementation
target. `music.mm` specifies the Roland **MPU-401 MIDI Processing Unit** with the
MIF-IPC interface card, driving a Roland **JX-8P** synthesiser, with RUBATO
written in C plus assembly routines for the MPU-401 interrupts. `src/` contains
exactly that — `mpu401.h`, `mpu401io.c`, `sequence.c`, `midi.h` — together with
`jx-8p.doc` and MPU data files for several pieces.

The drafts are kept separately because they are **not duplicates**: all four sets
differ. `doc/` holds the longest version of each document.

## Deliberately not included

- **`christie/cyacc/`** — asked about as a possible Rubato utility, but it is not
  related and not the author's work. Its `README` identifies it as the ANSI C
  grammar from the April 1985 draft standard, posted to Usenet by Jeff Lee of
  Georgia Tech.
- **`christie/hons/lispcpio/`** — a different subject. It is a Tiny C compiler in
  BruceLisp/Franz Lisp from a Compiler Techniques course, including a July 1987
  message from `brucee` about BruceLisp updates.
- **`christie/hons/midi/`** — the MIDI & SDLC project, which is a separate,
  five-author group project (Michael Barr-David, Fred Holmberg, Jason Lo, Chris
  Tham and Jarryl Wirth) submitted for the Computer Networks and Microprocessor
  Systems courses. Its user guide names RUBATO as a distinct honours project
  being developed alongside it, and as a potential source of the MIDI data its
  board would play.

## Third-party material

`drafts/musnotes/README` is not project documentation. It describes **cmusic**,
the CARL/UCSD music synthesis system — reference material gathered for the
literature review, and someone else's work.

## Building the documents

The documents are troff `-mm` source, as written for a VAX 11/780 running UNIX V8.

```sh
nroff -mm doc/rhl.mm | less
```
