.SA 1
.TL
RUBATO \*(EM
A Proposed Design for Performing Music on a computer
.AF "University of Sydney"
.AU "Chris Tham" CT SY "basser" 055 13 christie
.AT "CS Honours" "Department of Computer Science"
.MT 4 1
.AS 0
RUBATO will be set of tools that collectively allow a computer to perform music
using a notation that is compact and flexible.  The RUBATO system will consist
of a high level music compiler, an optional low level assembler and linker,
and a player
module implementing a virtual parallel machine that performs musical
pieces via interfacing hardware on a
conventional music synthesizer.  The RUBATO design uses the
MIDI (Musical Instrument Digital Interface) specification for
interconnection between computers and music synthesizer machines.
.AE
.OK "music performance" "compiler construction" "concurrent processing" "MIDI"
.nr Ej 1
.nr Cl 3
.H 1 INTRODUCTION
.P 1
Music performance using computers is a concept that has been explored and
realized before.  However, an efficient and
flexible means of entering and expressing music within the computer is
still to be found, and current efforts towards alleviating the problem are
unsatisfactory(\*F).
.FS
Of course, this is merely my own personal subjective opinion.  However, I
will try to justify this in the course of the project.
.FE
Indeed, most of the previous efforts at developing a language or notation
for expressing music within the computer can be likened to assembly
languages on the earliest computers, even though musical notation based on
the computer languages LISP and FORTH have been developed(\*F).
.FS
I believe, at the time of writing, there is a commercial music package
available on the IBM personal computers that features a built in LISP
interpreter called
.I "Personal Composer."
Also, the
.I "Acorn Music 500"
synthesizer add-on for the BBC home computer features
.I AMPLE
(Advanced Music Programming Language), a music language vaguely similar to
FORTH and LOGO.
.FE
Commercial music packages for computers are usually called
.I sequencers
which are mainly performance oriented and feature rudimentary music
notation, if any.
.P 1
A fundamental problem with expressing music into a computer is the nature
of music itself, especially Western 'classical' music.  A computer, or to
be exact, a
.I Von-Neumann
computer, is a sequential machine, and this is reflected in most computer
languages which are also sequential in nature.  However, music is
often thought of in parallel terms.
.I Polyphonic
music has many
.I voices
or parts that are performed concurrently, with each voice in synchronization
with all the other voices in such a way that the resultant combination
offers aesthetic pleasure to the ears.  Even in
.I monophonic
music, or music with only one voice, the performance of that music entails
the simultaneous control of many factors such as
loudness, timbre (brightness of tone), pitch and duration.  Any proposed
method of music notation has to take into account the inherent concurrent
nature of music.
.P 1
The proposed design, RUBATO, intends to overcome the above problems by
using established techniques in compiler construction and taking advantage
of recent research into parralel computation and the development of
concurrent languages.  Writing music into a computer is a process that can
be analogous to writing software that will be executed on a computing
machine.
For example, the music itself can be thought of as a set of algorithms
for 'playing' a piece and the computer as a virtual machine designed
to 'execute' these algorithms, i.e. 'play' music.  Given these analogies, it
can be easily seen that music notation therefore can be likened to a
computer language for expressing musical algorithms.
.P 1
The design of RUBATO can be viewed as the design of a virtual computer
system that exist to play music.  Music is expressed in a high-level
language that allows concurrent processing with syncronization.  This
language will be similar to modern structured high level computer
languages.  The RUBATO
.I compiler
will attempt to translate the high level
music language into a low level language that resembles assembly language
on physical computers.  This assembly language will be further translated
by the
.I assembler
into 'executable' code.
There may also exist a RUBATO
.I linker
to merge portions of music compiled and assembled separately into a whole.
Finally, at the end of the chain, the RUBATO
.I player
or interpreter attempts to execute RUBATO object code by simulating a
virtual music playing machine using the computer's native code and
supporting hardware.  This 'performance' will then be interpreted by human
ears as the playing of said music by the computer.
.P 1
The reader may now conceivably ask: "Why do I have to use
RUBATO and deal with abstract concepts such as
compilers and assemblers?  Why not stick with existing designs?"
.P 1
Well, for
a start, existing musical languages for computers can be clumsy, inflexible
and incredibly tedious to use(\*F).
.FS
Well, for now you will just have to take my word for it.  I have personally
used about 5 music packages and have found them all tedious and primitive.
Of course, this does not necessarily imply that the same holds for ALL music
languages.
.FE
Control structures that indicate the flow of music are often primitive, of
the LOOP and GOTO variety, and each musical note has to be painstakingly
specified in detail.  Common musical elements such as
.I trills ,
.I appogiaturas
often have to be expanded into individual notes.  Accents,
.I staccatos
and
.I legatos ,
and phrasing often have to be specified manually for each note even if they
occur in a fixed rhythmic pattern and effects
such as
.I crescendo / diminuendo
(loudness increment and decrement)
and
.I ritardando
(slowing down of a musical phrase)
have to be manually created by altering the duration and loudness of each
indivual note affected.
The design of RUBATO will take all this into account and will feature
abstraction of common musical concepts into
.I templates
or
functions
that than be filled by notes and phrases.  RUBATO will also be structured
and typed, allowing human readability of the musical notation.  In
addition, RUBATO will also try to be as compact as possible, defaulting to
some reasonable values if full details are not given for each note or
phrase.
.H 1 "IMPLEMENTATION"
.P 1
A few years ago, RUBATO will have to be implemented on a minicomputer using
expensive dedicated hardware for sound generation.  Most early music
performance software tend to be
totally dependent on the supporting hardware and inherently
difficult to port across to another environment.  However, with the advent
of MIDI (Musical Instrument Digital Interface)(\*F),
.FS
For further details,
refer to the document
.B "MIDI Specification 1.0"
(Doc. MIDI-1.0) (c) August 5, 1983
by the International MIDI Association (IMA), a conglomerate of
representatives from major music synthesizer manufacturers.
.FE
computers can be connected to a wide variety of music synthesizers and
sound producing / enhancing equipment in a relatively hardware independent
manner.  By following the constraints of MIDI, RUBATO can be essentially
hardware independent.
.P 1
It is envisaged that the initial prototype of RUBATO will be implemented on
the
.B "IBM PC/XT Personal Computer"
running under the
.B MS-DOS
3.20 operating system.  Sound
generation will be achieved using a
.B "Roland JX-8P Polyphonic Synthesizer"
which has an extensive MIDI implementation and 6 dual DCO
(Digitally Controlled Oscillator)
voices.  The MIDI
interface between the PC/XT and the JX-8P will be the
.B "Roland MPU-401 Midi Processing Unit"
with the
.B "Roland MIF-IPC Interface Card".
The MPU-401 is an intelligent interface that is programmable and the design
of the RUBATO assembler and player modules will be heavily based on the
design of this unit.
.P 1
RUBATO will be developed using the
.B "C Programming Language"
with assembly support routines for handling the MPU-401 interrupts.  The
development work will be done on the host machine itself using host
development utilities.  If necessary, additional development utilities
available on the UNIX operating system will be used via a VAX 11/780
system running UNIX V8.
.P 1
It is anticipated that the initial implementation of RUBATO will consist of
the compiler and player only.  The compiler will generate songfiles
directly executable by the player.  In future implementations, the
assembler and linker will also be developed.
.H 1 "A TECHNICAL OVERVIEW OF MIDI AND THE MPU-401 COMMAND SET"
.P 1
For readers who are not familiar with recent developments in music
synthesizer technology, a brief description of the nature and capabilities
of MIDI as well as the features available in the Roland MPU-401 MIDI
Processing Unit is presented here.
.P 1
In a nutshell, MIDI 1.0 is a data interconnection standard between
electronic musical instruments (and computers equipped with appropriate
interfacing hardware) that was proposed by the International MIDI
Association in August 1983 and has since been adopted by major
international electronic music equipment manufacturers.  It is both a
hardware and software standard.  The hardware standard specifies two 1.5 mA
current loop circuits (one for receiving, the other for transmitting) with
receiver optoisolation operating asynchronously at 31.25 kilobauds with 1
start bit, 8 data bits, and 1 stop bit.  The software standard specifies
the exact format of
.I "MIDI messages"
or valid MIDI data that is recognized in the MIDI stream.
.P 1
Multiple instruments can be connected into a MIDI network simply by daisy
chaining them together, but the most typical setup is a master-slave or
master-slaves configuration whereby a transmitting instrument (often a
synthesizer keyboard but can also be a computer under proper software, i.e.
RUBATO) sends commands to listening slave units daisy chained.
The MIDI software standard also defines 16 virtual
.I channels
on the single transmitting/receiving cable pair.  Each slave unit can be
made to 'listen' on a separate channel or a group of channels to allow
control in master-slaves configurations.
All MIDI communication is achieved through multi-byte MIDI messages.  Each
MIDI message, or 'command', consists of one status byte indicating the type
of command (which may also include the channel the command is directed to),
followed by up to two 'data' bytes.
.P 1
Commands currently available include note on/off commands that corresponds
to a keyboard player hitting and releasing a note on a music keyboard, key
pressure/aftertouch information, control (modulation) changes and timbre
(program) changes.  In addition, there are system messages that indicate
song position and song selection (mainly for drum machines), timing clock,
tuning, system reset and active sensing (a 'test' byte to verify that the
connection is still active).  Instruments may operate in a variety of set
'modes'.  In
.I OMNI
mode, instruments receive and act upon messages from all
channels, otherwise intruments will ignore all channels other than the one
they are assigned on.  Instruments may also be either in
.I Poly
or
.I Mono
mode (whether the instrument can play more than one voice at a given time).
.P 1
There is also a
.I "System Exclusive"
mode that allows free form data to be sent over the MIDI connection.  This
is not standardized and allow a manufacturer to send out dumps of internal
machine information to a backup device.
.P 1
The Roland MPU-401 MIDI Processing Unit is an intelligent MIDI interface
that is essentially computer-independent.  It buffers outgoing and incoming
MIDI data and features a manufacturer independent connector to the
computer.  All that is necessary for a computer to be connected to this
interface is some basic hardware that sends and receives signals to and
from this connector.  The MPU-401 requires an extra 'time' byte from MIDI
messages sent from the computer.  This time byte specifies the MPU-401 to
delay the
MIDI message for a certain amount of time AFTER the previous message before
sending it off on the MIDI circuit.  Hence a note can be played on a
synthesizer by sending two commands to the MPU-401, a 'note-on' command to
be sent off immediately, and a 'note-off' command to be sent after a given
period.
.P 1
The MPU-401 also implements 8 virtual 'tracks', each corresponding to a
virtual MIDI interface talking via a specific MIDI channel.  Tracks operate
in a pseudo-concurrent fashion, and the availability of this feature on the
MPU-401 greatly simplifies the design of the RUBATO player module.
The MPU-401 also has many other complex commands available that are not
derived from MIDI messages but I will not go through them here.  Further
details may be obtained from the
.B
"Roland MPU-401 Technical Reference Manual" .
.H 1 "SOME BASIC TERMINOLOGY TO BE USED BY RUBATO"
In order to explain RUBATO's design, some terminology will have to be
defined.  Whenever possible, the terminology used will be derived from
either computer science or music, whenever appropriate.
.VL 20 5
.LI note
A note is the most primitive concept in RUBATO and is analogous to a
machine instruction in a computer.  Unlike machine instructions, however, a
note has associated with it various attributes or characteristics that are
inherent to the production of music.  See the section below on note
attributes.
.LI chord
This is simply a set of notes meant to be sounded together.  However, not
all the notes in a chord may last for the same amount of time or even
possess the same attributes.  The notion of a chord is simply a convenient
way of expressing musical harmony as all the notes in a chord are related.
.LI phrase
A phrase is just a related set of notes to be played in sequence
that form a musical phrase or
sentence.  In RUBATO, phrases may be named and may possess attributes
similar to note attributes except they apply to the collection of notes
taken as a whole.
.LI template
A template is a structure on which notes, chords and phrases should fall
into.  Templates are analogous to 'procedures' or 'functions' in a high-level
programming language and may contain control flow and syncronization
commands.
Templates are yet another abstraction that allow a set of notes to
be treated as a group.
.LI track
This is essentially a musical 'line' or 'voice' running independently from
other voices.  A track can contain notes, chords, phrases, templates
together with control flow structures and synchronization primitives.
Each track is completely independent in RUBATO, with its own
set of defaults and settings, and can be likened to a 'process' in a
parallel computing machine.  Note, however, that tracks are just a useful
and convenient abstraction within RUBATO and does not necessarily
correspond to a physical structure(\*F).
.FS
Although it is envisaged that in the actual implementation, each RUBATO
track will probably correspond to a MPU-401 track and a given MIDI channel.
.FE
It is possible for tracks to be merged
together and a given track may contain notes to be sounded simultaneously
at a given time.
.LI conductor
This is the 'master' track, or the track that initiates and controls all
other tracks.  The conductor may be likened to the operating system of our
hypothetical parallel machine.  The conductor is also responsible for
assigning available hardware resources (MIDI channel or MPU-401 track) to
tracks and controlling synchronization between tracks.
.LI song
This is the music piece that has to be performed by the computer, and
corresponds to a computer program.  Songs are built up from individual
tracks plus the conductor track.
.LE
.P 1
Note attributes taken as a whole define a single note in a musical piece.
Adjacent notes in a musical phrase often share the same attributes, and
hence those attributes really belong to the phrase rather than the note
itself.
.AL
.LI
The
.B pitch
of a note is the frequency at which the note will sound, and is often
regarded as the dominant characteristic of the note.  However, it must be
stressed that the frequency of a note need not be fixed but can vary over
time (e.g. effects such as
.I vibrato
and even
.I portamento).
A note with a varying pitch is still considered a note.
.LI
The
.B duration
of a note is time between the current note and the next note in sequence.
.LI
The
.B length
of a note is the length of time during which the note will sound, i.e.
the time interval in which the note is played on a musical instrument.
Notice that this is a different concept to duration.  A note with a small
length relative to it's duration will be a staccato note.  A note with
equal length and duration is known as a legato note.  Notes with lengths
longer than their durations will overlap with the next note.
.LI
The
.B loudness
or
.B volume
of a note is the perceived intensity of the note when sounded.  This
corresponds to the velocity of a key struck on a music synthesizer.  A
related attribute, commonly referred to as 'pressure' or 'after touch' on
music synthesizers, is the force applied to a struck note and may vary over
time.  Often, on many synthesizers, pressure may not be an independent
attribute but is shared
by all notes currently being held down.
.LI
Each note may also have a distinct
.B timbre
of harmonics associated with a note.  The timbre affects the way the note
sounds to human ears and allow us to distinguish between a note bowed on a
stringed instrument such as a violin, or a note blown from a trumpet, or a
note struck from a piano.  The timbre of a note may change over time.
.LI
In addition to the above attributes, on most commercial synthesizers, a note
or notes may possess additional attributes known as
.B "modulated controls".
A synthesizer may possess continuously adjustable controls such as pitch
bend and modulation wheels and breath controllers that further colour a
given note or notes.
.LE
.H 1 "RUBATO COMPONENTS"
The following are the major modules of RUBATO and what they do:
.H 2 "Compiler"
This compiles a track written in the RUBATO high level language into
the RUBATO assembly language suitable for the assembler.  A RUBATO track is
written using structured typed coding procedures similar to modern block
structured computer languages.  Notes, chords and phrases corresponds to a
given type in a computer language and templates corresponds to functions or
procedures.  Variables, global as well as local, can be defined and control
flow structures will be familiar to Pascal or C programmers.  The RUBATO
high level language is portable and stable across implementations.
.H 2 "Assembler"
The RUBATO assembler accepts assembly instructions in the one instruction
per line format common to most assemblers for computer systems.  Each
assembler instruction correspond to a musical event, such as a command to
start playing a note or a command to turn on a particular attribute or set
it to a certain value.  Assembler instructions will generally be MIDI
information events or MPU-401 commands with some low level control flow
instructions.  Mutual exclusion and other synchronization primitives as
well as RUBATO variables may also be implemented here.  The design of the
assembly language need not be hardware independent but with a little care
it can be made independent of most hardware idiosyncracies.
.H 2 Linker
The optional RUBATO linker will link up separately compiled and assembled
tracks into a song that can be 'executed' by the player module.  External
declarations and references can be resolved at this stage.
.H 2 Player
This is a simulation of the RUBATO virtual music performance machine.
Essentially, it executes song files in the host environment and plays music
on the music hardware.  Song files or 'object' files are usually pure MIDI
or MPU-401 streams with some support for RUBATO control flow,
synchronization and variables.  Note that the player module can be an
independent program on the host environment or lumped together with all the
other RUBATO modules.  Another alternative is to link the song file
together with the player code to form a 'song' that is directly executable
from the host environment.  In that case, the host object file linker may
be used in place of the RUBATO linker.
.H 1 "HIGH LEVEL LANGUAGE DESCRIPTION"
This is yet to be finalized.  Also to be finalized are assembly and object
code formats as well as the format of a player song file.  Hence I will
simply present in this section, for the time being, a user's tour through
some of the features of RUBATO's high level language.  The discussion will
be strictly casual, with the intention of becoming more formalized in the
future.  Some implementation hints may also be discussed.
.P 1
We begin with the simplest object of all, the note.  In the RUBATO High
Level Language, simply called RHL from now on, a note can be specified by
its pitch and any other attributes that may be tacked on as belonging to
the note.  The only required attribute is the pitch.  If the other
attributes are not specified, they will default to the current settings.
A note description, then, consists of a pitch descriptor followed by other
attributes separated by white space on a single text line.
.P 1
Currently, attributes of a note that may be specified are
.DL
.LI
Pitch (this will be related to the current key signature)
.LI
Loudness (or velocity of key struck)
.LI
Length (time interval in which the note will sound)
.LI
Duration (time interval before next note)
.LI
Patch (or timbre of the note) PROVISIONAL
.LI
Channel (MIDI Channel number) PROVISIONAL
.LE
.P 1
Here are some examples:
.VL 20 0
.LI "c"
plays the C note at the current default octave and attribute settings.
.LI "c4"
plays the C note at the 4th octave at the current default settings.
.LI "c4#^"
plays the C-sharp note accented at default settings.
.LI "notenum|100"
plays the note with the MIDI value of 100.
.LI "c mp whole"
plays the C note at medium pianissimo loudness and with duration and length
of a whole
note at the current tempo.
.LI "c whole half"
plays the C note with the length of a whole note but the duration of a half
note.
.LI "c (whole*5+quarter)"
plays the C note with duration and length equal to 5 whole notes plus 1
quarter note.
.LE
.P 1
As can be seen from the last example, a note may contain an expression in
place of an attribute.  Hence quite complex notes can be defined.  In
general, attributes can be placed in any order, but if both duration and
length are to be specified, the length must be specified before the
duration as there is no way of otherwise distinguishing between the length
and the duration attribute.  The exact nature of attribute expressions will
be discussed later.
.P 1
A block of notes is simply a set of notes, each on a different line,
delimited by braces:
.DS
{
	c
	d
	e
	f
	g
}
.DE
Note that RUBATO input is not completely free-form as newlines are
considered significant.  However, the above block can be made more consise
by using the ';' character replacing the newline:
.DS
{ c; d; e; f; g }
.DE
The ';' character is not necessarily after a '{' or before a '}'.
.P 1
Given the above, phrases and chords can be easily constructed:
.DS
phrase eighth mf
{
	c
	d
	e quarter
	c
	e
	c
	e half
}

chord half f { c; e; g }
.DE
Note that the phrase or chord may have attributes, these attributes apply
to all notes within the block defined by the phrase or chord.  Note that in
the above example phrase, the third and last note have different duration
and length attributes from the rest of the notes in the block.  Such
attributes override the phrase attributes temporarily.
.P 1
A phrase or a chord can be named and then referenced by the name, as well
as contain nested blocks:
.DS
phrase eighth
{
	chord whole { c; e; g } cmajor
	phrase
	{
		c
		d
		e
		f
		g
		a
		b
	}
	cmajor
} ditty
.DE
The above example defines and plays a phrase called
.I ditty
which contains the chord definition
.I cmajor
which is played at the beginning and the end of the phrase.
.P 1
There are also integer variables which can be defined and set to any
attribute value:
.DS
{
	var	highnote
	var	longduration

	set highnote = c7
	set longduration = whole*10

	highnote longduration
	d longduration
}
.DE
Variables, named phrases and chords are local to the block unless declared
to be
.I public .
.P 1
Default values may be set that will apply to the rest of the block until
changed:
.DS
{
	default eighth pp
	key f#
	measure quarter*4

	define phrase { f; g; a; b; c } ascend

	ascend
	ascend
	phrase { c; b; a; g; f } descend
}
.DE
In the above example, the rest of the block will be in the F-sharp key with
4/4 time signature (as indicated by the
.I measure
statement).  Notes will normally be eighth notes and will be very soft in
loudness (pp).  A phrase is defined but not played.  Then it is played
twice before another phrase is defined and played.
.P 1
A function called random may also be used effectively in attribute
expressions.  For example specifying an attribute of random(quarter) will
generate a random duration/length up to a quarter note in length.
.P 1
In general, most 'C' operators such as '+', '-', '*', '/', '&', '|', and so
on can be used in RUBATO expressions.  Expressions can be also be used in
conditional control flow statements:
.DS
{
	var	aa
	set aa = random(half)

	if (aa < quarter)
	{
		c
		chord { e; g }
	}
	else
	{
		while (aa < quarter)
		{
			c aa
			set aa = aa - 1
		}
	}
}
.DE
.P 1
RUBATO will also have synchronization primitives.  Currently, semaphores
and message passing functions are being considered for inclusion in RUBATO.
.P 1
Attributes may be dynamically changed in RUBATO:
.DS
	change mp to mf by whole*5
	change half to whole for 5
.DE
The first change statement will slowly increase the loudness of notes
played over the duration of 5 whole notes wherease the second change
statement will slow down the next 5 notes from half notes to whole notes.
.P 1
A note on the implementation of the RHL:
.P 1
Notes attributes are simply integers greater than 16 bits in width.  The
lower eight bits are used to specify the value of the attribute and the
other bits are used to distinguish between attributes.  Only 8 bits are
needed to specify an attribute due to MIDI's inherent 8 bit design.  The
only attribute that could conceivably need more than 8 bits for
representation is the duration/length attribute.  Hence, the sign bit of a
machine word can be used to distinguish between duration/length attributes
(in which the whole word is significant, except for the sign bit), and
other attributes (including pitch) in which only the lower 8 bits are used
to specify the attribute value, and all higher bits are used to distinguish
between attributes.
.P 1
Given the above insight, it can be readily seen that the RHL can be easily
parsed by a recursive descent parser provided a suitable preprocessing or
tokenizing phase is undergone beforehand.  Hence the compiler can be
designed in a relatively small period of time.  Variables and expressions
will have to be evaluated by the player rather than the compiler, hence the
player will probably need a stack based architecture.
.H 1 "IMPLICATIONS"
RUBATO may be the key to an effective and realistic way to perform music on
computers.  If RUBATO should prove successful, the implications will
transcend musical performance.  Already there exist a myriad number of MIDI
devices only casually related to music production.  Since RUBATO generates
MIDI streams, it can be used to control devices such as MIDI light
controllers, MIDI sound effect processors, MIDI recording equipment and so
on.  There are a number of devices that can convert MIDI information to and
from SMPTE, the industry standard video synchronization code and hence
RUBATO can be used to control video images just as effectively
as playing music.
