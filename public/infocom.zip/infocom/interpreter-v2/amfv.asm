;IBM Plus Series executor. Disassembly completed 11th May 1987
;



esc		equ	1bh			; Escape code
screen_seg	equ	0b800h			; Screen segment

cseg		segment	para public 'Code'

		org	100h			; COM file

		assume	cs:cseg,ds:cseg,es:cseg,ss:cseg

amfv		proc	near			; Here goes!

start:		jmp	begin


dat_name	db	'AMFV.DAT',0		; Name of the game datafile
		db	38h dup (0)

sav_name	db	'AMFV.SAV',0		; Saved game name
		db	37h dup (0)

sav_name2	db	40h dup (0)		; Temp storage for save name

l01c4		dw	0
dat_handle	dw	0
sav_handle	dw	0

		db	'SETUP.INF',0

l01d4		dw	0
l01d6		db	0
l01d7		db	0

sav_drive	db	0
defdrvflg	db	0
sav_drive2	db	0
def2drvflg	db	0
l01dc		dw	0
l01de		dw	1
readwrite	db	0		; 0 = read, 1 = write
cp_saved	db	0		; 0 = scp not done. 1 = scp done
text_attrib	db	7		; Text attribute
mono		db	0
scrnlrx		db	80		; Width of screen
l01e5		db	18h
l01e6		db	0fah,1,0ffh,1,7,2,0,0,0fah,1
l01f0		db	0fah,1,0ffh,1,7,2,0,0,0fh,2
		db	4
		db	esc,'[0m'	; All attributes off
		db	7
		db	esc,'[37;7m'	; Inverse white
		db	7
		db	esc,'[37;1m'	; Bold white
		db	7
		db	esc,'[37;4m'	; Underlined white
l0217		db	'!'
		db	2,0ffh,1,7,2,0,0
		db	'!'
		db	2,0ch
		db	esc,'[0m'	; All attributes off
		db	esc,'[37;44m'	; White on blue

eraseln_ansi	db	3
		db	esc,'[K'	; Erase line
scp_ansi		db	3
		db	esc,'[s'	; Save cursor position
rcp_ansi		db	3
		db	esc,'[u'	; Restore cursor position
clstlhs_ansi	db	10h
		db	esc,'[2J'	; CLS
		db	esc,'[0m'	; All attributes off
		db	esc,'[01;01H'	; Move cursor to (1,1)
allattoff_ansi	db	4
		db	esc,'[0m'	; All attrributes off
		db	0
colclstlhs_ansi	db	14h
		db	esc,'[37;44m'	; White on blue
		db	esc,'[2J'	; CLS
		db	esc,'[01;01H'	; Move cursor to (1,1)
		db	0,0
clsblhs_ansi	db	0ch
		db	esc,'[2J'	; CLS
		db	esc,'['
l026f		db	'25;01H'	; Move to (1,25)
colclsblhs_ansi	db	14h
		db	esc,'[37;44m'	; White on blue
		db	esc,'[2J'	; CLS
		db	esc,'['
l0284		db	'25;01H'	; Move to (1,25)
storyload_ansi	db	1fh
		db	esc,'[12;28HThe story is loading...'
tlhs_ansi	db	8
		db	esc,'[01;01H'	; Move to (1,1)
coltlhs_ansi	db	10h
		db	esc,'[01;01H'	; Move to (1,1)
		db	esc,'[37;44m'	; White on blue
allattoff2_ansi	db	4
		db	esc,'[0m'	; All attributes off
col_ansii	db	8
		db	esc,'[37;44m'	; White on blue

ten		db	0ah		; Used for division by 10

error		db	0		; Tells pchar not to script it
script		db	0		; Tells pchar to lprint it
noprinter	db	0		; No printer flag

noprint		db	' %Printer not ready: Abort or Retry? ',80h

hourmin		dw	0
sechund		dw	0
random_divisor	dw	0

l0302		db	0
l0303		dw	0
l0305		db	0,0,0,0,0,0,0,0,0,0
l030f		dw	0
l0311		dw	0
l0313		dw	0
l0315		db	0
spwrd_base		dw	0
l0318		dw	0
obufptr		dw	0
l031c		dw	0
l031e		db	'O'
		db	0
l0320		db	1
l0321		db	1
l0322		dw	0
l0324		dw	0
l0326		dw	0
l0328		dw	0
l032a		db	1
l032b		db	' '
		db	9,0dh,0ch
		db	'.,?'
		db	0
l0333		dw	0
pagea		dw	0
l0337		dw	0

vocab_pointer	dw	0		; Pointer to vocabulary
orlist_pointer	dw	0		; Pointer to object/room list
glovar_pointer	dw	0		; Pointer to global variable table
spwrd_pointer	dw	0		; Pointer to special word table

l0341		dw	0
l0343		dw	0
l0345		dw	0
l0347		dw	0
l0349		dw	0
outbuff		db	81 dup (?)	; Output buffer
ibuff		db	0,0
l039e		db	78 dup (?)	; Input buffer

l03ec		db	0,0,0,0,0,0,0,0,0,0,0,0,0
		db	0,0,0,0,0,0,0

l0400		db	0,0,0,0,0,0,0,0,0,0,0,0
l040c		dw	0
datoffset	dw	0
keytoggle		db	0
l0411		db	0feh,0ffh,0,0,0,0,0,0
switches	db	0
l041a		dw	0
lvarptr		dw	0
pc_page		dw	0
pc		dw	0
highaddrflg	db	0
l0423		db	0

param1		dw	0		; Parameters. These must be
param2		dw	0		;  kept together in this order
param3		dw	0		;  for the multi-parameter instruction
param4		dw	0		;  reentry and linein to work

		db	0,0,0,0,0,0,0,0,0,0

l0436		dw	0
l0438		dw	0
l043a		dw	0
l043c		dw	0
l043e		dw	0
l0440		dw	0
l0442		dw	0
datbuf		dw	0
lowseg		dw	0
l0448		dw	0
linecount	db	0
alldatin	db	0
l044c		db	0
l044d		db	0
l044e		db	0
l044f		db	0
l0450		db	0
attrib		db	17h
l0452		db	0
l0453		db	0

beep_table	dw	beep1	;l0454
		dw	beep2

l0458		dw	0

;---------------- V E C T O R S 0 -------------------

vectors0	dw	rettrue
		dw	retfalse
		dw	ilprint
		dw	ilprtcr
		dw	null
		dw	save
		dw	restore
		dw	restart
		dw	rettos
		dw	popnil
		dw	quit
		dw	newline
		dw	0
		dw	verify
		dw	0
		dw	0

;-------------------- V E C T O R S 1 --------------------

vectors1	dw	cpzero
		dw	getwith
		dw	getholds
		dw	getloc
		dw	getplen
		dw	inc
		dw	dec
		dw	print
		dw	l1f96
		dw	delete
		dw	pobj
		dw	return
		dw	jump
		dw	print2
		dw	ldvarvar
		dw	not

;-------------------- V E C T O R S 2 --------------------

vectors2	dw	0
		dw	mwcomp
		dw	ltoe
		dw	gtoe
		dw	decchk
		dw	incchk
		dw	chkloc
		dw	bit
		dw	or
		dw	and
		dw	bitchk
		dw	biton
		dw	bitoff
		dw	ldvar
		dw	transfer
		dw	get16
		dw	get8
		dw	getprop
		dw	getpaddr
		dw	getnprop
		dw	add
		dw	sub
		dw	mult
		dw	div
		dw	mod
		dw	call
		dw	0
		dw	0
		dw	0
		dw	0
		dw	0
		dw	0

; -------------------- V E C T O R S 3 --------------------

		dw	call
		dw	put16
		dw	put8
		dw	putprop
		dw	input
		dw	printchar
		dw	printnum
		dw	random
		dw	push
		dw	pop
		dw	l103a
		dw	l1001
		dw	call
		dw	l10bf
		dw	eraseln
		dw	setcursorpos
		dw	null2
		dw	pnextchar
		dw	l1c93
		dw	l1cbd
		dw	null3
		dw	beep
		dw	l1d87
		dw	l188f
		dw	0
		dw	0
		dw	0
		dw	0
		dw	0
		dw	0
		dw	0

	db	0,0,3,0
	db	'COMPAQ Co$'
l0526	db	'COPR. IBM$'
	db	'Tandy Cor$'
l053a	db	0
l053b	db	1
l053c	db	0,0
scrnlry	db	0,0

l0540	db	'[MORE]',80h
l0547	db	0dh
	db	'         '
	db	0dh,80h
l0553	db	0,0

version_msg		db	80h,'IBM/PC-DOS 2.0 Interpreter Version A20',0

l057d		db	'Do you want color (Y/N)? ',80h
enterfname_msg	db	'Insert save disk then enter file name.',0
defaultis_msg	db	'(Default is ',80h
brackets_msg	db	'): ',80h
insertdat_msg		db	'Insert game disk then strike any key to continue.',0
savnotfnd_msg		db	'SAVE file not found',0
		db	'Bad file name syntax',0
noaccess_msg	db	'Unable to access file',0
noroom_msg		db	'No room on diskette for SAVE file',0
savrdfailed_msg		db	'Read of SAVE file failed',0
toomanywrds_msg		db	'Too many words typed, flushing: ',80h
nosuchprop_msg		db	'No such property',0
wrngvers_msg		db	'Wrong game or version',0
illegalop_msg		db	'Illegal operation',0
nofreepages_msg		db	'No free pages',0
datrdfailed_msg		db	'Game file read error',0
datnotfnd_msg		db	'Game file not found',0
		db	'Unauthorized copy',0
dosver		db	'Wrong DOS version.  Must be 2.0 or higher',0
nomemory	db	'Insufficient memory to play game',0
		db	'Illegal argument',0
l077a		db	'Screen must be 80 characters wide',0
fatal		db	'Fatal error: ',80h

asciicodes	db	'abcdefghijklmnopqrstuvwxyz'
		db	'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
		db	'  0123456789.,!?_#''"/\-:()'

	db	0
l07f9	db	0,0,0,0,0,0,0,0
l0801	db	0,0,0,0,0
l0806	db	0,0,0
l0809	db	0,0,0,0,0,0,0,0,0,0,0,0
l0815	db	0,0,0,0,0,0,0,0,0,0,0,0,0
	db	0,0,0,0,0,0,0,0,0,0
l082c	db	0,0,0,0
l0830	db	0,0,0,0
l0834	db	0,0,0,0
l0838	db	0,0,0,0
l083c	db	0,0,0,0,0,0,0,0,0,0,0,0,0
	db	943 dup (0)

stack	db	1000 dup (?)

l0fe0	db	0,0,0,0,0,0,0,0,0,0,0,0,0
	db	0,0,0,0,0,0,0,0,0,0,0


begin:	mov	sp,offset stack
	mov	di,offset begin
	jmp	begin2

l1001:	mov	byte ptr l0450,al
	test	al,al
	jz	l1021
	mov	byte ptr script,1
	call	scp
	mov	bx,offset tlhs_ansi
	test	byte ptr mono,1
	jz	l101d
	mov	bx,offset coltlhs_ansi
l101d:	call	ansi
	ret

l1021:	mov	byte ptr script,0
	call	rcp
	mov	bx,offset allattoff2_ansi
	test	byte ptr mono,1
	jz	l1036
	mov	bx,offset col_ansii
l1036:	call	ansi
	ret

l103a:	xor	ah,ah
	cmp	al,0
	jnz	l1055
	call	rcp
	mov	byte ptr l0452,0
	mov	ax,word ptr l053c
	mov	word ptr scrnlry,ax
	mov	word ptr l0553,0
	ret

l1055:	mov	byte ptr l0452,1
	cmp	al,byte ptr l01e5
	jng	l1065
	mov	al,byte ptr l01e5
	dec	al
l1065:	xchg	ah,al
	add	word ptr scrnlry,ax
	push	ax
	call	scp
	mov	bh,byte ptr text_attrib
	test	byte ptr mono,1
	jz	l107e
	mov	bh,byte ptr attrib
l107e:	pop	ax
	mov	dh,ah
	dec	dh
	mov	ah,6
	mov	al,0
	mov	cx,word ptr l053c
	mov	dl,byte ptr scrnlrx
	dec	dl
	int	10h
	call	rcp
	ret

;-------------------- S C P --------------------

scp:	test	byte ptr cp_saved,1	; 1097
	jz	scp_ok
	ret

scp_ok:	mov	bx,offset scp_ansi	;l109f
	call	ansi
	mov	byte ptr cp_saved,1
	ret

;-------------------- R C P --------------------

rcp:	test	byte ptr cp_saved,1	; 10ab
	jnz	rcp_ok
	ret

rcp_ok:	mov	bx,offset rcp_ansi	; 10b3
	call	ansi
	mov	byte ptr cp_saved,0
	ret

;-------------------- --------------------

l10bf:	cmp	al,0ffh
	jnz	l10cb
	mov	al,0
	call	l103a
	call	l1163
l10cb:	cmp	al,1
	jnz	l10f4
	mov	dx,word ptr scrnlry
	dec	dh
	mov	dl,byte ptr scrnlrx
	dec	dl
	mov	cx,0
l10de:	mov	al,0
	mov	ah,6
	mov	bh,byte ptr text_attrib
	test	byte ptr mono,1
	jz	l10f1
	mov	bh,byte ptr attrib
l10f1:	int	10h
	ret

l10f4:	cmp	al,0
	jz	l10f9
	ret

l10f9:	mov	cx,word ptr scrnlry
	mov	dx,184fh				; CHECK THIS !!!!
	jmp	short l10de

;-------------------- E R A S E L N --------------------

eraseln:cmp	al,1	;1102		; (V) Erases line cursor is at
	jz	eraseln2
	ret

eraseln2:				;l1107
	mov	bx,offset eraseln_ansi
	call	ansi 
	ret

;-------------------- S E T C U R S O R P O S --------------------

setcursorpos:				; (V) Set the cursor position
	test	byte ptr l0320,1
	jnz	l1133
	test	byte ptr l0450,1
	jz	l1133
	call	escbracket
	call	ansiidec		; Put param1 in decimal to ansi
	mov	dl,';'
	mov	ah,2
	int	21h
	mov	ax,bx			; Put param2 in decimal to ansi
	call	ansiidec
	mov	dl,'H'			; Set cursor position code
	mov	ah,2			; Print it to ansi
	int	21h
l1133:	ret

escbracket:			;1134
	push	ax
	push	dx
	mov	dl,esc
	mov	ah,2			; Print an escape to ansi
	int	21h
	mov	dl,'['			; Print the square bracket to ansi
	int	21h
	pop	dx
	pop	ax
	ret

ansiidec:
	push	bx
	xor	dx,dx
	mov	bx,0ah
	idiv	bx
	add	dl,30h
	add	al,'0'	;30h
	push	dx
	mov	dl,al
	mov	ah,2
	int	21h
	pop	dx
	mov	ah,2
	int	21h
	pop	bx
	ret

;-------------------- N U L L 2 --------------------

null2:	ret

;-------------------- P N E X T C H A R --------------------

pnextchar:
	inc	ax
	jmp	pchar

l1163:	mov	bx,offset clsblhs_ansi
	cmp	byte ptr mono,1
	jnz	l1170
	mov	bx,offset colclsblhs_ansi
l1170:	call	ansi
	ret

;-------------------- B E E P --------------------

beep:	or	ax,ax			; (V) Make a beep
	jz	beep_done		; Param1 is 1 or 2 
	cmp	ax,3
	jnb	beep_done
	dec	ax			; Make param1 0 or 1
	shl	ax,1			; Double it
	mov	bp,ax
	mov	si,ds:beep_table[bp]	; Get the address of the routine
	call	si			; Call the appropriate beep
beep_done:			;l1189
	ret

beep1:	mov	cx,1200		;118a
	mov	dx,1
	jmp	sound

beep2:	mov	cx,600		;1193
	mov	dx,5
	jmp	sound

;-------------------- V E R I F Y --------------------

verify:	call	clopdat			; (V) Verifies game file
	push	ax
	mov	ax,offset version_msg
	call	pmsg
	pop	ax

	cmp	byte ptr alldatin,1
	jnz	verify1
	jmp	short verify2
	nop

verify1:mov	ax,es:[1ah]  ;11b1
	xchg	ah,al
	mov	byte ptr l0423,1
	push	si
	push	di
	push	word ptr pagea
	call	l22fb
	mov	si,ax
	sub	bx,2
	mov	di,bx
	call	l2e3c
	mov	bx,word ptr l043a
	sub	bx,2
	mov	ax,word ptr l0438
	mov	word ptr [bx],ax
	mov	ax,-1
	mov	word ptr 2[bx],ax
	mov	word ptr 4[bx],ax
	mov	ax,0
	mov	bx,40h
	mov	dx,0
	mov	word ptr pagea,0
l11f3:	push	si
	push	di
	push	dx
	cmp	byte ptr l044d,1
	jnz	l1203
	call	l2134
	jmp	short l1206
	nop

l1203:	call	getbyte
l1206:	pop	dx
	pop	di
	pop	si
	add	dx,cx
	cmp	ax,si
	jnz	l11f3
	cmp	bx,di
	jnz	l11f3
	mov	ax,es:[1ch]
	xchg	ah,al
	pop	word ptr pagea
	pop	di
	pop	si
l121f:	cmp	ax,dx
	jz	l1226
	jmp	false

l1226:	jmp	true

verify2:push	si
	push	di
	push	cx
	push	ds
	mov	bx,word ptr dat_handle	; Get the datafile handle
	mov	si,word ptr lowseg
	mov	ds,si			; Set destination in low segment
	mov	cx,0
	mov	dx,40h			; Start off at byte 40
	mov	al,0			; From the front
	mov	ah,42h			; Move file pointer
	int	21h
	mov	cx,4000h-40h		; Length
	mov	dx,0c000h		; Destination
	mov	ah,3fh			; Read file
	int	21h
	cmp	ax,cx			; Did we get the full 3fc0 bytes?
	jne	datfail
	xor	dx,dx			; Clear crc
	call	crc			; Do a crc on the ax bytes at c000h
verifylp:		;l1256:
	mov	di,dx
	mov	dx,0c000h
	mov	cx,4000h		; Read in another 4000
	mov	ah,3fh			; Read file
	int	21h
	cmp	ax,cx			; Did we get all the 16k in?
	jne	notall
	mov	dx,di			; Get back the crc
	call	crc
	jmp	short verifylp

notall:			;l126d:
	mov	ax,es:[1ah]		; Get the amount to verify
	xchg	ah,al
	mov	dx,0
	mov	cx,1000h
	div	cx			; Work out the number of 16k blocks
	shl	dx,1			; dx is the remainder
	shl	dx,1
	sub	dx,2
	mov	ax,dx
	mov	dx,di
	call	crc			; CRC those last bytes
	push	dx
	mov	cx,0			; Move file pointer to c000
	mov	dx,0c000h
	mov	ah,42h			; Move file pointer
	mov	al,0			; From front
	int	21h
	mov	dx,0c000h
	mov	cx,4000h		; Read 16k
	mov	ah,3fh
	int	21h
	pop	dx
	pop	ds
	pop	cx
	pop	di
	pop	si
	mov	ax,es:[1ch]
	xchg	ah,al
	jmp	l121f

crc:			;l12ae:
	mov	cx,ax
	xor	ax,ax
	mov	si,0c000h
l12b5:	lodsb
	add	dx,ax
	loop	l12b5
	ret

datfail:		;l12bb
	call	scroll
	mov	ax,offset fatal		; "Fatal error: "
	call	pmsg
	mov	ax,offset datrdfailed_msg		; "Cannot read game file"
	call	pmsg
	jmp	endgame

;-------------------- S A V E / R E S T O R E --------------------

restore:mov	readwrite,0		; (V) Restores game
	jmp	short saverest
	nop

save:	mov	readwrite,1		; (V) Saves game
saverest:
	cmp	byte ptr alldatin,1
	jz	l12ed
	mov	ah,3eh
	mov	bx,word ptr dat_handle
	int	21h
	mov	ah,0dh
	int	21h
l12ed:	push	ax
	mov	ax,offset enterfname_msg	; "Insert save disk ... "
	call	pmsg
	pop	ax
	push	ax
	mov	ax,offset defaultis_msg	; "Default is "
	call	pmsg
	pop	ax
	test	byte ptr defdrvflg,1	; Check that we don't need to
					;  print drivename
	jnz	savdef

	mov	al,sav_drive		; We need to print up drivename
	add	al,'A'
	call	mspchar
	mov	al,':'
	call	mspchar

savdef:	push	si			; Print the save-file-name
	mov	si,offset sav_name
	mov	cx,si
	cld
psavname:
	lodsb
	test	al,al
	jz	savprtd
	call	mspchar
	jmp	short psavname

savprtd:sub	si,cx			; We've printed save name,
	mov	cx,si			;  now close the brackets
	pop	si
	push	ax
	mov	ax,offset brackets_msg
	call	pmsg
	pop	ax
	cmp	scrnlrx,32h		; If screen is less than 50 chars
	jg	widescrn		;  take a new line
	call	scroll
widescrn:
	mov	bx,offset ibuff
	mov	al,63			; Input buffer length = 63 characters
	mov	[bx],al
	mov	dx,bx
	mov	ah,0ah			; Buffered input
	int	21h
	call	savsav2			; Copy sav pointers into sav2 pointers
	push	si
	push	di
	push	cx
	push	es
	push	ds
	pop	es
	lea	si,ibuff+1		; Get length of input typed
	lodsb
	test	al,al
	jz	typedcr
	mov	cl,al
	xor	ch,ch
	mov	di,offset sav_name
	rep	movsb
	mov	al,0
	stosb

typedcr:test	noprinter,1
	jz	l136e
	call	lpsavname
l136e:	mov	si,offset sav_name
	inc	si
	lodsb
	cmp	al,':'	;3ah		; Check to see if there is a drivename
	jnz	nodrive
	mov	defdrvflg,1
	mov	al,sav_name
	and	al,5fh			; Simple upper case conversion
	sub	al,'A'
	cmp	al,sav_drive		; Was it the same as the .sav default?
	jz	defaultset
	mov	dl,al
	mov	ah,0eh			; Set default disk drive
	int	21h
	mov	ah,19h			; Get default disk drive
	int	21h
	mov	sav_drive,al		; Store it
	jmp	short defaultset
	nop

	mov	l01d6,1			; Is this some sort of debugging ?

nodrive:mov	defdrvflg,0	;139e
defaultset:
	pop	es
	pop	cx
	pop	di
	pop	si
	call	scroll
	cmp	byte ptr readwrite,1
	jz	createsav
	mov	dx,offset sav_name
	mov	ah,3dh			; Open file
	mov	al,0			; Read access only
	int	21h
	jb	savnotfnd
	jmp	short savok
	nop
savnotfnd:
	mov	ax,offset savnotfnd_msg	;l13bf	; "Game file not found"
	jmp	saverror

createsav:
	mov	dx,offset sav_name
	mov	cx,0
	mov	ah,3ch			; Create or truncate file
	int	21h
	jb	savenoaccess
	jmp	short savok
	nop
savenoaccess:
	mov	ax,offset noaccess_msg	; "No access"
	jmp	saverror

savok:	xchg	di,sp
	push	word ptr pc_page
	push	word ptr pc
	push	word ptr lvarptr
	push	word ptr l0333
	sub	sp,0bf8h
	mov	word ptr stack,sp
	mov	sp,di
	mov	word ptr sav_handle,ax
	push	es
	mov	ax,ss
	mov	es,ax
	mov	dx,offset stack
	mov	cx,400h
	mov	bx,word ptr sav_handle
	mov	ah,3fh
	add	ah,byte ptr readwrite
	int	21h
	cmp	ax,400h
	pushf
	mov	di,sp
	mov	sp,word ptr stack
	add	sp,0bf8h
	pop	ax
	cmp	ax,word ptr l0333
	jz	l143c
	mov	byte ptr error,0
	call	scroll
	mov	ax,offset fatal
	call	pmsg
	mov	ax,offset wrngvers_msg
	call	pmsg
	jmp	endgame

l143c:	pop	word ptr lvarptr
	pop	word ptr pc
	pop	word ptr pc_page
	xchg	di,sp
	popf
	pop	es
	jnz	l146a
	mov	cx,es:[0eh]
	xchg	ch,cl
	mov	ah,3fh
	add	ah,byte ptr readwrite
	mov	bx,word ptr sav_handle
	mov	dx,0
	push	ds
	push	es
	pop	ds
	int	21h
	pop	ds
	cmp	ax,cx
l146a:	pushf
	mov	ah,3eh
	mov	bx,word ptr sav_handle
	int	21h
	popf
	jnz	l14a2
	mov	ah,byte ptr noprinter
	or	ah,4
	xor	al,al
	mov	es:[10h],ax
	cmp	byte ptr alldatin,1
	jz	allin2
	call	clopdat
	mov	dl,byte ptr sav_drive
	mov	ah,0eh
	int	21h
allin2:	call	checkpc
	mov	ax,2
	sub	al,byte ptr readwrite
	jmp	pvarbyte

l14a2:	mov	ax,offset savrdfailed_msg
	cmp	byte ptr readwrite,1
	jnz	l14be
	mov	ah,3eh
	mov	bx,word ptr sav_handle
	int	21h
	mov	dx,offset sav_name
	mov	ah,41h
	int	21h
	mov	ax,offset noroom_msg
l14be:	jmp	short saverror
	nop

saverror:
	call	pmsg
	call	sav2sav
	cmp	byte ptr alldatin,1
	jz	allin3
	call	clopdat
allin3:	mov	ah,byte ptr noprinter
	or	ah,4
	xor	al,al
	mov	es:[10h],ax
	mov	ax,0
	jmp	pvarbyte

lpsavname:
	push	ax
	push	si
	push	dx
	mov	si,offset sav_name
l14ea:	lodsb
	test	al,al
	jnz	lpsavchar
	pop	dx
	pop	si
	pop	ax
	ret

lpsavchar:
	mov	dl,al
	mov	ah,5
	int	21h
	jmp	short l14ea

savsav2:push	di
	push	si
	push	ax
	push	es
	mov	ax,ds
	mov	es,ax
	mov	al,byte ptr sav_drive
	mov	byte ptr sav_drive2,al
	mov	al,byte ptr defdrvflg
	mov	byte ptr def2drvflg,al
	mov	si,offset sav_name
	mov	di,offset sav_name2
copyback:
	lodsb
	stosb
	test	al,al
	jnz	copyback
	pop	es
	pop	ax
	pop	si
	pop	di
	ret

sav2sav:push	di
	push	si
	push	ax
	push	es
	mov	ax,ds
	mov	es,ax
	mov	al,byte ptr def2drvflg
	mov	byte ptr defdrvflg,al
	mov	al,byte ptr sav_drive2
	cmp	al,byte ptr sav_drive
	jz	nochngdrv
	mov	dl,al
	mov	ah,0eh
	int	21h
	mov	byte ptr sav_drive,dl
nochngdrv:
	mov	di,offset sav_name
	mov	si,offset sav_name2
copyback1:
	lodsb
	stosb
	test	al,al
	jnz	copyback1
	pop	es
	pop	ax
	pop	si
	pop	di
	ret

restart:mov	bp,word ptr obufptr
	mov	ds: byte ptr [bp],0
	push	ax
	mov	ax,offset outbuff
	call	pmsg
	pop	ax
	jmp	startgame

quit:	jmp	endgame

;-------------------- A D D --------------------

add:	add	ax,bx			; (V) Adds param1 and param2
	jmp	pvarbyte		; Put the answer in the variable
					;  defined by the next byte

;-------------------- S U B --------------------

sub:	sub	ax,bx			; (V) Subtracts param2 from param1
	jmp	pvarbyte		; Put the answer in the variable
					;  defined by the next byte

;-------------------- M U L T --------------------

mult:	imul	bx			; (V) Multiplies param1 by param2
	jmp	pvarbyte		; Put the answer in the variable
					;  defined by the next byte

;-------------------- D I V --------------------

div:	cwd				; (V) Divides param1 by param2
	idiv	bx			; Put the answer in the variable
	jmp	pvarbyte		;  defined by the next byte

;-------------------- M O D --------------------

mod:	cwd				; (V) Returns param1 mod param2
	idiv	bx			;  in variable defined by next byte
	mov	ax,dx			; Get the remainder
	jmp	pvarbyte

;-------------------- R A N D O M --------------------

random:	cmp	ax,0
	jnge	l15c9
	jnz	l1598
	push	ax
	call	l31b6
	pop	ax
	mov	byte ptr l0302,al
	jmp	pvarbyte

l1598:	cmp	byte ptr l0302,1
	jz	l15e9
	sub	ah,ah
	mov	word ptr random_divisor,ax
	mov	ax,word ptr hourmin
	mov	bx,word ptr sechund
	mov	word ptr sechund,ax
	clc
	rcr	ax,1
	rcr	bx,1
	xor	word ptr hourmin,bx
	mov	ax,word ptr hourmin
	and	ax,0efffh
	sub	dx,dx
	div	random_divisor		; And divide by the number you first
	mov	ax,dx			;  thought of ...
	inc	ax
	jmp	pvarbyte

l15c9:	cmp	byte ptr l0302,1
	jz	l15e9
	mov	byte ptr l0302,1
	sub	dx,dx
	sub	dx,ax
	mov	word ptr hourmin,dx
	mov	word ptr sechund,0
	mov	ax,0
	jmp	pvarbyte

l15e9:	inc	word ptr sechund
	mov	ax,word ptr sechund
	cmp	ax,word ptr hourmin
	jna	l15fc
	mov	ax,1
	mov	word ptr sechund,ax
l15fc:	jmp	pvarbyte

;-------------------- L T O E --------------------

ltoe:	cmp	ax,bx			; (V) param1 <= param2 ?
	jnge	jmptrue2
jmpfalse2:
	jmp	false
jmptrue2:
	jmp	true

;-------------------- G T O E --------------------

gtoe:	cmp	ax,bx			; (V) param1 >= param2 ?
	jg	jmptrue2
	jmp	short jmpfalse2

;-------------------- B I T --------------------

bit:	not	ax			; (V) Check if bits on in param1
	and	bx,ax			;  are on in param2
	jz	jmptrue2
	jmp	short jmpfalse2

;-------------------- O R --------------------

or:	or	ax,bx			; (V) ors param1 & param2
	jmp	pvarbyte

;-------------------- N O T --------------------

not:	not	ax			; (V) nots param1
	jmp	pvarbyte

;-------------------- A N D --------------------

and:	and	ax,bx			; (V) ands param1 & param2
	jmp	pvarbyte

;-------------------- M W C O M P --------------------

mwcomp:	nop		;1626
	mov	bx,param1
	cmp	bx,param2
	je	mwcomp_true
	cmp	ax,3
	jl	mwcomp_false
	cmp	bx,param3
	je	mwcomp_true
	cmp	ax,4
	jl	mwcomp_false
	cmp	bx,param4
	jnz	mwcomp_false
mwcomp_true:		;1647
	jmp	true

mwcomp_false:		;l164a
	jmp	false

;-------------------- C P Z E R O --------------------

cpzero:	cmp	ax,0			; (V) see if param1 is zero
	jnz	cpzero_false
	jmp	true

cpzero_false:		;l1655
	jmp	false

;-------------------- T R A N S F E R --------------------

transfer:
	push	ax			; (V) Transfer object param1 to param2
	push	bx
	call	delete			; Delete the object from the orlist
	pop	dx
	mov	ax,dx			; ax is new location (param2)
	call	compadd
	mov	bx,ax			; bx points to new location (param2)
	pop	cx
	mov	ax,cx
	call	compadd
	mov	bp,ax			; bp points to object (param1)
	xchg	dh,dl			; Turn it around
	mov	es:6[bp],dx		; Make location of object = param2
	mov	dx,es:0ah[bx]		; Get holds of location
	xchg	dh,dl			; Turn it around
	xchg	ch,cl			; Turn around ne
	mov	es:0ah[bx],cx		; Make holds of location = new object
	cmp	dx,0
	jz	transfer_done
	xchg	dh,dl
	mov	es:8[bp],dx		; If other objects in row,
					;  make with link point to them
transfer_done:	ret

;-------------------- D E L E T E --------------------

delete:	mov	dx,ax			; (V) Deletes the object param1
	call	compadd
	mov	bx,ax
	mov	cx,es:6[bx]		; Get location of object
	xchg	ch,cl			; Turn it around
	cmp	cx,0			; Is it already deleted ?
	jz	delete_done
	mov	ax,cx
	call	compadd
	mov	bp,ax			; bp points to location
	mov	cx,dx
	mov	dx,es:0ah[bp]		; Now get holds of location
	xchg	dh,dl
	cmp	dx,cx			; Are we the first in the row ?
	jnz	delete_loop
	mov	ax,es:8[bx]		; Make holds of loc = with of object
	mov	es:0ah[bp],ax
	jmp	short delete_setz
	nop

delete_loop:
	mov	ax,dx			; Go from left to right until
	call	compadd			;  we find preceeding object
	mov	bp,ax
	mov	dx,es:8[bp]
	xchg	dh,dl
	cmp	dx,cx			; Found it ?
	jnz	delete_loop

	mov	ax,es:8[bx]		; Make link of previous object
	mov	es:8[bp],ax		;  = link of object being deleted

delete_setz:
	mov	es:word ptr 6[bx],0	; Set the location and with to nothing
	mov	es:word ptr 8[bx],0
delete_done:
	ret

;-------------------- B I T C H K --------------------

bitchk:	call	compadd			; (V) Checks statusbit p2 of object p1
	cmp	bx,20h			; If bit is in first double-word, jump
	jl	bitchk_lt20
	sub	bx,20h			; Otherwise subtract 20h and move
	add	ax,4			;  to the next double-word
	jmp	short bitchk_lt10
	nop

bitchk_lt20:
	cmp	bx,10h			; If bit is in first word, jump
	jl	bitchk_lt10
	sub	bx,10h			; Otherwise subtract 10h and move
	inc	ax			;  to the next word
	inc	ax
bitchk_lt10:
	mov	cx,bx			; Put bit number in cx
	mov	bx,ax			; Get the byte from memory
	mov	ax,es:[bx]
	xchg	ah,al			; Turn it around
	mov	dx,8000h		; High bit set
	shr	dx,cl			; Shift it right param2 times
	test	dx,ax			; Now test it with the word from memory
	jz	jfalse
	jmp	true

jfalse:	jmp	false

;-------------------- B I T O N --------------------

biton:	call	compadd			; (V) Turns on statusbit p2 of obj p1
	cmp	bx,20h			; If bit is in the first double-word,
	jl	biton_lt20		;  jump
	sub	bx,20h			; Otherwise, subtract 20h and move
	add	ax,4			;  to the next double-word
	jmp	short biton_lt10
	nop

biton_lt20:
	cmp	bx,10h			; If bit is in the first word, jump
	jnge	biton_lt10
	sub	bx,10h			; Otherwise subtract 10h and move
	inc	ax			;  to the next word
	inc	ax
biton_lt10:
	mov	cx,bx			; Put bit number in cx
	mov	bx,ax			; Get the byte from memory
	mov	ax,es:[bx]
	xchg	ah,al			; Turn it around
	mov	dx,8000h		; High bit set
	shr	dx,cl			; Shift it right param2 times
	or	ax,dx			; Or it into the byte
	xchg	ah,al			; Turn it around again
	mov	es:[bx],ax		; Put it back
	ret

;-------------------- B I T O F F -------------------

bitoff:	call	compadd
	cmp	bx,20h
	jl	bitoff_lt20
	add	ax,4
	sub	bx,20h
	jmp	short bitoff_lt10
	nop

bitoff_lt20:
	cmp	bx,10h
	jl	bitoff_lt10
	sub	bx,10h
	inc	ax
	inc	ax
bitoff_lt10:
	mov	cx,bx
	mov	bx,ax
	mov	ax,es: word ptr [bx]
	xchg	ah,al
	mov	dx,7fffh
	ror	dx,cl
	and	ax,dx
	xchg	ah,al
	mov	es: word ptr [bx],ax
	ret

;-------------------- G E T L O C --------------------

getloc:	call	compadd			; (V) Returns location of object p1
	mov	bx,ax
	mov	ax,es:6[bx]		; Location is bytes 6,7 in orlist entry
	xchg	ah,al			; Turn around
	jmp	pvarbyte

;-------------------- G E T H O L D S --------------------

getholds:
	call	compadd			; (V) Returns holds of object param1
	mov	bx,ax
	mov	ax,es:0ah[bx]		; Holds is bytes 0a,0b
	xchg	ah,al			; Turn around
	push	ax
	call	pvarbyte		; Put it in var defined by next byte
	pop	ax
	cmp	ax,0			; Check for deleted object
	jz	jmpfalse1
jmptrue1:
	jmp	true
jmpfalse1:
	jmp	false

;-------------------- G E T W I T H --------------------

getwith:call	compadd			; (V) Returns with of object param1
	mov	bx,ax
	mov	ax,es:8[bx]		; With is bytes 8,9
	xchg	ah,al			; Turn it around
	push	ax
	call	pvarbyte		; Put it in var defined by next byte
	pop	ax
	cmp	ax,0
	jz	jmpfalse1		; Check for last sibling
	jmp	short jmptrue1

;-------------------- C H K L O C --------------------

chkloc:	call	compadd			; (V) Checks if location of p1 if p2
	xchg	ax,bx
	xchg	ah,al
	cmp	es:6[bx],ax		; Location is bytes 6,7 of orlist entry
	xchg	ah,al
	jz	jmptrue1
	jmp	short jmpfalse1

;-------------------- G E T P R O P --------------------

getprop:mov	dx,bx			; (V) Get property p2 of object p1
	call	compadd
	call	l187c
	jmp	short l17d4
	nop

getprop_loop:		;17d1
	call	l231d			; Skip to the next property
l17d4:	mov	al,es:[bx]		; Get first byte
					;  (it contains propnum and proplen-1)
	and	al,00111111b		; Property number is six bits long
	cmp	al,dl			; Is it the one we are looking for ?
	jg	getprop_loop
	jl	getprop_unfound
	mov	al,es:[bx]		; Get the first byte again
	inc	bx
	and	al,00111111b		; Look at property number
	cmp	al,0
	jnz	getprop_found
	mov	al,es: byte ptr [bx]	; Property zero is always zero
	jmp	p0varbyte

getprop_unfound:
	dec	dx	;l17ef
	shl	dx,1
	mov	bx,dx
	add	bx,word ptr orlist_pointer
getprop_found:		;l17f8
	mov	ax,es:[bx]		; Get the property
	xchg	ah,al			; Turn it around
	jmp	pvarbyte

;-------------------- P U T P R O P --------------------

putprop:push	cx			; (V) Put p3 as prop p2 of obj p1
	mov	dx,bx
	call	compadd
	call	l187c
	jmp	short putprop_first
	nop

putprop_loop:		;l180c
	call	l231d
putprop_first:		;l180f
	mov	al,es:[bx]		; Get the first byte
	and	al,00111111b		; Look at the property number
	cmp	al,dl			; Is it the one we are looking for ?
	je	putprop_found
	jg	putprop_loop
	call	scroll
	mov	ax,offset fatal		; "Fatal error"
	call	pmsg
	mov	ax,offset nosuchprop_msg	; "No such property"
	call	pmsg
	jmp	endgame			; Finito

putprop_found:
	mov	al,es:[bx]		; Get the first byte again
	inc	bx
	and	al,00111111b		; Property number mask
	cmp	al,0			; Property zero ?
	pop	ax
	jnz	putprop_notzero
	mov	es:[bx],al
	ret

putprop_notzero:	;l183b
	xchg	ah,al			; Turn it around
	mov	es:[bx],ax
	ret

;-------------------- G E T N P R O P --------------------

getnprop:
	mov	dx,bx
	call	compadd
	call	l187c
	cmp	dx,0
	jz	l1874
	jmp	short l1854
	nop

l1851:	call	l231d
l1854:	mov	al,es: byte ptr [bx]
	and	al,00111111b
	cmp	al,dl
	jz	l1871
	jg	l1851
	call	scroll
	mov	ax,offset fatal		; "Fatal error: "
	call	pmsg
	mov	ax,offset nosuchprop_msg	; "No such property"
	call	pmsg
	jmp	endgame

l1871:	call	l231d
l1874:	mov	al,es:[bx]
	and	al,00111111b
	jmp	pvarbyte

l187c:	mov	bp,ax
	mov	bx,es:0ch[bp]
	xchg	bh,bl
	mov	al,es: byte ptr [bx]
	xor	ah,ah
	shl	ax,1
	add	bx,ax
	inc	bx
	ret

l188f:	mov	dx,ax
	mov	ax,bx
l1893:	push	ax
	push	cx
	call	cnvtadd
	call	getword
	cmp	cx,dx
	jz	l18ad
	pop	cx
	pop	ax
	inc	ax
	inc	ax
	loop	l1893
	xor	ax,ax
	call	pvarbyte
	jmp	false

l18ad:	pop	cx
	pop	ax
	call	pvarbyte
	jmp	true

;-------------------- G E T 1 6 --------------------

get16:	shl	bx,1			; (V) Returns param2 entry
	add	ax,bx			;  of a 2-byte entry table
	call	cnvtadd			; Convert address to pages	
	call	getword			; Get the word
	mov	ax,cx			; Put the word in ax
	jmp	pvarbyte

;-------------------- G E T 8 --------------------

get8:	add	ax,bx			; (V) Returns param2 entry
	call	cnvtadd			;  of a 1-byte entry table
	call	getbyte			; Get the word
	mov	ax,cx			; Put the word in ax
	jmp	p0varbyte

;-------------------- P U T 1 6 --------------------

put16:	shl	bx,1			; (V) Put param3 in param2 entry
	add	bx,ax			;  of a 2-byte entry table	
	xchg	ch,cl			;  at base param1
	mov	es:[bx],cx
	ret

;-------------------- P U T 8 --------------------

put8:	add	bx,ax			; (V) Put param3 in param2 entry
	mov	es:[bx],cl		;  of a 1-byte entry table
	ret				;  at base param1

;-------------------- G E T P A D D R --------------------

getpaddr:
	mov	dx,bx			; (V) Gets address of property
	call	compadd			;  p2 of object p1
	call	l187c
	jmp	short l18ef
	nop

l18ec:	call	l231d
l18ef:	mov	al,es: byte ptr [bx]
	and	al,00111111b		; Get the property number
	cmp	al,dl
	jg	l18ec
	jz	l18ff
	sub	ax,ax
	jmp	short l190d
	nop

l18ff:	mov	al,es: byte ptr [bx]
	inc	bx
	test	al,80h
	jnz	l190a
	jmp	short l190b
	nop

l190a:	inc	bx
l190b:	mov	ax,bx
l190d:	jmp	pvarbyte

;-------------------- G E T P L E N --------------------

getplen:mov	bx,ax
	mov	al,es:-1[bx]
	test	al,80h
	jnz	l192a
	test	al,01000000b		; Bit 6
	jnz	l1924
	mov	ax,1
	jmp	pvarbyte

l1924:	mov	ax,2
	jmp	pvarbyte

l192a:	and	al,00111111b
	xor	ah,ah
	jmp	pvarbyte

;-------------------- L D V A R V A R --------------------

ldvarvar:				; (V) Get var in param1 and put into
	call	getvar			;  var defined by next byte
	jmp	pvarbyte

;-------------------- L D V A R --------------------

ldvar:	jmp	putvar			; (V) Loads param2 into var defined
					;  by param1

;-------------------- P U S H --------------------

push:	xchg	sp,di			; (V) Pushes param1 onto stack
	push	ax
	xchg	sp,di
	ret

;-------------------- P O P --------------------

pop:	xchg	sp,di			; (V) Pops off stack
	pop	bx
	xchg	sp,di
	jmp	putvar			; Into var defined by param1

;-------------------- I N C --------------------

inc:	mov	cx,ax			; (V) Increment variable param1
	call	getvar
	inc	ax
incdec:	mov	bx,ax
	mov	ax,cx
	jmp	putvar

;-------------------- D E C --------------------

dec:	mov	cx,ax			; (V) Decrement variable param1
	call	getvar
	dec	ax
	jmp	short incdec

;-------------------- I N C C H K --------------------

incchk:	push	ax			; (V) Incs param1 & checks if >= param2
	call	getvar
	inc	ax
	sub	cx,cx			; Set cx = 0 (assume false)
	cmp	ax,bx
	jng	incfalse
inctrue:inc	cx			; If it is greater, return true
incfalse:
	mov	bx,ax
	pop	ax
	call	putvar			; Put the incremented variable back
	cmp	cx,0
	jz	jfalse2
	jmp	true

jfalse2:jmp	false

;-------------------- D E C C H K --------------------

decchk:	push	ax			; (V) Decs param1 & checks if <= param2
	call	getvar
	dec	ax
	sub	cx,cx
	cmp	ax,bx
	jge	incfalse
	jmp	short inctrue

;-------------------- L I N E I N --------------------

linein:	mov	ax,cx
	push	bx
	mov	script,1
	push	si
	mov	cl,es:[si]
	mov	bx,offset ibuff		; Set bx to the input buffer
	mov	[bx],cl			; Look at the length
	cmp	cl,78			; If someone patches the buffer
					;  longer, make it 78 chars
	jna	linein_ibuffok
	mov	byte ptr [bx],78

linein_ibuffok:
	mov	dx,bx			; Input buffer now in dx
	cmp	ax,2h
	jna	l19b8
	mov	bx,offset param1
	mov	ax,4[bx]		; ax gets param3
	mov	bx,6[bx]		; bx gets param4
	push	si
	call	l1dcb
	pop	si
	jmp	short l19bb
	nop

l19b8:	call	l1f01
l19bb:	test	byte ptr l053b,1
	jnz	linefd
	mov	ah,6
	mov	al,1
	mov	cx,word ptr scrnlry
	mov	dh,byte ptr l01e5
	mov	dl,byte ptr scrnlrx
	dec	dl
	mov	bh,byte ptr text_attrib
	int	10h
	jmp	short scrldone
	nop

linefd:	mov	ah,6
	mov	dl,0ah
	int	21h
scrldone:
	pop	dx
	mov	bx,offset ibuff
	mov	cl,byte ptr 1[bx]
	sub	ch,ch
	inc	bx
	cmp	cl,0
	jz	linein_noinput
lcloop:					; Copy input buffer to game's input
					;  buffer, lower-case-er-is-ing as we
					; go
	inc	si			; Go to next byte of game's buffer
	inc	bx			; Go to next byte of input buffer
	mov	al,[bx]
	cmp	al,'A'
	jl	linein_notupper
	cmp	al,'Z'
	jg	linein_notupper
	add	al,' '			; Lower-case-er-ise it
linein_notupper:
	mov	es:[si],al		; And move it to game's buffer at si
	loop	lcloop
linein_noinput:
	inc	si			; Put a zero at the end of the string
	sub	al,al
	mov	es:[si],al
	mov	script,0
	pop	bx
	ret

lpchar:	push	ax
	push	bx
	push	cx
	push	dx
	test	es:[10h],0100h
	jz	lpok
	test	byte ptr switches,10h
	jz	mslpchar
retry:	mov	ah,0
	mov	dx,0
	int	17h
	test	ah,1
	jz	lpok
	call	abrtrtry
	jb	lpok
	jmp	short retry

mslpchar:
	mov	dl,al
	mov	ah,5
	int	21h
lpok:	pop	dx
	pop	cx
	pop	bx
	pop	ax
	ret

abrtrtry:
	push	ax
	mov	byte ptr script,1
	push	ax
	mov	ax,offset noprint
	call	pmsg
	pop	ax
abtrtylp:
	call	keyin
	call	mspchar
	and	al,5fh
	cmp	al,'A'	;41h
	jnz	nota
	mov	noprinter,0
	mov	script,0
	stc
	pushf
	jmp	short abrtrtryx
	nop

nota:	cmp	al,'R'	;52h
	jnz	abtrtylp
	clc
	pushf
abrtrtryx:
	call	scroll
	mov	byte ptr script,0
	popf
	pop	ax
	ret

l1a7e:	push	ax
	push	bx
	push	dx
	test	byte ptr noprinter,1
	jnz	l1a8b
	jmp	short l1ab7
	nop

l1a8b:	sub	cx,cx
	mov	bp,dx
	inc	bp
l1a90:	mov	al,es:[bp]
	inc	bp
	cmp	bp,si
	jng	l1a9f
	call	l1abb
	jmp	short l1ab7
	nop

l1a9f:	call	lpchar
	inc	cx
	cmp	cl,byte ptr scrnlrx
	jnz	l1a90
	call	l1abb
	jb	l1ab7
	sub	cx,cx
	jmp	short l1a90

	mov	byte ptr noprinter,0
l1ab7:	pop	dx
	pop	bx
	pop	ax
	ret

l1abb:	test	es:[10h],0100h
	jnz	lpcrlf
	ret

lpcrlf:	mov	al,0dh
	call	lpchar
	mov	al,0ah
	call	lpchar
	or	es:[10h],0400h
	ret

;-------------------- I N P U T --------------------

input:	nop
	mov	cx,ax
	mov	bx,offset param1
	mov	ax,word ptr [bx]
	mov	bx,word ptr 2[bx]
	push	ax
	mov	bp,word ptr obufptr
	mov	ds:byte ptr [bp],80h
	push	ax
	mov	ax,offset outbuff
	call	pmsg
	pop	ax
	mov	word ptr obufptr,034bh
	pop	si
	mov	word ptr l0553,0
	mov	word ptr l031e,4fh
	call	linein
	call	l1a7e
	push	di
	mov	word ptr l030f,dx
	mov	word ptr l0311,si
	mov	word ptr l0313,bx
	mov	byte ptr l0315,0
	inc	dx
	mov	di,bx
	inc	di
	inc	di
l1b24:	mov	cx,offset l0305
	mov	bx,dx
l1b29:	cmp	dx,word ptr l0311
	jnz	l1b38
	cmp	cx,0305h
	jnz	l1b80
	jmp	l1c81

l1b38:	mov	bp,dx
	mov	al,es:[bp]
	cmp	al,'A'
	jl	l1b48
	cmp	al,'Z'
	jg	l1b48
	add	al,' '
l1b48:	inc	dx
	mov	si,offset l03ec
l1b4c:	inc	si
	cmp	al,byte ptr -1[si]
	jz	l1b66
	cmp	byte ptr [si],0
	jnz	l1b4c
	cmp	cx,030eh
	jz	l1b29
	mov	bp,cx
	mov	ds:[bp],al
	inc	cx
	jmp	short l1b29

l1b66:	cmp	cx,0305h
	jnz	l1b7f
	cmp	si,word ptr l0343
	jna	l1b75
	inc	bx
	jmp	short l1b29

l1b75:	mov	bp,cx
	mov	ds:[bp],al
	inc	cx
	jmp	short l1b80

	nop

l1b7f:	dec	dx
l1b80:	inc	byte ptr l0315
	mov	bp,bx
	mov	bx,word ptr l0313
	mov	bl,es:[bx]
	cmp	bl,3bh
	jna	l1b94
	mov	bl,';'
l1b94:	cmp	byte ptr l0315,bl
	mov	bx,bp
	jng	l1bd1
	push	ax
	mov	ax,offset toomanywrds_msg
	call	pmsg
	pop	ax
	mov	ax,bx
	mov	bp,l0311
	mov	bl,es:[bp]
	mov	es:byte ptr [bp],0
	push	bx
	mov	bx,ds
	neg	bx
	add	bx,lowseg
	mov	cl,4
	shl	bx,cl
	add	ax,bx
	pop	bx
	call	pmsg
	mov	es:[bp],bl
	dec	byte ptr l0315
	jmp	l1c81

l1bd1:	mov	ax,bx
	neg	ax
	add	ax,dx
	mov	es:2[di],al
	sub	bx,word ptr l030f
	mov	es:3[di],bl
	mov	bp,cx
	mov	ds:byte ptr [bp],0
	mov	ax,offset l0305
	call	l247b
	mov	l0303,cx
	push	dx
	push	di
	mov	di,ax
	mov	si,l0347
	mov	ax,si
	dec	ax
	mul	word ptr l0345
	add	ax,l0349
	mov	cx,ax
	mov	dx,di
	mov	di,bx
	mov	bx,l0345
	sar	si,1
l1c13:	shl	bx,1
	sar	si,1
	cmp	si,0
	jnz	l1c13
	mov	si,l0349
	add	si,bx
	push	ax
	mov	ax,word ptr l0345
	sub	si,ax
	pop	ax
l1c29:	sar	bx,1
	mov	ax,es: word ptr [si]
	xchg	ah,al
	cmp	dx,ax
	ja	l1c5d
	jb	l1c68
	mov	bp,si
	add	bp,2
	mov	ax,es:[bp]
	xchg	ah,al
	cmp	di,ax
	ja	l1c5d
	jb	l1c68
	mov	bp,si
	add	bp,4
	mov	ax,es:[bp]
	xchg	ah,al
	cmp	word ptr l0303,ax
	ja	l1c5d
	jb	l1c68
	jmp	short l1c72

	nop
l1c5d:	add	si,bx
	cmp	si,cx
	jna	l1c6a
	mov	si,cx
	jmp	short l1c6a

	nop
l1c68:	sub	si,bx
l1c6a:	cmp	bx,l0345
	jge	l1c29
	sub	si,si
l1c72:	pop	di
	mov	dx,si
	xchg	dh,dl
	mov	es:[di],dx
	pop	dx
	add	di,4
	jmp	l1b24

l1c81:	inc	word ptr l0313
	mov	bp,l0313
	mov	dl,l0315
	mov	es:[bp],dl
	pop	di
	ret

l1c93:	cmp	ax,0
	jnz	l1cb6
	mov	byte ptr l0320,0
	push	bx
	mov	bx,word ptr obufptr
	mov	byte ptr [bx],80h
	push	ax
	mov	ax,offset outbuff
	call	pmsg
	pop	ax
	mov	bx,offset outbuff
	mov	word ptr obufptr,bx
	pop	bx
	ret

l1cb6:	mov	byte ptr l0320,1
	ret

null3:	ret

l1cbd:	or	al,al
	jns	l1cc4
	jmp	short l1d42
	nop

l1cc4:	cmp	al,1
	jnz	l1cce
	mov	byte ptr l032a,1
	ret

l1cce:	cmp	al,2
	jnz	l1d15
	push	ax
	push	bx
	push	dx
	test	byte ptr noprinter,1
	jnz	l1d11
	or	es:[10h],0100h
	mov	byte ptr noprinter,1
	test	byte ptr switches,10h
	jz	l1d11
l1cef:	mov	dx,0
	mov	ah,1
	int	17h
	test	ah,0a1h
	jz	l1d11
	call	abrtrtry
	jnb	l1cef
	xor	ah,ah
	mov	noprinter,ah
	or	ah,4
	xor	al,al
	xchg	ah,al
	mov	es:[10h],ax
l1d11:	pop	dx
	pop	bx
	pop	ax
	ret

l1d15:	cmp	al,3
	jnz	l1d3d
	mov	al,byte ptr l0320
	mov	byte ptr l0321,al
	mov	ax,0
	call	l1c93
	mov	word ptr l0322,1
	mov	word ptr l0324,bx
	mov	word ptr l0328,0
	add	bx,2
	mov	word ptr l0326,bx
	ret

l1d3d:	cmp	al,4
	jnz	l1d41
l1d41:	ret

l1d42:	cmp	al,0ffh
	jnz	l1d4c
	mov	byte ptr l032a,0
	ret

l1d4c:	cmp	al,0feh
	jnz	l1d5d
	mov	byte ptr noprinter,0
	and	es:[10h],0feffh
	ret

l1d5d:	cmp	al,0fdh
	jnz	l1d82
	mov	al,byte ptr l0321
	mov	byte ptr l0320,al
	mov	word ptr l0322,0
	mov	ax,word ptr l0328
	mov	bx,word ptr l0324
	xchg	ah,al
	mov	es: word ptr [bx],ax
	mov	bx,word ptr l0326
	mov	es: byte ptr [bx],0
	ret

l1d82:	cmp	al,0fch
	jnz	l1d86
l1d86:	ret

l1d87:	nop
	push	bx
	push	cx
	mov	word ptr l0553,0
	mov	word ptr l031e,4fh
	mov	bx,word ptr param1
	cmp	bx,1
	jnz	l1dbb
	cmp	ax,3
	jb	l1dc3
	mov	ax,word ptr param2
	idiv	ten
	mov	word ptr l0318,ax
	mov	bx,word ptr param3
	call	l1ebc
	jnb	l1dc3
	test	al,al
	jz	l1dc3
l1dbb:	pop	cx
	pop	bx
	mov	ax,0
	jmp	p0varbyte

l1dc3:	call	l1e72
	pop	cx
	pop	bx
	jmp	p0varbyte

l1dcb:	push	bx
	mov	bx,offset ibuff
	mov	byte ptr [bx],4eh
	mov	byte ptr 1[bx],0
	idiv	ten
	mov	word ptr l0318,ax
	pop	bx
	call	l1ebc
	jnb	l1df2
	test	al,al
	jz	l1df2
	mov	bx,offset l039e
	add	bx,cx
	mov	byte ptr [bx],al
	call	mspchar
	ret

l1df2:	jmp	short l1df5

	nop
l1df5:	call	l1e72
	cmp	al,0eh			; Control N
	jz	l1e61
	cmp	al,7			; Bell
	jz	l1e61
	cmp	al,0dh			; Carraige return
	jz	l1e66
	cmp	al,7fh			; Delete
	jz	l1e48
	cmp	al,8			; Backspace
	jz	l1e48
	cmp	al,0bh			; Control K
	jz	l1e48
	sub	ch,ch
	mov	cl,byte ptr ibuff+1
	mov	bl,byte ptr ibuff
	dec	bl
	cmp	cl,bl
	jz	l1e43
	inc	byte ptr ibuff+1
	mov	bx,offset l039e
	add	bx,cx
	mov	byte ptr [bx],al
l1e2b:	call	mspchar
	jmp	short l1df5

l1e30:	call	l1e72
	cmp	al,0dh
	jz	l1e66
	cmp	al,7fh
	jz	l1e48
	cmp	al,8
	jz	l1e48
	cmp	al,0bh
	jz	l1e48
l1e43:	call	l3072
	jmp	short l1e30

l1e48:	cmp	byte ptr ibuff+1,0
	jz	l1e61
	dec	byte ptr ibuff+1
	mov	al,8
	call	mspchar
	mov	al,' '	;20h
	call	mspchar
	mov	al,8
	jmp	short l1e2b

l1e61:	call	l3072
	jmp	short l1df5

l1e66:	mov	bx,offset l039e
	add	bx,cx
	inc	bx
	mov	byte ptr [bx],al
	call	mspchar
	ret

l1e72:	mov	ah,7
	int	21h
	and	al,7fh			; Take off high bit
	cmp	al,0
	jnz	l1ead
	mov	ah,7
	int	21h
	cmp	al,'H'			; Up arrow
	jnz	l1e89
	mov	al,0eh
	jmp	short l1ebb

	nop
l1e89:	cmp	al,'K'			; Left arrow
	jnz	l1e92
	mov	al,0bh
	jmp	short l1ebb

	nop
l1e92:	cmp	al,'M'			; Right arrow
	jnz	l1e9b
	mov	al,7
	jmp	short l1ebb

	nop
l1e9b:	cmp	al,'P'			; Down arrow
	jnz	l1ea4
	mov	al,0dh
	jmp	short l1ebb

	nop
l1ea4:	cmp	al,'S'			; Del
	jnz	l1e72
	mov	al,7fh
	jmp	short l1ebb

	nop
l1ead:	cmp	al,8
	jz	l1ebb
	cmp	al,0dh
	jz	l1ebb
	cmp	al,' '
	jnb	l1ebb
	jmp	short l1e72

l1ebb:	ret

l1ebc:	push	di
l1ebd:	mov	di,word ptr l0318
l1ec1:	mov	ah,2ch
	int	21h
	mov	word ptr l0458,dx
l1ec9:	mov	ah,0bh
	int	21h
	or	al,al
	jz	l1ed4
	pop	di
	clc
	ret

l1ed4:	mov	ah,2ch
	int	21h
	mov	ax,dx
	sub	dx,word ptr l0458
	cmp	dx,0100h
	jb	l1ec9
	neg	dx
	cmp	dx,0100h
	jb	l1ec9
	mov	word ptr l0458,ax
	dec	di
	jnz	l1ec1
	mov	ax,bx
	call	l2067
	cmp	ax,0
	jnz	l1efe
	jmp	short l1ebd

l1efe:	pop	di
	stc
	ret

l1f01:	push	ax
	push	bx
	push	cx
	push	dx
	push	dx
	pop	bx
	mov	byte ptr 1[bx],0
	call	l1df5
	pop	dx
	pop	cx
	pop	bx
	pop	ax
	ret

;-------------------- P R I N T C H A R --------------------

printchar:
	jmp	pchar			; (V) Print the character in param1

;-------------------- P R I N T N U M --------------------

printnum:				; (V) Print param1 in decimal
	mov	bx,ax
	cmp	bx,0
	jnz	pn_not0
	mov	ax,'0'
	jmp	pchar

pn_not0:jg	pn_plus		;1f23?
	mov	ax,'-'			; If negative, print a minus sign
	call	pchar
	neg	bx			; And negate the number
pn_plus:sub	cx,cx		;1f2d
	jmp	short pn_ndentry

	nop
pn_nextdig:			;l1f32
	mov	ax,bx			; Keep dividing by 10 until remainder
	mov	bp,10			;  is less than 10
	cwd
	idiv	bp
	push	dx
	inc	cx
	mov	bx,ax
pn_ndentry:			;l1f3e
	cmp	bx,10
	jge	pn_nextdig
	mov	ax,bx
	jmp	short pn_print

	nop
pn_loop:pop	ax		;1f48	; Keep popping off the answers
pn_print:
	add	ax,'0'		;1f49	;  from the stack
	call	pchar
	dec	cx
	jge	pn_loop
	ret

;-------------------- P R I N T 2 --------------------

print2:	call	l22fb			; (V) Prints message at param1*2
	jmp	pcode

;-------------------- P R I N T --------------------

print:	call	cnvtadd			; (V) Prints message at param1
	jmp	pcode

;-------------------- P O B J --------------------

pobj:	call	compadd			; (V) Prints the name of the object in
	mov	bp,ax			;  param1
	mov	ax,es: word ptr 0ch[bp]	; Get property address
	xchg	ah,al			; Turn it around
	inc	ax			; Skip over the proplen/propnum byte
	call	cnvtadd			; Convert into pages
	jmp	pcode			; Print the text

;-------------------- I L P R I N T --------------------

ilprint:mov	byte ptr l044f,0	; (V) Inline print
	mov	ax,word ptr pc_page	; Prints the message following the
	mov	bx,word ptr pc		;  instruction
	call	pcode
	mov	word ptr pc_page,ax
	mov	word ptr pc,bx
	jmp	checkpc

;-------------------- I L P R I N T R E T --------------------

ilprtcr:call	ilprint			; (V) Inline print and returns from
	call	newline			;  subroutine
	jmp	rettrue

;-------------------- N E W L I N E --------------------

newline:	jmp	crlf		; (V) Take a new line

;--------------------  --------------------

l1f96:	mov	word ptr param1,ax
	mov	ax,1
	jmp	short call
	nop

;-------------------- C A L L --------------------

call:	nop
	mov	dx,ax
	mov	ax,word ptr param1
	cmp	ax,0
	jnz	l1faf
	sub	ax,ax
	jmp	pvarbyte

l1faf:	xchg	sp,di
	push	word ptr pc_page
	xchg	sp,di
	xchg	sp,di
	push	word ptr pc
	xchg	sp,di
	mov	cx,word ptr lvarptr
	xchg	sp,di
	push	cx
	xchg	sp,di
	call	l22fb
	mov	word ptr pc_page,ax
	mov	word ptr pc,bx
	call	checkpc
	mov	word ptr lvarptr,di
	sub	word ptr lvarptr,2
	call	getpcbyte
	mov	bx,ax
	mov	bp,offset param2
l1fe6:	dec	bx
	jnge	l2002
	call	l21f5
	dec	dx
	jng	l1ffb
	xchg	sp,di
	push	word ptr [bp]
	xchg	sp,di
	add	bp,2
	jmp	short l1fe6

l1ffb:	xchg	sp,di
	push	ax
	xchg	sp,di
l2000:	jmp	short l1fe6

l2002:	ret

;-------------------- R E T U R N --------------------

return:	mov	di,word ptr lvarptr	; (V) Return from subroutine
	xchg	sp,di
	pop	dx
	xchg	sp,di
	xchg	sp,di
	pop	word ptr lvarptr	; Get back the local variable pointer
	xchg	sp,di
	xchg	sp,di
	pop	word ptr pc		; Get back the pc
	xchg	sp,di
	xchg	sp,di
	pop	word ptr pc_page	; Get back the pc page
	xchg	sp,di
	cmp	word ptr pc_page,1
	jnz	l202e
	jmp	short l2086

	nop
l202e:	push	ax
	call	checkpc
	pop	ax
	jmp	pvarbyte

;-------------------- R E T T R U E --------------------

rettrue:mov	ax,1			; (V) Returns a true to calling routine
	jmp	short return

;-------------------- R E T F A L S E --------------------

retfalse:
	sub	ax,ax			; (V) Returns false to calling routine
	jmp	short return

;-------------------- J U M P --------------------

jump:	add	pc,ax			; (V) Relative jump by param1
	sub	pc,2
	cmp	pc,0200h
	jnb	jump_overpage
	mov	byte ptr l044f,0
	ret

jump_overpage:		;l2056
	jmp	checkpc

;-------------------- R E T T O S --------------------

rettos:	xchg	sp,di			; (V) Returns top of stack to the
	pop	ax			;  calling routine
	xchg	sp,di
	jmp	short return

;-------------------- P O P N I L --------------------

popnil:	xchg	sp,di			; (V) Pops a value off stack & discards
	pop	dx			;  it
	xchg	sp,di
	ret

;-------------------- N U L L --------------------

null:	ret				; (V) Null instruction


l2067:	push	bx
	push	cx
	push	dx
	push	si
	push	word ptr pc_page
	mov	word ptr pc_page,1
	mov	word ptr param1,ax
	mov	ax,1
	call	call
	mov	byte ptr l044f,0
	jmp	reentry

l2086:	add	sp,2
	pop	word ptr pc_page
	push	ax
	call	checkpc
	pop	ax
	pop	si
	pop	dx
	pop	cx
	pop	bx
	ret

;-------------------- G E T B Y T E --------------------

getbyte:push	si			; Get the byte at page ax, offset bx 
	push	ax			;  into cx
	cmp	byte ptr alldatin,1
	jz	l20a6
	cmp	ax,word ptr pagea
	jge	l20d7
l20a6:	cmp	ax,80h
	jb	l20c9
	sub	ax,80h
	mov	si,word ptr l0448
	mov	byte ptr linecount,1
l20b7:	cmp	ax,80h
	jb	l20d3
	sub	ax,80h
	add	si,1000h
	inc	byte ptr linecount
	jmp	short l20b7

l20c9:	mov	cl,9
	shl	ax,cl
	or	ax,bx
	xchg	ax,bx
	jmp	short l2100

	nop
l20d3:	mov	es,si
	jmp	short l20c9

l20d7:	call	l2b5b
	add	ax,bx
	xchg	ax,bx
	cmp	byte ptr linecount,0
	jz	l2100
	push	ax
	push	bx
	push	dx
	mov	dx,0
	mov	ax,1000h
	mov	bl,byte ptr linecount
	mov	bh,0
	mul	bx
	add	ax,word ptr lowseg
	mov	si,ax
	pop	dx
	pop	bx
	pop	ax
	mov	es,si
l2100:	cmp	bx,0ffffh
	NOP
	jnz	l210c
	mov	cl,es: byte ptr [bx]
	jmp	short l2118

	nop
l210c:	mov	cx,es: word ptr [bx]
	mov	byte ptr l044c,ch
	mov	byte ptr l044d,1
l2118:	sub	ch,ch
	mov	bx,ax
	mov	si,word ptr lowseg
	mov	es,si
	pop	ax
	pop	si
	inc	bx
	cmp	bx,0200h
	jnz	l2133
	sub	bx,bx
	inc	ax
	mov	byte ptr l044d,0
l2133:	ret

l2134:	mov	cl,byte ptr l044c
	mov	ch,0
	mov	byte ptr l044d,0
	inc	bx
	cmp	bx,0200h
	jnz	l214a
	mov	bx,0
	inc	ax
l214a:	ret

;-------------------- G E T W O R D --------------------

getword:push	dx
	call	getbyte
	push	cx
	cmp	byte ptr l044d,1
	jnz	l215d
	call	l2134
	jmp	short l2160

	nop
l215d:	call	getbyte
l2160:	pop	dx
	mov	ch,dl
	pop	dx
	ret

getpcbyte:
	cmp	byte ptr l044f,1
	jnz	l216f
	jmp	short l21d9

	nop
l216f:	push	si
	push	bx
	test	byte ptr l0423,1
	jz	l217b
	call	checkpc
l217b:	mov	bx,word ptr pc
	add	bx,word ptr l0436
	cmp	byte ptr highaddrflg,0
	jz	l21a0
	push	bx
	push	dx
	xor	bh,bh
	mov	bl,byte ptr highaddrflg
	dec	bx
	mov	ax,1000h
	mul	bx
	add	ax,word ptr l0448
	pop	dx
	pop	bx
	mov	es,ax
l21a0:	cmp	bx,0ffffh
	NOP
	jnz	l21ac
	mov	al,es: byte ptr [bx]
	jmp	short l21b8

	nop
l21ac:	mov	ax,es: word ptr [bx]
	mov	byte ptr l044e,ah
	mov	byte ptr l044f,1
l21b8:	push	ax
	mov	si,word ptr lowseg
	mov	es,si
	inc	word ptr pc
	cmp	word ptr pc,0200h
	jnge	l21d3
	mov	byte ptr l044f,0
	call	checkpc
l21d3:	pop	ax
	sub	ah,ah
	pop	bx
	pop	si
	ret

l21d9:	mov	ah,0
	mov	al,byte ptr l044e
	push	ax
	mov	byte ptr l044f,0
	inc	word ptr pc
	cmp	word ptr pc,0200h
	jnz	l21f3
	call	checkpc
l21f3:	pop	ax
	ret

l21f5:	push	bx
	call	getpcbyte
	push	ax
	call	getpcbyte
	pop	bx
	mov	ah,bl
	pop	bx
	ret

;-------------------- G E T P A R A M --------------------

getparam:
	dec	ax
	jl	l21f5
	jz	l2215
	call	getpcbyte
	cmp	ax,0
	jnz	getvar
	xchg	sp,di
	pop	ax
	xchg	sp,di
	ret

l2215:	jmp	getpcbyte

;-------------------- G E T V A R --------------------

getvar:	cmp	ax,0
	jnz	l2221
	mov	ax,ss: word ptr [di]
	ret

l2221:	push	bp
	cmp	ax,10h
	jge	l2235
	dec	ax
	shl	ax,1
	mov	bp,word ptr lvarptr
	sub	bp,ax
	mov	ax,word ptr [bp]
l2233:	pop	bp
	ret

l2235:	sub	ax,10h
	shl	ax,1
	add	ax,word ptr glovar_pointer
	mov	bp,ax
	mov	ax,es: word ptr [bp]
	xchg	ah,al
	jmp	short l2233

;-------------------- P U T V A R --------------------

putvar:	cmp	ax,0
	jnz	l2251
	mov	ss: word ptr [di],bx
	ret

l2251:	cmp	ax,10h
	jge	l2265
	push	bp
	dec	ax
	shl	ax,1
	mov	bp,word ptr lvarptr
	sub	bp,ax
	mov	[bp],bx
	pop	bp
	ret

l2265:	sub	ax,10h
	shl	ax,1
	add	ax,word ptr glovar_pointer
	xchg	ax,bx
	xchg	ah,al
	mov	es: word ptr [bx],ax
	ret

p0varbyte:
	sub	ah,ah
	jmp	short pvarbyte

	nop
pvarbyte:
	mov	bx,ax
	call	getpcbyte
	cmp	ax,0
	jnz	putvar
	xchg	sp,di
	push	bx
	xchg	sp,di
	ret

false:	sub	bx,bx
	jmp	short l2295
	nop

;-------------------- T R U E --------------------

true:	mov	bx,1
	jmp	short l2295

	nop
l2295:	call	getpcbyte
	test	ax,80h
	jz	l229e
	inc	bx
l229e:	test	ax,40h
	jz	l22a9
	and	ax,0ff3fh
	jmp	short l22bb

	nop
l22a9:	and	ax,0ff3fh
	mov	cx,ax
	call	getpcbyte
	mov	ah,cl
	test	ax,2000h
	jz	l22bb
	or	ax,0c000h
l22bb:	dec	bx
	jz	l22e1
	cmp	ax,0
	jnz	l22c6
	jmp	retfalse

l22c6:	dec	ax
	jnz	l22cc
	jmp	rettrue

l22cc:	dec	ax
	mov	byte ptr l044f,0
	add	word ptr pc,ax
	cmp	word ptr pc,0200h
	jb	l22e1
	jmp	checkpc

l22e1:	ret

;-------------------- C N V T A D D --------------------

cnvtadd:mov	bx,ax
	xchg	al,ah
	shr	ax,1
	and	ax,7fh
	and	bx,01ffh
	ret

cnvtadd2:
	mov	bx,ax
	mov	al,ah
	sub	ah,ah
	sub	bh,bh
	shl	bx,1
	ret

l22fb:	push	cx
	mov	cl,7
	mov	bx,ax
	shr	ax,cl
	and	bx,7fh
	add	bx,bx
	add	bx,bx
	pop	cx
	ret

compadd:push	bx
	push	dx
	mov	bx,0eh
	mul	bx
	pop	dx
	pop	bx
	add	ax,word ptr orlist_pointer
	add	ax,70h
	ret

l231d:	push	ax
	push	cx
	mov	al,es: byte ptr [bx]
	inc	bx
	test	al,80h
	jnz	l2330
	test	al,40h
	jz	l232c
	inc	bx
l232c:	inc	bx
	pop	cx
	pop	ax
	ret

l2330:	mov	al,es: byte ptr [bx]
	and	al,3fh
	inc	bx
	xor	ah,ah
	add	bx,ax
	pop	cx
	pop	ax
	ret

;-------------------- P C O D E --------------------

pcode:	push	si			; Print encoded text: page ax, byte bx
	push	cx
	push	dx
	push	di
	push	bp
	sub	dx,dx			; Set single mode to zero (lower case)
	sub	di,di			; Set mode to zero (lower case)
pcode_nextword:		;l2346:
	call	getword			; Get the word into cx
	mov	si,cx			; Put coded word in si
	push	ax
	push	bx
	push	si
	mov	cx,3			; We can get three chars from a word
pcode_pushnext:		;pcodelp
	push	si			; Push the word onto stack
	mov	bp,cx
	mov	cl,5			; Shift the top 5 bits
	sar	si,cl			;  to the bottom
	mov	cx,bp
	loop	pcode_pushnext
	mov	cx,3			; Maximum to three chars per word
pcode_nextchar:		;l235f:
	pop	si			; Get next character
	and	si,00011111b		; Bottom five bits
	cmp	dx,0			; Special word mode
	jge	pcode_notspwrd		; No, jump
	shl	si,1			; Multiply code by two
	add	si,spwrd_pointer	; Add to special word pointer
	add	si,spwrd_base		; Add another offset
	mov	ax,es:[si]		; Get the location of the special word
	xchg	ah,al			; Turn it right way around
	call	cnvtadd2		; Table give offset in words,
					;  so use cnvtadd2
	call	pcode			; Print the special word
	jmp	pcode_chardone

pcode_notspwrd:				; Not a special word
	cmp	dx,3
	jl	pcode_modelt3		; Modes less than three are "normal"
	jnz	pcode_makechar
	xchg	dl,dh			; Mode is three
	or	dx,si			; Put the character into the mode
	jmp	pcode_loop		; It won't be three next time

pcode_makechar:		;l238f:		; Mode not three (actually greater)
	and	dx,3			; Only look at the bottom two bits
	mov	bp,cx			; Save cx
	mov	cl,5			; The last code was stored in bottom
	shl	dx,cl			;  two bits of the mode. Shift it up
	mov	cx,bp			; Restore cx
	or	dx,si			; Or in the current code
	mov	ax,dx			; Make the character
	jmp	short pcode_print
	nop

pcode_modelt3:
	cmp	si,6			; Codes less than 6 are special
	jl	pcode_codelt6
	cmp	dx,2			; Mode 0 or 1 ?
	jnz	pcode_lookup		; Modes 0 and 1 : just do a lookup
	cmp	si,7			; Mode 2 : Digit / punctuation
	je	pcode_pcrlf		; Digit 7 is a crlf
	jg	pcode_lookup		; Digit > 7 : Look it up too
	inc	dx			; Make char is code 6. Mode
					;  three indicates we are about
					;  to make a character. Inc dx
	jmp	short pcode_loop	;  from two to three
	nop

pcode_pcrlf:				; Digit code 7 is a crlf
	call	crlf			; Do the carraige return
	jmp	short pcode_chardone	; And forget any special modes, etc
	nop

pcode_lookup:
	mov	ax,dx			; Multiply mode by 26
	mov	bp,26
	mul	bp
	add	ax,si			; And add character code
	sub	ax,6			; Subtract an offset of six
	mov	bx,offset asciicodes
	xlat	al			; Lookup the character
	jmp	short pcode_print
	nop

pcode_codelt6:		;l23d0:
	cmp	si,0			; Code zero ?
	jnz	pcode_codenzlt6	; No, jump
	mov	ax,' '			; Code zero is a space
	jmp	short pcode_print	; Print the space
	nop

pcode_codenzlt6:			; Code is non-zero and less than 6
	cmp	si,3			; Mode switch code ? (4 or 5)
	jg	pcode_modeswitch	; Yes, jump
	or	dx,8000h
	dec	si
	mov	bp,cx
	mov	cl,6
	shl	si,cl
	mov	cx,bp
	mov	word ptr spwrd_base,si
	jmp	short pcode_loop
	nop

pcode_modeswitch:	;l23f4:		; Codes 4,5 are mode switch codes
	sub	si,3			; Make them codes 1,2
	cmp	dx,0			; Mode zero at the moment ?
	jnz	pcode_nmode0		; No, jump
	mov	dx,si			; Yes, new mode is 1 or 2
	jmp	short pcode_loop	; ie lowercase + code 4 => uppercase
	nop				;    lowercase + code 5 => digit/punct

pcode_nmode0:		;l2401:
	cmp	si,dx			; Compare mode with code
					; Code has been reduced to a 1 or 2,
					;  so a code corresponding to a mode
					;  now means locking in the mode
	je	pcode_lock
	sub	dx,dx			; Otherwise, set mode to lower case
pcode_lock:		;l2407:
	mov	di,dx			; Lock there
	jmp	short pcode_loop

	nop

pcode_jnextchar:	;l240c:
	jmp	pcode_nextchar

pcode_print:
	call	pchar
pcode_chardone:		;l2412:
	mov	dx,di
pcode_loop:		;l2414:
	loop	pcode_jnextchar
	pop	si
	pop	bx
	pop	ax
	cmp	si,0
	jnge	pcode_done
	jmp	pcode_nextword

pcode_done:
	pop	bp
	pop	di
	pop	dx
	pop	cx
	pop	si
	ret

l2427:	cmp	ax,0
	jnz	l2430
	mov	ax,3
	ret

l2430:	push	bx
	mov	bx,offset asciicodes
l2434:	inc	bx
	cmp	al,byte ptr -1[bx]
	jz	l2445
	cmp	byte ptr [bx],0
	jnz	l2434
	mov	ax,2
	jmp	short l2453

	nop
l2445:	sub	bx,07aah
	sub	ax,ax
l244b:	sub	bx,1ah
	jng	l2453
	inc	ax
	jmp	short l244b

l2453:	pop	bx
	ret

l2455:	push	bx
	mov	bx,offset asciicodes
l2459:	inc	bx
	cmp	al,byte ptr -1[bx]
	jz	l2469
	cmp	byte ptr [bx],0
	jnz	l2459
	sub	ax,ax
	jmp	short l2479

	nop
l2469:	sub	bx,07a5h
	mov	ax,bx
l246f:	cmp	ax,20h
	jnge	l2479
	sub	ax,1ah
	jmp	short l246f

l2479:	pop	bx
	ret

l247b:	push	si
	push	dx
	push	di
	push	bp
	mov	si,ax
	sub	di,di
	mov	cx,9
l2486:	inc	si
	mov	bl,byte ptr -1[si]
	cmp	bl,0
	jnz	l2498
	mov	ax,5
l2492:	push	ax
	loop	l2492
	jmp	short l24d1

	nop
l2498:	mov	ax,bx
	call	l2427
	cmp	ax,0
	jz	l24a9
	add	ax,3
	push	ax
	dec	cx
	jz	l24d1
l24a9:	mov	ax,bx
	call	l2455
	cmp	ax,0
	jnz	l24ce
	mov	ax,6
	push	ax
	dec	cx
	jz	l24d1
	mov	ax,bx
	mov	bp,cx
	mov	cl,5
	sar	ax,cl
	mov	cx,bp
	push	ax
	dec	cx
	jz	l24d1
	and	bx,1fh
	mov	ax,bx
l24ce:	push	ax
	loop	l2486
l24d1:	mov	bp,sp
	mov	ax,10h[bp]
	mov	cl,5
	shl	ax,cl
	or	ax,0eh[bp]
	shl	ax,cl
	or	ax,0ch[bp]
	mov	bx,0ah[bp]
	shl	bx,cl
	or	bx,8[bp]
	shl	bx,cl
	or	bx,6[bp]
	mov	dx,4[bp]
	shl	dx,cl
	or	dx,2[bp]
	shl	dx,cl
	or	dx,[bp]
	or	dx,8000h
	mov	cx,dx
	add	sp,12h
	pop	bp
	pop	di
	pop	dx
	pop	si
	ret

pchar:	test	byte ptr l0320,1
	jnz	l252d
	cmp	word ptr l0322,1
	jz	l251b
	jmp	mspchar

l251b:	push	bx
	mov	bx,word ptr l0326
	mov	es: byte ptr [bx],al
	inc	word ptr l0326
	inc	word ptr l0328
	pop	bx
	ret

l252d:	push	bp
	mov	bp,obufptr
	cmp	bp,word ptr l031c
	jnz	l253b
	jmp	short l25ac

	nop
l253b:	cmp	word ptr l031e,0
	jz	l2545
	jmp	l2613

l2545:	push	ax
	push	bx
	push	si
	mov	bx,word ptr obufptr
	mov	si,offset outbuff
l254f:	dec	bx
	cmp	byte ptr [bx],20h
	jz	l257e
	cmp	bx,si
	jnz	l254f
l2559:	mov	byte ptr [bx],0
	push	ax
	mov	ax,offset outbuff
	call	pmsg
	pop	ax
	mov	word ptr obufptr,si
	mov	word ptr l031e,4fh
	mov	bp,sp
	cmp	byte ptr 4[bp],' '
	jnz	l257b
	mov	word ptr 4[bp],0
l257b:	jmp	l260b

l257e:	cmp	bx,si
	jz	l2559
	mov	byte ptr [bx],0
	push	ax
	mov	ax,offset outbuff
	call	pmsg
	pop	ax
	mov	ax,word ptr obufptr
	inc	bx
l2591:	cmp	bx,ax
	jz	l25a1
	mov	bp,ax
	mov	al,byte ptr [bx]
	mov	byte ptr [si],al
	mov	ax,bp
	inc	bx
	inc	si
	jmp	short l2591

l25a1:	mov	ax,word ptr l031c
	sub	ax,si
	mov	word ptr l031e,ax
	jmp	short l2607

	nop
l25ac:	push	ax
	push	bx
	push	si
	mov	bx,word ptr l031c
	mov	si,offset outbuff
l25b6:	dec	bx
	cmp	byte ptr [bx],' '
	jz	l25dc
	cmp	bx,si
	jnz	l25b6
l25c0:	push	ax
	mov	ax,offset outbuff
	call	pmsg
	pop	ax
	mov	word ptr obufptr,si
	mov	bp,sp
	cmp	byte ptr 4[bp],20h
	jnz	l260b
	mov	word ptr 4[bp],0
	jmp	short l260b

	nop
l25dc:	cmp	bx,si
	jz	l25c0
	mov	byte ptr [bx],0
	push	ax
	mov	ax,offset outbuff
	call	pmsg
	pop	ax
	mov	ax,word ptr l031c
	inc	bx
l25ef:	cmp	bx,ax
	jz	l25ff
	mov	bp,ax
	mov	al,byte ptr [bx]
	mov	byte ptr [si],al
	mov	ax,bp
	inc	bx
	inc	si
	jmp	short l25ef

l25ff:	mov	ax,word ptr l031c
	sub	ax,si
	mov	word ptr l031e,ax
l2607:	mov	word ptr obufptr,si
l260b:	pop	si
	pop	bx
	pop	ax
	cmp	ax,0
	jz	l2622
l2613:	mov	bp,word ptr obufptr
	mov	[bp],al
	inc	word ptr obufptr
	dec	word ptr l031e
l2622:	pop	bp
	ret

crlf:	push	bx
	mov	bx,word ptr obufptr
	mov	byte ptr [bx],0
	mov	word ptr obufptr,034bh
	mov	word ptr l031e,4fh
	pop	bx
	push	ax
	mov	ax,offset outbuff
	call	pmsg
	pop	ax
	ret

l2642:	mov	ah,0fh
	int	10h
	cmp	al,0
	jnz	l2698
l264a:	call	scroll
	mov	ax,offset fatal
	call	pmsg
	mov	ax,offset l077a
	call	pmsg
	jmp	endgame

l265c:	mov	byte ptr l053a,0
	test	byte ptr switches,3
	jz	l2672
	test	byte ptr switches,1
	jnz	l26ab
	jmp	short l2684

	nop
l2672:	push	ax
	mov	ax,offset l057d
	call	pmsg
	pop	ax
l267a:	mov	ah,7
	int	21h
	and	al,5fh
	cmp	al,'Y'	;59h
	jnz	l2691
l2684:	mov	byte ptr mono,1
	mov	byte ptr text_attrib,17h
	jmp	short l26ab

	nop
l2691:	cmp	al,'N'	;4eh
	jnz	l267a
	jmp	short l26ab

	nop
l2698:	cmp	al,1
	jz	l264a
	cmp	al,2
	jz	l265c
	cmp	al,3
	jz	l265c
	test	byte ptr switches,2
	jnz	l265c
l26ab:	cmp	byte ptr alldatin,1
	jnz	l26bb
	call	l1163
	mov	bx,offset storyload_ansi
	call	ansi
l26bb:	ret

l26bc:	mov	al,byte ptr l01e5
	sub	ah,ah
	inc	ax
	div	ten
	add	ah,30h
	add	al,'0'	;30h
	mov	bx,offset l026f
	mov	word ptr [bx],ax
	mov	bx,offset l0284
	mov	word ptr [bx],ax
	mov	bx,offset outbuff
	mov	cl,byte ptr scrnlrx
	sub	ch,ch
	add	bx,cx
	dec	bx
	mov	word ptr l031c,bx
	mov	byte ptr [bx],0
	call	l318d
	ret

begin2:	call	chkdos
	sub	ax,ax
	sub	bx,bx
	call	readpg1
	mov	error,1
	cmp	byte ptr es:[0],4
	jnz	badvers
	test	byte ptr es:[1],1
	jz	gameok
badvers:call	scroll
	mov	ax,offset fatal
	call	pmsg
	mov	ax,offset wrngvers_msg
	call	pmsg
	jmp	endgame

gameok:	test	byte ptr l053b,1
	jnz	l273e
	mov	al,es:[1]
	or	al,3fh
	cmp	byte ptr mono,1
	jz	l2738
	cmp	byte ptr l053a,1
	jz	l273a
l2738:	and	al,37h
l273a:	mov	es:[1],al
l273e:	mov	byte ptr es:[1eh],6
	mov	byte ptr es:[1fh],41h
	mov	al,byte ptr l01e5
	mov	es:[20h],al
	mov	al,byte ptr scrnlrx
	mov	es:[21h],al
	mov	ax,es:[2]
	xchg	ah,al
	mov	word ptr l0333,ax
	mov	ax,es:[4]
	xchg	ah,al
	test	ax,01ffh
	jz	l2772
	and	ax,0fe00h
	add	ax,0200h
l2772:	mov	cx,ax
	mov	bp,cx
	mov	cl,9
	shr	bp,cl
	mov	cx,bp
	mov	word ptr pagea,cx
	mov	ax,80h
	sub	ax,cx
	push	cx
	mov	cx,3
	shl	ax,cl
	pop	cx
	mov	word ptr l0337,ax
	dec	cx
	cmp	byte ptr alldatin,1
	jnz	l27ce
	mov	ax,1
	mov	word ptr datbuf,1
	mov	cx,3fh
	call	l2f71
	jnz	l27c5
	mov	ax,40h
	mov	word ptr datbuf,40h
l27b1:	mov	cx,40h
	push	ax
	call	l2f71
	pop	ax
	jnz	l27c5
	add	word ptr datbuf,40h
	add	ax,40h
	jmp	short l27b1

l27c5:	mov	word ptr datbuf,0
	jmp	short l27de

	nop
l27ce:	mov	ax,1
	mov	bx,offset endprog
	add	bx,8
	mov	word ptr datbuf,bx
	call	l2f71
l27de:	mov	ax,es:[8]
	xchg	ah,al
	mov	word ptr vocab_pointer,ax
	mov	ax,es:[0ah]
	xchg	ah,al
	mov	word ptr orlist_pointer,ax
	mov	ax,es:[0ch]
	xchg	ah,al
	mov	word ptr glovar_pointer,ax
	mov	ax,es:[18h]
	xchg	ah,al
	mov	word ptr spwrd_pointer,ax
	mov	ax,es:[0eh]
	xchg	ah,al
	test	ax,1ffh
	jz	l2810
	add	ax,200h
l2810:	mov	cl,9
	sar	ax,cl
	and	ax,7fh
	mov	word ptr l0341,ax
	mov	bx,offset l03ec
	mov	si,word ptr vocab_pointer
	mov	cl,es: byte ptr [si]
	sub	ch,ch
	inc	si
l2827:	mov	al,es: byte ptr [si]
	mov	byte ptr [bx],al
	inc	bx
	inc	si
	loop	l2827
	mov	word ptr l0343,bx
	mov	bp,offset l032b
l2837:	mov	al,[bp]
l283a:	mov	byte ptr [bx],al
	inc	bx
	inc	bp
	cmp	al,0
	jnz	l2837
	mov	al,es: byte ptr [si]
	sub	ah,ah
	mov	word ptr l0345,ax
	inc	si
	mov	ax,es: word ptr [si]
	xchg	ah,al
	mov	word ptr l0347,ax
	add	si,2
	mov	word ptr l0349,si
	mov	si,word ptr pagea
	mov	cl,9
	shl	si,cl
	mov	word ptr datoffset,si
	jmp	l28fd

startgame:
	call	clopdat
	mov	word ptr l0553,0
	sub	ax,ax
	mov	byte ptr linecount,0
	mov	byte ptr highaddrflg,0
	mov	word ptr datbuf,0
	push	word ptr datoffset
	mov	word ptr datoffset,0
	mov	cx,word ptr l0341
	call	l2f71
	pop	word ptr datoffset
	mov	ah,byte ptr noprinter
	xor	al,al
	mov	es:[10h],ax
	mov	al,es: byte ptr 1
	or	al,'?'	;3fh
	test	byte ptr l053b,1
	jnz	l28c4
	mov	al,es: byte ptr 1
	or	al,'?'	;3fh
	cmp	byte ptr mono,1
	jz	l28c4
	cmp	byte ptr l053a,1
	jz	l28c6
l28c4:	and	al,'7'	;37h
l28c6:	mov	es: byte ptr 1,al
	mov	es: byte ptr 1eh,6
	mov	es: byte ptr 1fh,41h
	mov	al,byte ptr l01e5
	mov	es: byte ptr 20h,al
	mov	al,byte ptr scrnlrx
	mov	es: byte ptr 21h,al
	or	es: byte ptr 1,20h
	mov	word ptr scrnlry,0
	mov	byte ptr l0450,0
	mov	byte ptr l0452,0
	jmp	short l2900

	nop
l28fd:	call	l26bc
l2900:	mov	word ptr l031e,4fh
	call	l31b6
	mov	byte ptr l0302,0
	call	l1163
	mov	sp,offset stack
	mov	di,offset begin
	mov	word ptr obufptr,034bh
	mov	word ptr lvarptr,di
	sub	word ptr lvarptr,2
	mov	ax,es: word ptr 6
	xchg	ah,al
	call	cnvtadd
	mov	word ptr pc_page,ax
	mov	word ptr pc,bx
	call	checkpc
	jmp	short reentry
	nop

;-------------------- R E E N T R Y --------------------

reentry:call	getpcbyte		; Get byte at pc
	mov	dx,ax			; Store instruction in dx too
	cmp	ax,80h
	jnb	nottwoprm
	jmp	twoprm			; x < 80 : two parameters

nottwoprm:
	cmp	ax,0b0h
	jge	notoneprm
	jmp	oneprm			; 80 <= x < b0 : one parameter

notoneprm:
	cmp	ax,0c0h
	jg	multiparam
	jmp	noprm			; b0 <= x <= c0 : no parameters

multiparam:
	and	ax,00111111b		; Get a number between 0 & 3fh
	shl	ax,1			; Multiply by two for lookup
	mov	bp,ax
	mov	si,vectors2[bp]		; Loop up the table
	cmp	si,0			; Illegal opcode ?
	jnz	multi_ok
	jmp	illop

multi_ok:
	mov	bp,4
	cmp	dx,0ech
	jnz	l298f
	mov	bp,8
	call	getpcbyte
	mov	dx,ax
	call	getpcbyte
	mov	cx,4
l2983:	push	ax
	shr	ax,1
	shr	ax,1
	loop	l2983
	mov	ax,dx
	jmp	short l2992

	nop
l298f:	call	getpcbyte
l2992:	mov	cx,4
l2995:	push	ax
	sar	ax,1
	sar	ax,1
	loop	l2995
	mov	cx,bp
	sub	dx,dx
	mov	bx,offset param1
l29a3:	pop	ax
	and	ax,3
	cmp	ax,3
	jz	l29ba
	call	getparam
	mov	word ptr [bx],ax
	add	bx,2
	inc	dx
	loop	l29a3
	jmp	short l29bf

	nop
l29ba:	dec	cx
	shl	cx,1
	add	sp,cx
l29bf:	xchg	cx,dx
	mov	ax,cx
	cmp	byte ptr [si],90h
	jz	multi_none
	dec	cx
	jnge	multi_none
	jz	multi_one
	sub	cx,2
	jnge	multi_two
	jz	multi_three
	mov	dx,word ptr param4
multi_three:	mov	cx,word ptr param3	;29d8
multi_two:	mov	bx,word ptr param2	;29dc
multi_one:	mov	ax,word ptr param1	;29e0
multi_none:	jmp	dovector		;29e3

twoprm:	and	ax,00011111b		; Get a number between 0 & 1fh
	shl	ax,1			; Multiply by two for lookup
	mov	bp,ax
	mov	si,vectors2[bp]		; Look up the table
	cmp	si,0			; Illegal opcode ?
	jz	illop			; Yes, print error and exit
	mov	ax,1			; Assume first param is a byte
	test	dx,01000000b		; Bit 6 tells us
	jz	twoprm_p1		; Bit 6 off : param1 is a byte
	inc	ax			; Bit 6 on : param1 is a var
twoprm_p1:
	call	getparam		; Get the parameter
	push	ax			; Store it
	mov	ax,1			; Assume second param is a byte
	test	dx,00100000b		; Bit 5 tells us
	jz	twoprm_p2		; Bit 5 off : param2 is a byte
	inc	ax			; Bit 5 on : param2 is a var
twoprm_p2:
	call	getparam		; Get the parameter
	mov	bx,ax			; Put it in bx
	pop	ax			; Get back param1
	cmp	byte ptr [si],90h	; If first instruction is a NOP
					;  put params into memory
	jnz	dovector
	mov	param1,ax
	mov	param2,bx
	mov	ax,2			; Two parameters
	jmp	short dovector		; Do the opcode

	nop
oneprm:	and	dx,00001111b		; Get a number between 0 & 0fh
	shl	dx,1			; Double it
	mov	bp,dx
	mov	si,vectors1[bp]		; Look up the table
	cmp	si,0			; Illegal operation ?
	jz	illop			; Yes, printe error and exit
	sar	ax,1
	sar	ax,1
	sar	ax,1
	sar	ax,1
	and	ax,3			; Bits 4,5 are now in 0,1
	call	getparam		; Get the parameter
	jmp	short dovector		; Do the opcode

	nop
noprm:	and	ax,00001111b		; Get a number between 0 & 0fh
	shl	ax,1			; Double it
	mov	bp,ax
	mov	si,vectors0[bp]		; Look up the table
	cmp	si,0			; Illegal operation ?
	jnz	dovector		; No, do the instruction
illop:	call	scroll
	mov	ax,offset fatal		; "Fatal error: "
	call	pmsg
	mov	ax,offset illegalop_msg		; "Illegal operation"
	call	pmsg
	jmp	endgame			; Finito

dovector:
	call	si			; Call the vector in si
	jmp	reentry			; Next instruction

checkpc:mov	byte ptr l044f,0
	mov	byte ptr l044d,0
	push	si
	push	bp
	push	bx
	push	cx
	push	dx
	sub	ax,ax
	mov	bx,word ptr pc_page
	mov	cx,9
l2a87:	shl	ax,1
	shl	bx,1
	adc	ax,0
	loop	l2a87
	mov	si,word ptr pc
	xchg	ax,si
	cwd
	xchg	ax,si
	add	bx,si
	adc	ax,dx
	mov	dx,bx
	and	dx,01ffh
	mov	word ptr pc,dx
	mov	cl,9
	sar	bx,cl
	and	bx,7fh
	cmp	ax,0
	jz	l2ac7
	mov	cl,7
	shl	ax,cl
	or	bx,ax
	shr	ax,cl
	test	byte ptr alldatin,1
	jz	l2ad3
	mov	byte ptr highaddrflg,al
	jmp	short l2ad3

	nop
l2ac7:	test	byte ptr alldatin,1
	jz	l2ad3
	mov	byte ptr highaddrflg,0
l2ad3:	mov	word ptr pc_page,bx
	test	byte ptr l0423,1
	jnz	l2ae4
	cmp	bx,word ptr l0438
	jz	l2b50
l2ae4:	mov	word ptr l0438,bx
	mov	ax,word ptr l043a
	cmp	ax,0
	jz	l2b01
	mov	bp,ax
	mov	cx,l043c
	mov	[bp],cx
	mov	cx,l043e
	mov	2[bp],cx
	inc	ax
l2b01:	cmp	byte ptr alldatin,1
	jz	l2b36
	cmp	bx,pagea
	jnge	l2b36
	mov	ax,bx
	call	l2b5b
	mov	bl,linecount
	mov	highaddrflg,bl
	mov	bx,ax
	mov	ax,datbuf
	add	ax,2
	mov	word ptr l043a,ax
	mov	bp,ax
	mov	word ptr [bp],-1
	mov	word ptr 2[bp],-1
	inc	ax
	jmp	short l2b4c

	nop
l2b36:	mov	cl,9
	shl	bx,cl
	test	byte ptr alldatin,1
	jnz	l2b46
	mov	byte ptr highaddrflg,0
l2b46:	mov	word ptr l043a,0
l2b4c:	mov	word ptr l0436,bx
l2b50:	mov	byte ptr l0423,0
	pop	dx
	pop	cx
	pop	bx
	pop	bp
	pop	si
	ret

l2b5b:	cmp	ax,word ptr l0440
	jnz	l2b65
	mov	ax,word ptr l0442
	ret

l2b65:	mov	word ptr l0440,ax
	push	cx
	push	bx
	add	word ptr l043e,1
	adc	word ptr l043c,0
	mov	bx,offset endprog
l2b77:	add	bx,2
	cmp	ax,-2[bx]
	jnz	l2be8
	cmp	ax,word ptr l0438
	jz	l2b92
	mov	cx,word ptr l043c
	mov	word ptr [bx],cx
	mov	cx,word ptr l043e
	mov	word ptr 2[bx],cx
l2b92:	sub	bx,2
	push	bx
	sub	bx,3260h
	mov	ax,bx
	cmp	bx,word ptr l0337
	pop	bx
	jnge	l2bbe
	mov	byte ptr linecount,1
	sub	ax,word ptr l0337
	mov	cl,3
	shr	ax,cl
l2bb0:	cmp	ax,80h
	jb	l2bc3
	inc	byte ptr linecount
	sub	ax,80h
	jmp	short l2bb0

l2bbe:	mov	byte ptr linecount,0
l2bc3:	mov	word ptr datbuf,bx
	sub	bx,3260h
	mov	cl,6
	cmp	byte ptr linecount,0
	jz	l2bd8
	mov	bx,ax
	mov	cl,9
l2bd8:	shl	bx,cl
	cmp	byte ptr linecount,0
	jnz	l2c0f
	add	bx,word ptr datoffset
	jmp	short l2c0f

	nop
l2be8:	add	bx,6
	cmp	word ptr [bx],-1
	jnz	l2b77
	call	l2c17
	push	ax
	mov	word ptr datbuf,bx
	mov	ax,word ptr l0440
	mov	word ptr [bx],ax
	mov	cx,word ptr l043c
	mov	word ptr 2[bx],cx
	mov	cx,word ptr l043e
	mov	word ptr 4[bx],cx
	pop	bx
	call	readpg1
l2c0f:	mov	ax,bx
	mov	word ptr l0442,ax
	pop	bx
	pop	cx
	ret

l2c17:	push	cx
	mov	bx,offset endprog
	mov	cx,-1
	mov	dx,cx
	add	bx,2
l2c23:	add	bx,2
	cmp	word ptr -2[bx],cx
	ja	l2c38
	jb	l2c31
	cmp	word ptr [bx],dx
	jnb	l2c38
l2c31:	mov	cx,word ptr -2[bx]
	mov	dx,word ptr [bx]
	mov	ax,bx
l2c38:	add	bx,6
	cmp	byte ptr -2[bx],-1
	jnz	l2c23
	inc	cx
	jz	l2c85
	sub	ax,4h
	mov	bx,ax
	sub	ax,offset endprog
	cmp	ax,word ptr l0337
	jnge	l2c6f
	mov	byte ptr linecount,1
	sub	ax,word ptr l0337
	mov	cl,3
	shr	ax,cl
	mov	cl,9
l2c61:	cmp	ax,80h
	jb	l2c76
	sub	ax,80h
	inc	byte ptr linecount
	jmp	short l2c61

l2c6f:	mov	byte ptr linecount,0
	mov	cl,6
l2c76:	shl	ax,cl
	cmp	byte ptr linecount,0
	jnz	l2c83
	add	ax,word ptr datoffset
l2c83:	pop	cx
	ret

l2c85:	call	scroll
	mov	ax,offset fatal
	call	pmsg
	mov	ax,offset nofreepages_msg
	call	pmsg
	jmp	endgame

chkdos:	mov	ah,30h			; Check DOS version
	int	21h
	cmp	al,2
	jge	dosok
	call	scroll
	mov	ax,offset fatal		; "Fatal error: "
	call	pmsg
	mov	ax,offset dosver		; "Wrong DOS version"
	call	pmsg
	jmp	endgame

dosok:	mov	byte ptr l053a,0
	push	es
	push	di
	mov	bx,0f000h
	mov	es,bx
	mov	di,0e000h
	mov	ax,offset l0526
	mov	cx,16h
	mov	dx,9h
	call	l2e9f
	pop	di
	pop	es
	jb	l2cd5
	mov	byte ptr l053a,1
l2cd5:	mov	ah,19h
	int	21h
	mov	byte ptr l01d7,al
	mov	byte ptr sav_drive,al
	call	l2ec9
	mov	byte ptr l053b,0
	mov	ah,3dh
	mov	al,0
	mov	dx,offset dat_name
	int	21h
	jnb	l2cf5
	jmp	l2e2a

l2cf5:	mov	word ptr dat_handle,ax
	mov	bx,ax
	xor	cx,cx
	xor	dx,dx
	mov	ah,42h
	mov	al,2
	int	21h
	mov	cx,4
l2d07:	shr	ax,1
	test	dx,1
	jnz	l2d16
l2d0f:	shr	dx,1
	loop	l2d07
	jmp	short l2d1b

	nop
l2d16:	or	ah,80h
	jmp	short l2d0f

l2d1b:	mov	cl,5
	shr	ax,cl
	mov	word ptr l01c4,ax
	xor	cx,cx
	mov	dx,4
	mov	ah,42h
	mov	al,0
	int	21h
	mov	ah,3fh
	mov	cx,2
	mov	dx,offset l01d4
	int	21h
	mov	ax,word ptr l01d4
	xchg	ah,al
	test	ax,01ffh
	jz	l2d47
	and	ax,0fe00h
	add	ax,200h
l2d47:	mov	cl,9
	shr	ax,cl
	mov	dx,ax
	mov	bx,2
	mov	bx,cs: word ptr [bx]
	mov	ax,cs
	sub	bx,ax
	mov	cl,4
	mov	ax,offset endprog
	shr	ax,cl
	inc	ax
	and	ax,0fe0h
	add	ax,20h
	sub	bx,ax
	test	byte ptr switches,4
	jz	l2d78
	cmp	bx,word ptr l041a
	jna	l2d78
	mov	bx,word ptr l041a
l2d78:	cmp	bx,0640h
	jnb	l2d90
	call	scroll
	mov	ax,offset fatal
	call	pmsg
	mov	ax,offset nomemory
	call	pmsg
	jmp	endgame

l2d90:	mov	cl,5
	shr	bx,cl
	cmp	bx,word ptr l01c4
	jge	l2de2
	sub	bx,dx
	ja	l2db0
l2d9e:	call	scroll
	mov	ax,offset fatal
	call	pmsg
	mov	ax,offset nomemory
	call	pmsg
	jmp	endgame

l2db0:	cmp	bx,5
	jna	l2d9e
	sub	bx,4
	cmp	bx,0ffh
	jb	l2dd8
	sub	bx,2
	cmp	bx,017fh
	jb	l2dd8
	sub	bx,2
	cmp	bx,01ffh
	jng	l2dd8
	mov	byte ptr alldatin,1
	mov	bx,01ffh
l2dd8:	push	bx
	add	bx,dx
	cmp	bx,word ptr l01c4
	pop	bx
	jna	l2ded
l2de2:	mov	byte ptr alldatin,1
	mov	bx,offset endprog
	jmp	short l2dfc

	nop
l2ded:	mov	word ptr l040c,bx
	mov	cl,3
	shl	bx,cl
	add	bx,2
	add	bx,3260h
l2dfc:	mov	cx,4
	shr	bx,cl
	mov	ax,ds
	add	bx,ax
	add	bx,1
	mov	word ptr lowseg,bx
	add	bx,1000h
	mov	word ptr l0448,bx
	test	byte ptr alldatin,1
	jnz	l2e1e
	call	l2e3c
l2e1e:	call	l2642
	call	l31c7
	mov	ax,word ptr lowseg
	mov	es,ax
	ret

l2e2a:	call	scroll
	mov	ax,offset fatal
	call	pmsg
	mov	ax,offset datnotfnd_msg
	call	pmsg
	jmp	endgame

l2e3c:	push	si
	push	di
	push	ax
	push	bx
	push	cx
	mov	di,offset endprog
	mov	cx,word ptr l040c
	mov	ax,ds
	mov	es,ax
	cld
l2e4d:	mov	si,offset l0411
	push	cx
	mov	cx,8
	rep	movsb
	pop	cx
	loop	l2e4d
	mov	word ptr [di],-1
	mov	bx,word ptr lowseg
	mov	es,bx
	pop	cx
	pop	bx
	pop	ax
	pop	di
	pop	si
	ret

clopdat:push	dx
	mov	dl,byte ptr l01d7
	mov	ah,0eh
	int	21h
	mov	ah,3eh
	mov	bx,word ptr dat_handle
	int	21h
l2e7a:	mov	ah,3dh
	mov	al,0
	mov	dx,offset dat_name
	int	21h
	jnb	l2e92
	push	ax
	mov	ax,offset insertdat_msg
	call	pmsg
	pop	ax
	call	keyin
	jmp	short l2e7a

l2e92:	mov	word ptr dat_handle,ax
	mov	dl,byte ptr sav_drive
	mov	ah,0eh
	int	21h
	pop	dx
	ret

l2e9f:	cld
	push	si
	push	dx
	mov	bp,sp
	mov	si,ax
l2ea6:	cmp	byte ptr [si],24h
	jz	l2ebf
	cmpsb
	jnz	l2eb4
	dec	dx
	loop	l2ea6
	jmp	short l2ebb

	nop
l2eb4:	mov	si,ax
	mov	dx,[bp]
	loop	l2ea6
l2ebb:	stc
	pop	dx
	pop	si
	ret

l2ebf:	test	dx,dx
	jnz	l2ebb
	clc
	pop	dx
	pop	si
	ret

	clc
	ret

l2ec9:	cld
	mov	si,80h
	lodsb
	test	al,al
	jnz	l2ed3
l2ed2:	ret

l2ed3:	dec	al
	xor	dx,dx
	mov	dl,al
	add	dx,82h
	inc	si
l2ede:	cmp	si,dx
	lodsb
	jz	l2ed2
	cmp	al,'/'	;2fh
	jnz	l2ede
	lodsb
	and	al,5fh
	cmp	al,'M'	;4dh
	jnz	l2ef5
	or	byte ptr switches,1
	jmp	short l2ede

l2ef5:	cmp	al,'W'	;57h
	jnz	l2f05
	mov	byte ptr l053b,0
	or	byte ptr switches,8
	jmp	short l2ede

l2f05:	cmp	al,'G'	;47h
	jnz	l2f15
	mov	di,offset dat_name
l2f0c:	movsb
	cmp	dx,si
	jnz	l2f0c
	mov	al,0
	stosb
	ret

l2f15:	cmp	al,'C'	;43h
	jnz	l2f20
	or	byte ptr switches,2
	jmp	short l2ede

l2f20:	cmp	al,'K'	;4bh
	jnz	l2f56
	mov	bx,0
l2f27:	cmp	dx,si
	jnz	l2f3b
l2f2b:	or	byte ptr switches,4
	mov	cl,6
	shl	bx,cl
	mov	word ptr l041a,bx
	dec	si
	jmp	short l2ede

l2f3b:	lodsb
	cmp	al,0
	jz	l2f2b
	cmp	al,' '	;20h
	jz	l2f2b
	cmp	al,'/'	;2fh
	jz	l2f2b
	xor	ah,ah
	aaa
	xchg	ax,bx
	push	dx
	mul	ten
	add	bx,ax
	pop	dx
	jmp	short l2f27

l2f56:	cmp	al,'P'	;50h
	jz	l2f5c
	jmp	short l2ede

l2f5c:	push	dx
	mov	dx,0
	mov	ah,1
	int	17h
	pop	dx
	jmp	l2ede

readpg1:push	cx
	mov	cx,1
	call	l2f71
	pop	cx
	ret

l2f71:	mov	byte ptr readwrite,0
	push	ax
	mov	ax,word ptr dat_handle
	mov	word ptr l01dc,ax
	pop	ax
	push	bp
	push	dx
	push	bx
	push	si
	mov	bx,0
	mov	dx,cx
	mov	cx,9
l2f8a:	shl	dx,1
	shl	ax,1
	pushf
	shl	bx,1
	popf
	adc	bx,0
	loop	l2f8a
	mov	cx,bx
	mov	bx,word ptr l01dc
	mov	si,dx
	test	byte ptr l01de,1
	jz	l2fae
	mov	dx,ax
	mov	ah,42h
	mov	al,0
	int	21h
l2fae:	mov	dx,word ptr datbuf
	test	byte ptr alldatin,1
	jnz	l2fd6
	cmp	dx,0
	jz	l2fd6
	sub	dx,3260h
	mov	cl,3
	shr	dx,cl
	mov	cl,9
	cmp	byte ptr linecount,0
	jnz	l2fd6
	mov	ax,word ptr datoffset
	shr	ax,cl
	add	dx,ax
l2fd6:	mov	cx,si
	mov	ah,3fh
	cmp	byte ptr readwrite,0
	jz	l2fe3
	mov	ah,40h
l2fe3:	test	byte ptr alldatin,1
	jnz	l2ffd
	cmp	byte ptr linecount,0
	jz	l3022
	mov	si,word ptr l0337
	push	cx
	mov	cl,3
	shr	si,cl
	pop	cx
	sub	dx,si
l2ffd:	mov	si,word ptr lowseg
	test	byte ptr alldatin,1
	jnz	l300c
	add	si,1000h
l300c:	cmp	dx,80h
	jb	l301c
	sub	dx,80h
	add	si,1000h
	jmp	short l300c

l301c:	push	ds
	mov	ds,si
	jmp	short l3027

	nop
l3022:	push	ds
	mov	si,es
	mov	ds,si
l3027:	push	cx
	mov	cl,9
	shl	dx,cl
	pop	cx
	int	'!'	;21h
	cmp	ax,cx
	pop	ds
	mov	byte ptr l01de,1
l3037:	pop	si
	pop	bx
	pop	dx
	pop	bp
	ret

	push	ax
	mov	ax,word ptr dat_handle
	cmp	word ptr l01dc,ax
	jz	l3049
	stc
	jmp	short l3037

l3049:	call	scroll
	mov	ax,offset fatal
	call	pmsg
	mov	ax,offset datrdfailed_msg
	call	pmsg
	jmp	endgame

keyin:	push	cx
	push	dx
	cmp	byte ptr keytoggle,0
	jnz	l3069
	mov	byte ptr keytoggle,1
l3069:	mov	ah,7
	int	'!'	;21h
	sub	ah,ah
	pop	dx
	pop	cx
	ret

l3072:	mov	ax,7
	call	mspchar
	ret

mspchar:push	ax
	push	bx
	push	cx
	push	dx
	push	bp
	push	si
	push	ax
	test	byte ptr l032a,1
	jz	l30c1
	dec	al
	xor	ah,ah
	cmp	ax,0
	jb	l30b9
	cmp	ax,4
	ja	l30b9
	mov	si,offset l0217
	cmp	byte ptr mono,1
	jz	l30ac
	mov	si,offset l01f0
	cmp	byte ptr l053a,1
	jz	l30ac
	mov	si,offset l01e6
l30ac:	shl	al,1
	mov	bx,ax
	mov	bx,word ptr [bx+si]
	call	ansi
	pop	ax
	jmp	short l30d3

	nop
l30b9:	inc	al
	mov	ah,6
	mov	dl,al
	int	'!'	;21h
l30c1:	pop	ax
	test	byte ptr noprinter,1
	jz	l30d3
	cmp	byte ptr script,1
	jz	l30d3
	call	lpchar
l30d3:	pop	si
	pop	bp
	pop	dx
	pop	cx
	pop	bx
	pop	ax
	ret

scroll:	push	ax
	push	bx
	push	cx
	push	dx
	push	bp
	test	byte ptr l032a,1
	jz	l3161
	test	byte ptr l053b,1
	jnz	l3105
	test	byte ptr l0450,1
	jnz	l3105
	mov	ah,6
	mov	al,1
	mov	cx,word ptr scrnlry
	mov	dx,184fh			;CHECK THIS
	mov	bh,byte ptr text_attrib
	int	10h
l3105:	mov	ah,6
	mov	dl,0dh
	int	'!'	;21h
	test	byte ptr l0450,1
	jnz	l3119
	test	byte ptr l053b,1
	jz	l311f
l3119:	mov	ah,6
	mov	dl,0ah
	int	'!'	;21h
l311f:	test	byte ptr l0450,1
	jnz	l3161
	inc	word ptr l0553
	mov	al,byte ptr l01e5
	sub	ah,ah
	dec	ax
	mov	dx,word ptr scrnlry
	xchg	dh,dl
	sub	al,dl
	cmp	word ptr l0553,ax
	jnge	l3161
	mov	word ptr l0553,0
	mov	byte ptr script,1
	push	ax
	mov	ax,offset l0540
	call	pmsg
	pop	ax
	call	keyin
	push	ax
	mov	ax,offset l0547
	call	pmsg
	pop	ax
	mov	byte ptr script,0
l3161:	test	byte ptr noprinter,1
	jz	l3172
	call	l1abb
	or	es:[10h],0400h
l3172:	pop	bp
	pop	dx
	pop	cx
	pop	bx
	pop	ax
	ret

ansi:	mov	cl,byte ptr [bx]
	sub	ch,ch
	cmp	cl,0
	jz	l318c
l3181:	inc	bx
	mov	dl,byte ptr [bx]
	mov	ah,6
	push	bx
	int	21h
	pop	bx
	loop	l3181
l318c:	ret

l318d:	mov	bx,offset clstlhs_ansi
	test	byte ptr mono,1
	jz	l319a
	mov	bx,offset colclstlhs_ansi
l319a:	call	ansi
	ret

pmsg:	push	bx
	mov	bx,ax
l31a1:	mov	al,byte ptr [bx]
	cmp	al,0
	jz	l31b1
	cmp	al,80h
	jz	l31b4
	call	mspchar
	inc	bx
	jmp	short l31a1

l31b1:	call	scroll
l31b4:	pop	bx
	ret

l31b6:	push	cx
	push	dx
	mov	ah,2ch
	int	21h
	mov	word ptr hourmin,cx
	mov	word ptr sechund,dx
	pop	dx
	pop	cx
	ret

l31c7:	push	ax
	mov	al,0b6h
	out	43h,al
	pop	ax
	ret

port42:	push	ax
	push	cx
	mov	al,cl
	out	42h,al
	mov	al,ch
	out	42h,al
	pop	cx
	pop	ax
	ret

click:	push	ax
	in	al,61h
	or	al,3
	out	61h,al
	pop	ax
	ret

click2:	push	ax
	in	al,61h
	and	al,0fch
	out	61h,al
	pop	ax
	ret

l31ed:	push	ax
	push	bx
	push	cx
	push	dx
	call	wait
	mov	byte ptr l0453,dl
l31f8:	push	cx
l31f9:	mov	ah,2ch
	int	21h
	cmp	dl,byte ptr l0453
	jz	l31f9
	pop	cx
	mov	byte ptr l0453,dl
	loop	l31f8
	pop	dx
	pop	cx
	pop	bx
	pop	ax
	ret

wait:	push	ax
	push	bx
	push	cx
	mov	ah,2ch
	int	21h
	mov	byte ptr l0453,dl
l321a:	mov	ah,2ch
	int	21h
	cmp	dl,byte ptr l0453
	jz	l321a
	pop	cx
	pop	bx
	pop	ax
	ret

l3228:	push	ax
	push	bx
	push	dx
	mov	dx,12h
	mov	ax,34deh		; CHECK THIS
	div	cx
	mov	cx,ax
	pop	dx
	pop	bx
	pop	ax
	ret

sound:	push	ax
	push	bx
	push	cx
	push	dx
	call	l3228
	call	port42
	call	click
	mov	cx,dx
	call	l31ed
	call	click2
	pop	dx
	pop	cx
	pop	bx
	pop	ax
	ret

endgame:call	scroll
	mov	bx,offset allattoff_ansi
	call	ansi
	mov	ah,4ch
	int	21h

endprog	equ	$

amfv	endp
cseg	ends

	end	start
