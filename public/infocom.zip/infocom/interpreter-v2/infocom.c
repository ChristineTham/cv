/* File: infocom.c */

#include	<stdio.h>
#include	<string.h>
#include	"infocom.h"

word		random1 ;
word		random2 ;
word		pc_offset ;
word		pc_page ;
word		resident_blocks ;
word		save_blocks ;
word		status ;

header		data_head ;
object		*obj_list ;
byte		*base_ptr ;
byte		*base_end ;
byte		*vocab ;
byte		*global_ptr ;
byte		*end_resident_area ;
word		*stack_base ;
word		*stack_var_ptr ;
word		*stack ;

pg_table	*strt_page_table ;
byte		*page_strt ;
byte		*prog_block_ptr ;

/* Score Routine Variables */

word		score_time ;
byte		*s_buff_strt ;
byte		*s_buff_ptr ;

/* Input Routine Variables */

byte		*ws_buff_strt ;
byte		*end_of_sentence ;
word		num_vocab_words ;
word		vocab_entry_size ;
byte		*strt_vocab_table ;
byte		*end_vocab_table ;

/* Print Routine Variables */

ProcPtr		PrintChar ;
byte		*common_word_ptr ;
byte		*p_buff_strt ;
byte		*p_buff_ptr ;
byte		*p_buff_end ;

char	ws_table[] = { ' ','\t','\r','.',',','?','\0','\0' };

char	table[] =
	{
		'a','b','c','d','e','f','g','h','i','j','k','l',
		'm','n','o','p','q','r','s','t','u','v','w','x',
		'y','z','A','B','C','D','E','F','G','H','I','J',
		'K','L','M','N','O','P','Q','R','S','T','U','V',
		'W','X','Y','Z',' ',' ','0','1','2','3','4','5',
		'6','7','8','9','.',',','!','?','_','#','\'',
		'\"','/','\\','-',':','(',')','\0','\0'
	};

extern void	init(), options(), interp(), exit();
extern int	open_file();

void	usage();

int
main(argc, argv)
int	argc;
char	*argv[];
{
	Boolean		head	= false;
	Boolean		objs	= false;
	Boolean		vocab	= false;
	Boolean		opts	= false;
	int		i;
	char		*myname;
	char		*ptr;

#ifdef	NOARGV0
	myname = "infocom";
#else
	if ((myname = strrchr(*argv, SEPARATOR)) == NULL)
		myname = *argv;
	else
		++myname;
#endif

	if (argc == 1)
		usage(myname);

	while (--argc)
	{
		if (**++argv == '-')
		{
			ptr = *argv;
			while (*++ptr)
				switch (*ptr)
				{
				case	'h':
					head = true;
					opts++;
					break;

				case	'o':
					objs = true;
					opts++;
					break;

				case	'v':
					vocab = true;
					opts++;
					break;

				default:
					usage(myname);
				}
		}
		else if (open_file(*argv))
		{
			init();
			if (opts)
				options(head, objs, vocab);
			else
				interp();
		}
		else
		{
			printf("%s: cannot open %s\n", myname, *argv);
			return 2;
		}
	}

	return 0;
}

void
usage(name)
char	*name;
{
	printf("Usage: %s [-hov] <filename>\n", name);
	exit(1);
}
