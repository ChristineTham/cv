/* File: options.c */

#include	"infocom.h"

#define		words_per_line	8

options ( head,objs,vocab )
Boolean		head,objs,vocab ;
{
	if ( head )
		show_header () ;
	if ( vocab )
		show_vocab () ;
	if ( objs )
		show_objects () ;
}

show_header ()
{
	extern header	data_head ;

	word			i ;

	printf ( "INFOCOM Data File Header.\n\n" ) ;
	printf ( "Z-Code Version: $%x\n",(int)data_head.z_code_version ) ;
	if ( (data_head.score_or_time & 0x02) == 0 )
		printf ( "Score/Time    : Score\n" ) ;
	else
		printf ( "Score/Time    : Time\n" ) ;
	printf ( "Release Number: $%x\n",data_head.release ) ;
	printf ( "Resident Bytes: $%x\n",data_head.resident_bytes ) ;
	printf ( "Start Address : $%x\n",data_head.start ) ;
	printf ( "Vocab Address : $%x\n",data_head.vocab ) ;
	printf ( "Object List   : $%x\n",data_head.object_list ) ;
	printf ( "Global Vars.  : $%x\n",data_head.globals ) ;
	printf ( "Save Bytes    : $%x\n",data_head.save_bytes ) ;
	if ( data_head.script_status == 0 )
		printf ( "Script Status : Off\n" ) ;
	else
		printf ( "Script Status : On\n" ) ;
	printf ( "Serial Number : " ) ;
	for ( i = 0 ; i < 6 ; i++ )
		printf ( "%c",data_head.serial_no[i] ) ;
	printf ( "\n" ) ;
	printf ( "Common Words  : $%x\n",data_head.common_word ) ;
	printf ( "Verify Length : $%x\n",data_head.verify_length ) ;
	printf ( "Verify Check  : $%x\n",data_head.verify_checksum ) ;
	printf ( "\n\n" ) ;
}

show_vocab ()
{
	extern word		num_vocab_words ;
	extern word		vocab_entry_size ;
	extern byte		*strt_vocab_table ;
	extern byte		*base_ptr ;
	extern byte		*p_buff_strt ;
	extern byte		*p_buff_ptr ;
	extern ProcPtr	PrintChar ;

	byte			*ptr ;
	word			page ;
	word			offset ;
	word			count ;

	printf ( "INFOCOM Adventure - Vocab List.\n\n" ) ;
	printf ( "Number of Words: $%x\n\n",num_vocab_words ) ;
	p_buff_ptr = p_buff_strt ;
	count = 0 ;
	ptr = strt_vocab_table ;
	while ( count < num_vocab_words )
	{
		page = ( ptr - base_ptr ) / block_size ;
		offset = ( ptr - base_ptr ) % block_size ;
		print_coded ( &page,&offset ) ;
		(*PrintChar)((word)'\t') ;
		ptr += vocab_entry_size ;
		++count ;
		if ( (count % words_per_line) == 0 )
			new_line () ;
	}
	new_line () ;
	new_line () ;
}

show_objects ()
{
	extern object	*obj_list ;
	extern byte		*p_buff_strt ;
	extern byte		*p_buff_ptr ;

	object			*obj ;
	word			i,j ;

	printf ( "INFOCOM Adventure - Object List.\n\n" ) ;
	p_buff_ptr = p_buff_strt ;
	for ( i = 1 ; i < 256 ; i++ )
	{
		obj = obj_addr ( i ) ;
		printf ( "Object $%x : ",i ) ;
		p_obj ( i ) ;
		new_line () ;
		printf ( "\t -> attributes : " ) ;
		for ( j = 0 ; j < 4 ; j++ )
			printf ( "$%x ",obj->attributes[j] ) ;
		printf ( "\n" ) ;
		printf ( "\t -> location   : $%x\n",obj->location ) ;
		printf ( "\t -> link       : $%x\n",obj->link ) ;
		printf ( "\t -> holds      : $%x\n",obj->holds ) ;
		printf ( "\n" ) ;
	}
}
