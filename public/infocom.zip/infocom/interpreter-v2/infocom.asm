;IBM Standard executor (new). Disassembly started 3rd Feb 1987
;			      Reassembly started 23rd Feb 1987
;			      Reassembly attempted 13th Mar 1987
;			      Reassembly accomplished 16th April 1987
		
esc		equ	1bh			; Escape code
screen_seg	equ	0b800h			; Screen segment
screen_bottom	equ	80*24*2			; Bottom of screen

cseg		segment para public 'Code'

		org	100h			; COM file

		assume	cs:cseg,ds:cseg,es:cseg,ss:cseg

infocom		proc	near			; Here goes!

start:		jmp	begin


datname		db	'INFOGAME.DAT',0	; Name of the game datafile
		db	34h dup (0)

savname		db	'INFOGAME.SAV',0	; Saved game name
		db	34h dup (0)

sav2name	db	'xxxxxxxx.xxx',0	; Temp storage for save name
		db	33h dup (0)

pagesinfile	dw	0			;Number of pages in datafile
dathandle	dw	0			;Handle of datafile
savhandle	dw	0			;Handle of save file
datlen		dw	0			;Length of datafile	
l01d7		db	0
datdrive	db	0			;Drive of datafile
savdrive	db	0			;Drive of savfile
defdrvflg	db	0			;Flag for using default drive
sav2drive	db	0			;Old savfile drive 
def2drvflg	db	0			;Old savfile defdrvflg
dat2handle	dw	0			;Second datfile handle
nomoveptr	db	1
		db	0
readwrite	db	0			;0 = read, 1 = write

attrib		db	7			;Standard arrtibute: 
						; white on black
sbattrib	db	27h			;Status bar attribute

cursor_pos	dw	0			;Position of cursor

scrnlrx		db	80d			;Width of screen 
scrnlry		db	25d			;Height of screen
	
scp		db	3
		db	esc,'[s'		;Save cursor position

rcp		db	3
		db	esc,'[u'		;Restore cursor position

underbar	db	8
		db	esc,'[02;01H'		;Go to (1,2)

attroff		db	4
		db	esc,'[0m'		;All attributes off


ten		db	10			;Used for division by 10
nine		db	9			;Used for multiplication by 9


error		db	0			;Tells pchar not to script it
script		db	0			;Tells pchar to lprint it
noprinter	db	0			;No printer flag

noprint		db	' %Printer not ready: Abort or Retry? ',80h

pmflag		db	0			;1 if afternoon
barptr		dw	0			;Statbar pointer
barbuff		dw	0			;Statbar buffer

bartable	dw	smtxt40			;Table used in STATBAR
		dw	smdat40
		dw	smtxt80
		dw	smdat80
		dw	ttxt40
		dw	tdat40
		dw	ttxt80
		dw	tdat80

smtxt40:db	'                                        S:     M:      '
		db	0,80h
smdat40:	dw	0ffffh
		dw	pobj
		dw	1
		dw	19h
		dw	0ffffh
		dw	printnum
		dw	1ch
		dw	1eh
		dw	0ffffh
		dw	printnum
		dw	23h
		dw	28h

ttxt40:	db	'                                        Time:          '
		db	0,80h
tdat40:		dw	0ffffh
		dw	pobj
		dw	1
		dw	18h
		dw	0ffffh
		dw	phours
		dw	1fh
		dw	21h
		dw	0ffffh
		dw	pmins
		dw	22h
		dw	28h

smtxt80:	db	'                        '
		db	'                        '
		db	'                        '
		db	'                        '
		db	'              Score:    '
		db	'      Moves:       '
		db	0,80h
smdat80:	dw	0ffffh
		dw	pobj
		dw	1
		dw	1bh
		dw	0ffffh
		dw	printnum
		dw	39h
		dw	3dh
		dw	0ffffh
		dw	printnum
		dw	49h
		dw	50h

ttxt80:		db	'                        '
		db	'                        '
		db	'                        '
		db	'                        '
		db	'                        '
		db	'Time:             '
		db	0,80h
tdat80:		dw	0ffffh
		dw	pobj
		dw	1
		dw	1dh
		dw	0ffffh
		dw	phours
		dw	42h
		dw	44h
		dw	0ffffh
		dw	pmins
		dw	45h
		dw	50h

hourmin		dw	0			;System time: hours, minutes
sechund		dw	0			;System time: secs, hundredths

l04d4		dw	0
l04d6		dw	0
l04d8		dw	0
l04da		dw	0
l04dc		dw	0
l04de		dw	0
l04e0		dw	0
l04e2		dw	0			;Used in input parsing
l04e4		db	0			;Used in input parsing
l04e5		dw	0		
obufptr		dw	0
obufend		dw	0
l04eb		dw	0
l04ed		dw	0920h
		dw	0c0dh
		dw	2c2eh
		dw	003fh

scotim		dw	0
l04f7		dw	0
pagea		dw	0
pageb		dw	0
vocabptr	dw	0
orlptr		dw	0
gvarptr		dw	0
swrdptr		dw	0
l0505		dw	0
l0507		dw	0
l0509		dw	0
l050b		dw	0
l050d		dw	0

outbuff		db	51h dup (0)		;Output buffer

ibuff		db	0,0			;Input buffer
		db	4eh dup (0)

l05b0		db	0,0,0,0,0,0,0,0,0,0,0,0,0
		db	0,0,0,0,0,0,0,0,0,0,0,0,0
		db	0,0,0,0,0,0

freepages	dw	0			;Free memory in pages
datoffset	dw	0			;Datafile offset
keytoggle	db	0			;Some toggle in keyin	
l05d5		db	0feh,0,0,0
switches	db	0			;Slash switch bits
memory		dw	0			;Available memory
lvarptr		dw	0			;Local variable pointer
l05de		dw	0	
pc		dw	0			;Program counter
highaddrflg	db	0			;Upper segment flag
pcmoved		db	0			;Set to 1 if pc moved
l05e4		dw	0
l05e6		dw	0
l05e8		dw	0
l05ea		dw	0
l05ec		dw	0
paging2		dw	0
paging1		dw	0
l05f2		db	0
l05f3		dw	0
l05f5		dw	0
l05f7		dw	0
datbuf		dw	0
firstes		dw	0
extraes		dw	0
datofstflg	db	0
alldatin	db	0	;1 = not all data file loaded. Must page in.
l0601		db	0
l0603		db	0


;	0 parameter instructions

vectors0	dw	rettrue
		dw	retfalse
		dw	ilprint
		dw	ilprtcr
		dw	null
		dw	save
		dw	restore
		dw	restart
		dw	rettos
		dw	popnil
		dw	quit
		dw	newline
		dw	statbar
		dw	verify
		dw	0
		dw	0


;	1 parameter instructions

vectors1	dw	cpzero
		dw	getwith
		dw	getholds
		dw	getloc
		dw	getplen
		dw	inc
		dw	dec
		dw	print
		dw	0
		dw	delete
		dw	pobj
		dw	return
		dw	jump
		dw	print2
		dw	ldvarvar
		dw	not


;	2 parameter instructions

vectors2	dw	0
		dw	l16be
		dw	ltoe
		dw	gtoe
		dw	decchk
		dw	incchk
		dw	chkloc
		dw	bit
		dw	or
		dw	and
		dw	bitchk
		dw	biton
		dw	bitoff
		dw	ldvar
		dw	transfer
		dw	get16
		dw	get8
		dw	getprop
		dw	getpaddr
		dw	getnprop
		dw	add
		dw	sub
		dw	mult
		dw	div
		dw	mod
		dw	0
		dw	0
		dw	0
		dw	0
		dw	0
		dw	0
		dw	0
		dw	call
		dw	put16
		dw	put8
		dw	putprop
		dw	input
		dw	printchar
		dw	printnum
		dw	random
		dw	push
		dw	pop
		dw	l11ca
		dw	l119b
		dw	0
		dw	0
		dw	0
		dw	0
		dw	0
		dw	0
		dw	0
		dw	0
		dw	0
		dw	0
		dw	0
		dw	0
		dw	0
		dw	0
		dw	0
		dw	0
		dw	0
		dw	0
		dw	0
		dw	0


x0y1		dw	100h			;Top lhs of screen

more		db	0dh
		db	'( More ) ',80h

spaces9		db	0dh			;Print this to erase "more"
		db	'         ',0dh,80h

linecount	dw	0			;Count of number of lines
						; since last 'more' or input

version		db	'** New Infocom Interpreter v0.0 **',0

instsave	db	'Insert save disk then enter file name.',0
defaultis	db	'(Default is ',80h
brackets	db	'): ',80h
insdat		db	'Insert game disk then strike any key to continue.',0
savnf		db	'SAVE file not found',0
badfname	db	'Bad file name syntax',0
noaccess	db	'Unable to access file',0
noroom		db	'No room on diskette for SAVE file',0
savnr		db	'Read of SAVE file failed',0
words		db	'Too many words typed, flushing: ',80h
nsprop		db	'No such property',0
wrngver		db	'Wrong game or version',0
illegop		db	'Illegal operation',0
datnr		db	'Game file read error',0
datnf		db	'Game file not found',0
dosver		db	'Wrong DOS version.  Must be 2.0 or higher',0
nomemory	db	'Insufficient memory to play game',0
fatal		db	'Fatal error: ',80h

asciicodes	db	'abcdefghijklmnopqrstuvwxyz'
		db	'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
  		db	'  0123456789.,!?_#''"/\-:()'

	db	400h dup (0)		; Stack
stack	dw	0

	db	3feh dup (0)

begin:	mov	sp,offset stack		;Start of the executor
	mov	di,offset begin
	jmp	begin2

l119b:	mov	l0601,al
	test	al,al
	jz	restcurs
	call	setcurs
	mov	bx,offset underbar
	call	ansii
	ret

restcurs:
	call	rstrcurs
	mov	bx,offset attroff
	call	ansii
	ret

l11ca:	xor	ah,ah
	cmp	al,0
	jnz	l11e5
	mov	l0603,0
	mov	x0y1,100h
	mov	linecount,0
	call	rstrcurs
	ret

l11e5:	mov	l0603,1
	cmp	al,scrnlry
	jng	l11f5
	mov	al,scrnlry
	dec	al
l11f5:	xchg	ah,al
	add	x0y1,ax
	push	ax
	call	setcurs
	mov	bh,attrib
	pop	ax
	mov	dh,ah
	mov	ah,6				;Scroll window up
	mov	al,0
	mov	cx,offset start
	mov	dl,scrnlrx
	dec	dl
	int	10h
	call	rstrcurs
	ret

setcurs:mov	bx,offset scp			;Save the cursor position
	call	ansii
	ret

rstrcurs:
	mov	bx,offset rcp			;Restore the cursor posn
	call	ansii
	ret

;-------------------- V E R I F Y --------------------

verify:	call	clopdat				;(V) Verifies game file
	push	ax
	mov	ax,offset version
	call	pmsg
	pop	ax

	push	si
	push	di
	push	cx
	push	ds
	mov	bx,dathandle
	mov	si,firstes
	mov	ds,si
	mov	cx,0
	mov	dx,40h			;Start off at byte 40
	mov	al,0			;From the front
	mov	ah,42h			;Move file pointer
	int	21h
	mov	cx,4000h-40h	
	mov	dx,0c000h
	mov	ah,3fh			;Read file
	int	21h
	cmp	ax,cx			;Did we get the full 3fc0 bytes?
	jnz	datfail
	xor	dx,dx			;Clear crc
	call	crc			;Do a crc on the ax bytes at c000h
verifylp:
	mov	di,dx
	mov	dx,0c000h
	mov	cx,4000h		;Read in another 4000
	mov	ah,3fh			;Read file
	int	21h
	cmp	ax,cx			;Did we get all the 16k in?
	jnz	notall
	mov	dx,di			;Get back the crc
	call	crc
	jmp	short verifylp

notall:	mov	ax,es:[1ah]		;Get the amount to verify
	xchg	ah,al
	mov	dx,0
	mov	cx,2000h
	div	cx			;Work out the number of 16k blocks
					; we should have done
	shl	dx,1			;dx is the remainder
	mov	ax,dx
	mov	dx,di
	call	crc			;Crc those last bytes
	push	dx
	mov	cx,0			;Move file pointer to c000
	mov	dx,0c000h
	mov	ah,42H			;Move file pointer
	mov	al,0			;From front
	int	21h
	mov	dx,0c000h
	mov	cx,4000h		;Read 16k
	mov	ah,3fh
	int	21h
	pop	dx
	pop	ds
	pop	cx
	pop	di
	pop	si
	mov	ax,es:[1ch]
	xchg	ah,al

	cmp	ax,dx			; Compate the checksums
	jz	jtrue
	jmp	false

jtrue:	jmp	true


crc:	mov	cx,ax			; Put length in cx
	xor	ax,ax
	mov	si,0c000h
crclp:	lodsb
	add	dx,ax			; Do the crc
	loop	crclp
	ret

datfail:call	scroll
	mov	ax,offset fatal		; "Fatal error: "
	call	pmsg
	mov	ax,offset datnr		; "Game file read error"
	call	pmsg
	jmp	endgame

;-------------------- S A V E  /  R E S T O R E --------------------

restore:mov	readwrite,0	;(V) Restores game
	jmp	short saverest
	nop

save:	mov	readwrite,1	;(V) Saves game
saverest:
	push	ax
	mov	ax,offset instsave	;"Insert save disk ..."
	call	pmsg
	pop	ax
	push	ax
	mov	ax,offset defaultis	;"Default is ..."
	call	pmsg
	pop	ax
	test	defdrvflg,1	;Check that we don't need to
					; print drivename
	jnz	savdef

	mov	al,savdrive	;We need to print up drivename
	add	al,'A'
	call	mspchar
	mov	al,':'
	call	mspchar

savdef:	push	si			;Print the save-file-name
	mov	si,offset savname
	mov	cx,si
	cld
psavname:
	lodsb
	test	al,al
	jz	savprtd
	call	mspchar
	jmp	short psavname

savprtd:sub	si,cx			;We've printed save name,
	mov	cx,si			; now close the brackets
	pop	si
	push	ax
	mov	ax,offset brackets
	call	pmsg
	pop	ax
	cmp	scrnlrx,32h		;If screen is less than 50 chars
	jg	widescrn		; take a new line
	call	scroll
widescrn:
	mov	bx,offset ibuff
	mov	al,63			;Input buffer length = 63 characters
	mov	[bx],al
	mov	dx,bx
	call	cursor_on
	mov	ah,0ah			;Buffered input
	int	21h
	call	cursor_off
	mov	cursor_pos,screen_bottom
	call	savsav2			;Copy sav pointers into sav2 pointers
	push	si
	push	di
	push	cx
	push	es
	push	ds
	pop	es
	lea	si,ibuff+1		;Get length of input typed
	lodsb
	test	al,al
user:	jz	typedcr
	mov	cl,al
	xor	ch,ch
	mov	di,offset savname
	rep movsb
	mov	al,0
	stosb

typedcr:test	noprinter,1
	jz	l13f4
	call	lpsavname
l13f4:	mov	si,offset savname
	inc	si
	lodsb
	cmp	al,':'	;3ah		;Check to see if there is a drivename
	jnz	nodrive
	mov	defdrvflg,1
	mov	al,savname
	and	al,5fh			;Simple upper case conversion
	sub	al,'A'
	cmp	al,savdrive	;Was it the same as the .sav default?
	jz	defaultset
	mov	dl,al
	mov	ah,0eh			;Set default disk drive
	int	21h
	mov	ah,19h			;Get default disk drive
	int	21h
	mov	savdrive,al	;Store it
	jmp	short defaultset
	nop

	mov	l01d7,1			;Is this some sort of debugging?

nodrive:mov	defdrvflg,0
defaultset:
	pop	es
	pop	cx
	pop	di
	pop	si
	call	scroll
	cmp	readwrite,1
	jz	createsav
	mov	dx,offset savname
	mov	ah,3dh			;Open file
	mov	al,0			;Read access only
	int	21h
	jb	savnotfnd
	jmp	short savok
	nop

savnotfnd:
	mov	ax,offset savnf		;"Game file not found"
	jmp	saverror

createsav:
	mov	dx,offset savname
	mov	cx,0
	mov	ah,3ch			;Create or truncate file
	int	21h
	jb	savenoaccess
	jmp	short savok
	nop

savenoaccess:
	mov	ax,offset noaccess	;"No access"
	jmp	saverror

savok:	xchg	di,sp
	push	l05de
	push	pc
	push	lvarptr
	push	l04f7
	sub	sp,offset stack
	mov	stack,sp
	mov	sp,di
	mov	savhandle,ax
	push	es
	mov	ax,ss
	mov	es,ax
	mov	dx,offset stack
	mov	cx,400h
	mov	bx,savhandle
	mov	ah,3fh	;read file
	add	ah,readwrite		;If writing, adds 1 to make
						; fn 40, ie write file
	int	21h
	cmp	ax,400h
	pushf
	mov	di,sp
	mov	sp,stack
	add	sp,offset stack
	pop	ax
	cmp	ax,l04f7
	jz	l14c2
	mov	error,0
	call	scroll
	mov	ax,offset fatal
	call	pmsg
	mov	ax,offset wrngver		;"Wrong game or version"
	call	pmsg
	jmp	endgame

l14c2:	pop	lvarptr
	pop	pc
	pop	l05de
	xchg	di,sp
	popf
	pop	es
	jnz	l14f0
	mov	cx,es:[0eh]
	xchg	ch,cl
	mov	ah,3fh
	add	ah,readwrite
	mov	bx,savhandle
	mov	dx,0
	push	ds
	push	es
	pop	ds
	int	21h
	pop	ds
	cmp	ax,cx
l14f0:	pushf
	mov	ah,3eh
	mov	bx,savhandle
	int	21h
	popf
	jnz	l151e
	mov	ah,noprinter
	xor	al,al
	mov	es:[10h],ax
allin2:	call	checkpc
	jmp	true

l151e:	mov	ax,offset savnr
	cmp	readwrite,1
	jnz	l153a
	mov	ah,3eh				;Close file
	mov	bx,savhandle
	int	21h
	mov	dx,offset savname
	mov	ah,41h				;Delete file
	int	21h
	mov	ax,offset noroom
l153a:	jmp	short saverror
	nop

saverror:
	call	pmsg
	call	sav2sav
allin3:	mov	al,noprinter
	xchg	ah,al
	xor	al,al
	mov	es:[10h],ax
	jmp	false

lpsavname:
	push	ax
	push	si
	push	dx
	mov	si,offset savname
l1561:	lodsb
	test	al,al
	jnz	lpsavchar
	pop	dx
	pop	si
	pop	ax
	ret

lpsavchar:
	mov	dl,al
	mov	ah,5
	int	21h
	jmp	short l1561

savsav2:push	di			;Copy sav pointers into sav2 pointers
	push	si
	push	ax
	push	es
	mov	ax,ds
	mov	es,ax
	mov	al,savdrive
	mov	sav2drive,al
	mov	al,defdrvflg
	mov	def2drvflg,al
	mov	si,offset savname
	mov	di,offset sav2name
copyback:
	lodsb
	stosb
	test	al,al
	jnz	copyback
	pop	es
	pop	ax
	pop	si
	pop	di
	ret

sav2sav:push	di
	push	si
	push	ax
	push	es
	mov	ax,ds
	mov	es,ax
	mov	al,def2drvflg
	mov	defdrvflg,al
	mov	al,sav2drive
	cmp	al,savdrive
	jz	nochngdrv
	mov	dl,al
	mov	ah,0eh
	int	21h
	mov	savdrive,dl
nochngdrv:
	mov	di,offset savname
	mov	si,offset sav2name
copyback1:
	lodsb
	stosb
	test	al,al
	jnz	copyback1
	pop	es
	pop	ax
	pop	si
	pop	di
	ret

;-------------------- R E S T A R T -------------------

restart:mov	bp,obufptr	;(V) Restarts adventure
	mov	byte ptr ds:[bp],0
	push	ax
	mov	ax,offset outbuff	;Print out the buffer
	call	pmsg
	pop	ax
	jmp	startgame

;-------------------- Q U I T --------------------

quit:	jmp	endgame			;(V) Quits adventure

;-------------------- S T A T B A R --------------------

statbar:push	di			;(V) puts the status bar on the screen
	push	obufptr
	mov	bx,barptr
	mov	obufptr,bx
	mov	ax,10h
	mov	di,barbuff		;Buffer for status bar text and other
					; information
	mov	cx,3
l15ff:	push	ax
	call	getvar
	mov	dx,4[di]
	call	skipdx			;Move output buffer pointer dx places
	push	cx
	push	di
	call	2[di]
	pop	di
	mov	dx,6[di]
	call	l1639
	add	di,8
	pop	cx
	pop	ax
	inc	ax
	loop	l15ff
	mov	ax,24h			;Put a dollar sign on the end
					; of the output buffer for MS-DOS
	call	pchar
	call	printbar
	pop	obufptr
	pop	di
	ret

skipdx:	mov	bx,barptr	;Move obufptr dx places
	mov	obufptr,bx
	add	obufptr,dx
	ret

l1639:	mov	cx,obufptr
	sub	cx,barptr
	sub	dx,cx
	mov	cx,dx
	jng	l164f
l1647:	mov	ax,0020h
	call	pchar
	loop	l1647
l164f:	ret

;------------------- A D D -------------------

add:	add	ax,bx			;(V) Adds param1 and param2
	jmp	pvarbyte

;------------------- S U B -------------------

sub:	sub	ax,bx			;(V) Subtracts param2 from param1
	jmp	pvarbyte

;------------------- M U L T --------------------

mult:	imul	bx			;(V) Multiplies param1 by param2
	jmp	pvarbyte

;------------------- D I V -------------------

div:	cwd				;(V) Divides param1 by param2
	idiv	bx
	jmp	pvarbyte

;------------------- M O D -------------------

mod:	cwd				;(V) Returns param1 mod param2
	idiv	bx
	mov	ax,dx
	jmp	pvarbyte

;------------------- R A N D O M --------------------

random:	sub	ah,ah			;(V) Returns a random number
	mov	l04d4,ax
	mov	ax,hourmin
	mov	bx,sechund
	mov	sechund,ax
	clc
	rcr	ax,1
	rcr	bx,1
	xor	hourmin,bx
	mov	ax,hourmin
	and	ax,0efffh
	sub	dx,dx
	div	l04d4
	mov	ax,dx
	inc	ax
	jmp	pvarbyte

;-------------------- L T O E --------------------

ltoe:	cmp	ax,bx			;(V) param1 <= param2 ?
	jnge	jmptrue2
jmpfalse2:
	jmp	false
jmptrue2:
	jmp	true

;-------------------- G T O E --------------------

gtoe:	cmp	ax,bx			;(V) param1 >= param2 ?
	jg	jmptrue2
	jmp	short jmpfalse2

;-------------------- B I T -------------------

bit:	not	ax			;(V) check if bits on in param1
	and	bx,ax			; are on in param2	
	jz	jmptrue2
	jmp	short jmpfalse2

;-------------------- O R --------------------

or:	or	ax,bx			;(V) ors param1 & param2
	jmp	pvarbyte

;-------------------- N O T -------------------

not:	not	ax			;(V) nots param1 & param2
	jmp	pvarbyte

;-------------------- A N D -------------------

and:	and	ax,bx
	jmp	pvarbyte

;-------------------- ? ? ? -------------------

l16be:	nop
	mov	bx,l05e4
	cmp	bx,l05e6
	jz	l16df
	cmp	ax,3
	jnge	l16e2
	cmp	bx,l05e8
	jz	l16df
	cmp	ax,4
	jnge	l16e2
	cmp	bx,l05ea
	jnz	l16e2
l16df:	jmp	true

l16e2:	jmp	false

;-------------------- C P Z E R O -------------------

cpzero:	cmp	ax,0			;(V) see if param1 is zero
	jnz	false1
	jmp	true

false1:	jmp	false

;-------------------- T R A N S F E R --------------------

transfer:
	push	ax			;(V) transfer object param1 into param2
	push	bx
	call	delete			;Delete the object from the orlist
	pop	dx
	mov	ax,dx
	call	compadd
	mov	bx,ax			;bx points to new location (param2)
	pop	cx
	mov	ax,cx
	call	compadd
	mov	bp,ax			;bp points to object (param1)
	mov	es:4[bp],dl	;Make location of object = param2
	mov	dh,es:6[bx]	;Get holds of location
					; (first obj in row)
	mov	es:6[bx],cl	;Put holds of location = new object
	cmp	dh,0
	jz	transx
	mov	es:5[bp],dh	;If other objects in row,
					; make with link point to them
transx:	ret

;------------------- D E L E T E -------------------

delete:	mov	cx,ax			;(V) deletes the object in param1
	call	compadd
	mov	bx,ax
	mov	ch,es:4[bx]		;Get location of object
	cmp	ch,0			;Is it already deleted?
	jz	delexit
	mov	al,ch
	call	compadd
	mov	bp,ax			;bp points to location
	mov	dl,es:6[bp]		;Now get holds of location
	cmp	dl,cl			;Are we the first in the row?
	jnz	dellp
	mov	al,es:5[bx]		;Make holds of loc = with of object
	mov	es:6[bp],al
	jmp	short delsetz
	nop

dellp:	mov	al,dl			;Go from left to right until
	call	compadd			; we find preceeding object
	mov	bp,ax
	mov	dl,es:5[bp]
	cmp	dl,cl
	jnz	dellp			;Found it?
	mov	al,es:5[bx]		;Make link of previous obj
	mov	es:5[bp],al		; = link of object being deleted
delsetz:mov	byte ptr es:4[bx],0	;Set the location and with to nothing
	mov	byte ptr es:5[bx],0
delexit:ret

;-------------------- B I T C H K -------------------

bitchk:	call	compadd			;(V) checks statusbit p2 of object p1
	cmp	bx,10h
	jnge	chklt10			;If bit is in first word, jump
	sub	bx,10h			; else sub 10h and point to the
	inc	ax			; next word
	inc	ax
chklt10:mov	cx,bx			;Put bit number in cx
	mov	bx,ax			;Get the byte from memory
	mov	ax,es:[bx]
	xchg	ah,al			;It's back-to front of course...
	mov	dx,8000h		;High bit set
	shr	dx,cl			;Shift it right param2 times
	test	dx,ax			;Now test it with the word from memory
	jz	jfalse
	jmp	true

jfalse:	jmp	false

;-------------------- B I T O N -------------------

biton:	call	compadd			;(V) turns on statusbit p2 of object p1
	cmp	bx,10h
	jnge	onlt10
	sub	bx,10h
	inc	ax
	inc	ax
onlt10:	mov	cx,bx
	mov	bx,ax
	mov	ax,es:[bx]
	xchg	ah,al
	mov	dx,8000h
	shr	dx,cl
	or	ax,dx
	xchg	ah,al
	mov	es:[bx],ax
	ret

;-------------------- B I T O F F --------------------

bitoff:	call	compadd			;(V) turns off statusbit param2 of object param1
	cmp	bx,10h
	jnge	offlt10
	sub	bx,10h
	inc	ax
	inc	ax
offlt10:mov	cx,bx
	mov	bx,ax
	mov	ax,es:[bx]
	xchg	ah,al
	mov	dx,7fffh
	ror	dx,cl
	and	ax,dx
	xchg	ah,al
	mov	es:[bx],ax
	ret

;-------------------- G E T L O C --------------------

getloc:	call	compadd			;(v) Returns location of object p1
	mov	bx,ax
	mov	al,es:4[bx]
	jmp	palvarbyte

;-------------------- G E T H O L D S --------------------

getholds:
	call	compadd			;(v) returns holds of object param1
	mov	bx,ax
	mov	al,es:6[bx]
	push	ax
	call	palvarbyte
	pop	ax
	cmp	al,0
	jz	jmpfalse1
jmptrue1:
	jmp	true
jmpfalse1:
	jmp	false

;-------------------- G E T W I T H --------------------

getwith:call	compadd			;(V) returns link of object param1
	mov	bx,ax
	mov	al,es:5[bx]
	push	ax
	call	palvarbyte
	pop	ax
	cmp	al,0
	jz	jmpfalse1
	jmp	short jmptrue1

;-------------------- C H K L O C --------------------

chkloc:	call	compadd			;(V) checks if location of p1 is p2
	xchg	ax,bx
	cmp	es:4[bx],al	;offset 4 is location
	jz	jmptrue1
	jmp	short jmpfalse1

;-------------------- G E T P R O P --------------------

getprop:mov	dx,bx			;(V) get property p2 of object p1
	call	compadd
	mov	bp,ax
	mov	bx,es:7[bp]	;Get property table address
	xchg	bh,bl
	mov	al,es:[bx]	;Get the first byte (length of object name/2)
	sub	ah,ah	;double it
	shl	ax,1
	add	bx,ax			;And skip that amount
	inc	bx			;And one more
	jmp	short gproplpe
	nop

gproplp:call	nextprop		;Skip to the next property
gproplpe:
	mov	al,es:[bx]	;Get the property number
	and	al,1fh			;Mask out prop len for the moment
	cmp	al,dl			;Is it the one we are looking for?
	jg	gproplp
	jnge	l1852
	mov	al,es:[bx]
	inc	bx
	and	al,0e0h			;Get the top three bits
	mov	cl,5
	shr	al,cl
	cmp	al,0
	jnz	l185b
	mov	al,es:[bx]
	jmp	palvarbyte

l1852:	dec	dx
	shl	dx,1
	mov	bx,dx
	add	bx,orlptr
l185b:	mov	ax,es:[bx]
	xchg	ah,al
	jmp	pvarbyte

putprop:push	cx
	mov	dx,bx
	call	compadd
	mov	bp,ax
	mov	bx,es:7[bp]
	xchg	bh,bl
	mov	al,es:[bx]
	sub	ah,ah
	shl	ax,1
	add	bx,ax
	inc	bx
	jmp	short l1881
	nop

l187e:	call	nextprop
l1881:	mov	al,es:[bx]
	and	al,1fh
	cmp	al,dl
	jz	l189e
	jg	l187e
	call	scroll
	mov	ax,offset fatal
	call	pmsg
	mov	ax,offset nsprop	;"No such property"
	call	pmsg
	jmp	endgame

l189e:	mov	al,es:[bx]
	inc	bx
	and	al,0e0h
	mov	cl,5
	shr	al,cl
	cmp	al,0
	pop	ax
	jnz	l18b1
	mov	es:[bx],al
	ret

l18b1:	xchg	ah,al
	mov	es:[bx],ax
	ret

;------------------- G E T N P R O P --------------------

getnprop:				;(V) gets the property after param2
	mov	dx,bx			; of object param1
	call	compadd
	mov	bp,ax
	mov	bx,es:7[bp]
	xchg	bh,bl
	mov	al,es:[bx]
	sub	ah,ah
	shl	ax,1
	add	bx,ax
	inc	bx
	cmp	dx,0
	jz	l18f9
	jmp	short l18d9
	nop

l18d6:	call	nextprop
l18d9:	mov	al,es:[bx]
	and	al,1fh
	cmp	al,dl
	jz	l18f6
	jg	l18d6
	call	scroll
	mov	ax,offset fatal
	call	pmsg
	mov	ax,offset nsprop	;"No such property"
	call	pmsg
	jmp	endgame

l18f6:	call	nextprop
l18f9:	mov	al,es:[bx]
	and	al,1fh
	jmp	pvarbyte

;------------------- G E T 1 6 -------------------

get16:	shl	bx,1			;(V) returns param2 entry
	add	ax,bx			; of a 2-byte entry table
	call	cnvtadd			; at base param1
	call	getword
	mov	ax,cx
	jmp	pvarbyte

;-------------------- G E T 8 --------------------

get8:	add	ax,bx			;(V) returns param2 entry 
	call	cnvtadd			; of a 1-byte entry table
	call	getbyte			; at base param1
	mov	ax,cx
	jmp	palvarbyte

;-------------------- P U T 1 6 --------------------

put16:	shl	bx,1			;(V) put param3 in param2 entry
	add	bx,ax			; of a 2-byte entry table
	xchg	ch,cl			; at base param1
	mov	es:[bx],cx
	ret

;-------------------- P U T 8 ---------------------

put8:	add	bx,ax			;(V) put param3 in param2 entry
	mov	es:[bx],cl	; of a 1-byte entry table
	ret				; at base param1

;-------------------- G E T P A D D R -------------------

getpaddr:
	mov	dx,bx			;(V) gets address of property
	call	compadd			;p2 of object p1
	mov	bp,ax
	mov	bx,es:7[bp]
	xchg	bh,bl
	mov	al,es:[bx]
	sub	ah,ah
	shl	ax,1
	add	bx,ax
	inc	bx
	jmp	short l194a
	nop

l1947:	call	nextprop
l194a:	mov	al,es:[bx]
	and	al,1fh
	cmp	al,dl
	jg	l1947
	jz	l195a
	sub	ax,ax
	jmp	short l195d
	nop

l195a:	inc	bx
	mov	ax,bx
l195d:	jmp	pvarbyte

;-------------------- G E T P L E N --------------------

getplen:mov	bx,ax			;(V) gets the length of the
 					; property pointed to by param1
	mov	al,es:-1[bx]
	and	al,0e0h
	sub	ah,ah
	mov	cl,5
	shr	ax,cl
	inc	ax
	jmp	pvarbyte

;-------------------- L D V A R V A R --------------------

ldvarvar:				;(V) Get var in param1 and put into
	call	getvar			; var defd by next byte
	jmp	pvarbyte

;-------------------- L D V A R --------------------

ldvar:	jmp	putvar			;(V) loads param2 into var defined
					; by param1

;-------------------- P U S H -------------------

push:	xchg	sp,di			;(V) Pushes param1 onto stack
	push	ax
	xchg	sp,di
	ret

;-------------------- P O P --------------------

pop:	xchg	sp,di			;(V) Pops off stack
	pop	bx
	xchg	sp,di
	jmp	putvar

;-------------------- I N C --------------------

inc:	mov	cx,ax			;(V) increment variable in param1
	call	getvar
	inc	ax
incdec:	mov	bx,ax
	mov	ax,cx
	jmp	putvar

;-------------------- D E C --------------------

dec:	mov	cx,ax			;(V) decrement variable in param1
	call	getvar
	dec	ax
	jmp	short incdec

;-------------------- I N C C H K --------------------

incchk:	push	ax			;(V) incs param1 & checks if >= param2
	call	getvar
	inc	ax
	sub	cx,cx			;Set cx = 0 (assume false)
	cmp	ax,bx
	jng	incfalse
inctrue:inc	cx			;If it is greater, return true
incfalse:
	mov	bx,ax
	pop	ax
	call	putvar			;Put the incremented variable back
	cmp	cx,0
	jz	jfalse2
	jmp	true

jfalse2:jmp	false

;-------------------- D E C C H K --------------------

decchk:	push	ax			;(V) decs param1 & checks if <= param2
	call	getvar
	dec	ax
	sub	cx,cx
	cmp	ax,bx
	jge	incfalse
	jmp	short inctrue


linein:	push	bx			;Get input from the user and
	mov	script,1		;lower-case-er-ise it
	push	si
	mov	cl,es:[si]
	mov	bx,offset ibuff		;Set bx to the input buffer
	mov	[bx],cl			;Look at the length
	cmp	cl,4eh			;If someone patches buffer
					; longer, make it 78 chars
	jna	ibuffok
	mov	byte ptr [bx],4eh	;78 characters long
ibuffok:call	cursor_on
	mov	dx,bx			;Input buffer now in dx
	mov	ah,0ah			;Buffered input
	int	21h
	call	cursor_off
	mov	cursor_pos,screen_bottom

	push	si
	push	di
	push	ds
	push	es

	cld					;Go forwards
	mov	ax,screen_seg
	mov	ds,ax				;Source is screen
	mov	es,ax				;Destination is screen
	mov	si,80*4				;Source is the third line
	mov	di,80*2				;Destination is the second
	mov	cx,80*23			;24-1=23 moves
	rep	movsw				;Scroll up

	mov	ah,cs:attrib			;Text attribute
	mov	al,' '				;Space
	mov	di,80*24*2			;Starting posn of bottom line
	mov	cx,80				;Width of bottom line
	rep	stosw				;Clear bottom line

	pop	es
	pop	ds
	pop	di
	pop	si

scrldone:
	pop	dx
	mov	bx,offset ibuff
	mov	cl,1[bx]		;Get the length in cl
	sub	ch,ch
	inc	bx
	cmp	cl,0
	jz	noinput
lcloop:	inc	si				;Lower case-er-ise it
	inc	bx
	mov	al,[bx]
	cmp	al,'A'
	jnge	notalpha
	cmp	al,'Z'
	jg	notalpha
	add	al,' '				;Lower case-er-ise it
notalpha:
	mov	es:[si],al		;And move it to buffer at si
	loop	lcloop
noinput:inc	si
	sub	al,al
	mov	es:[si],al
	mov	script,0
	pop	bx
	ret

cursor_on:				;Turn on the flashing cursor
	push	ax
	push	bx
	push	dx
	mov	dx,cursor_pos		;Get the cursor posn
	sub	dx,screen_bottom	;Get column of cursor*2
	shr	dl,1			;Divide by two
	mov	dh,24			;Bottom line always
	mov	bh,0			;Page zero
	mov	ah,2			;Move cursor
	int	10h
	pop	dx
	pop	bx
	pop	ax
	ret

cursor_off:				;Turn off the flashing cursor
	push	ax
	push	bx
	push	dx
	mov	ah,2
	mov	bh,0			;Page zero
	mov	dh,25			;Line 25
	mov	dl,0			;Column zero
	int	10h
	pop	dx
	pop	bx
	pop	ax
	ret

lpchar:	push	ax
	push	bx
	push	cx
	push	dx
retry:	mov	ah,0			;Output the character to printer
	mov	dx,0			;Printer number zero
	int	17h
	test	ah,1
	jz	lpok
	call	abrtrtry
	jb	lpok
	jmp	short retry

lpok:	pop	dx
	pop	cx
	pop	bx
	pop	ax
	ret

abrtrtry:
	push	ax
	mov	script,1
	push	ax
	mov	ax,offset noprint
	call	pmsg
	pop	ax
abtrtylp:
	call	keyin
	call	mspchar
	and	al,5fh
	cmp	al,'A'
	jnz	nota
	mov	noprinter,0
	and	es:[10h],0feffh			;Turns off script
	mov	script,0
	stc
	pushf
	jmp	short abrtrtryx
	nop

nota:	cmp	al,'R'
	jnz	abtrtylp
	clc
	pushf
abrtrtryx:
	call	scroll
	mov	script,0
	popf
	pop	ax
	ret

l1aad:	push	ax
	push	bx
	push	dx
	mov	ax,es:[10h]
	xchg	ah,al
	test	al,1
	jz	l1b0f
	test	noprinter,1
	jnz	l1ae8
	mov	noprinter,1
l1ad4:	mov	dx,0
	mov	ah,1
	int	17h
	test	ah,0a1h
	jz	l1ae8
	call	abrtrtry
	jnb	l1ad4
	jmp	short l1b0f
	nop

l1ae8:	sub	cx,cx
	mov	bp,dx
	inc	bp
l1aed:	mov	al,es:[bp]
	inc	bp
	cmp	bp,si
	jng	l1afc
	call	lpcrlf
	jmp	short l1b14
	nop

l1afc:	call	lpchar
	inc	cx
	cmp	cl,scrnlrx
	jnz	l1aed
	call	lpcrlf
	jb	l1b14
	sub	cx,cx
	jmp	short l1aed

l1b0f:	mov	noprinter,0
l1b14:	pop	dx
	pop	bx
	pop	ax
	ret

lpcrlf:	mov	al,0dh				;Lprint a crlf
	call	lpchar
	mov	al,0ah
	call	lpchar
	ret

;-------------------- I N P U T --------------------

input:	push	ax				;(V) get command from the user
	push	ax
	push	bx
	call	statbar				;Put up the status bar
	pop	bx
	pop	ax
	mov	bp,obufptr		;Put a cr marker on the end of the
	mov	ds:byte ptr [bp],80h	; the output buffer
	push	ax
	mov	ax,offset outbuff		;Print the output buffer
	call	pmsg
	pop	ax
	mov	obufptr,offset outbuff
	pop	si
	mov	linecount,0
	call	linein				;Get the input from the user
	call	l1aad
	push	di
	mov	l04de,dx
	mov	l04e0,si
	mov	l04e2,bx
	mov	l04e4,0
	inc	dx
	mov	di,bx
	inc	di
	inc	di
l1b66:	mov	cx,offset l04d6
	mov	bx,dx
l1b6b:	cmp	dx,l04e0
	jnz	l1b7a
	cmp	cx,offset l04d6
	jnz	l1bc2
	jmp	l1cab


l1b7a:	mov	bp,dx
	mov	al,es:[bp]
	cmp	al,'A'
	jnge	l1b8a
	cmp	al,'Z'
	jg	l1b8a
	add	al,' '
l1b8a:	inc	dx
	mov	si,offset l05b0
l1b8e:	inc	si
	cmp	al,-1[si]
	jz	l1ba8
	cmp	byte ptr [si],0
	jnz	l1b8e
	cmp	cx,offset l04dc
	jz	l1b6b
	mov	bp,cx
	mov	ds: [bp],al
	inc	cx
	jmp	short l1b6b

l1ba8:	cmp	cx,offset l04d6
	jnz	l1bc1
	cmp	si,l0507
	jna	l1bb7
	inc	bx
	jmp	short l1b6b

l1bb7:	mov	bp,cx
	mov	ds:[bp],al
	inc	cx
	jmp	short l1bc2
	nop

l1bc1:	dec	dx
l1bc2:	inc	l04e4
	mov	bp,bx
	mov	bx,l04e2
	mov	bl,es:[bx]
	cmp	bl,3bh
	jna	l1bd6
	mov	bl,3bh
l1bd6:	cmp	l04e4,bl
	mov	bx,bp
	jng	l1c13
	push	ax
	mov	ax,offset words			;"Too many words. Flushing:" 
	call	pmsg
	pop	ax
	mov	ax,bx
	mov	bp,l04e0
	mov	bl,es:[bp]
	mov	byte ptr es:[bp],0
	push	bx
	mov	bx,ds
	neg	bx
	add	bx,firstes
	mov	cl,4
	shl	bx,cl
	add	ax,bx
	pop	bx
	call	pmsg
	mov	es:[bp],bl
	dec	l04e4
	jmp	l1cab

l1c13:	mov	ax,bx
	neg	ax
	add	ax,dx
	mov	es:2[di],al
	sub	bx,l04de
	mov	es:3[di],bl
	mov	bp,cx
	mov	ds:byte ptr [bp],0
	mov	ax,offset l04d6
	call	l2143
	push	dx
	push	di
	mov	di,ax
	mov	si,l050b
	mov	ax,si
	dec	ax
	mul	l0509
	add	ax,l050d
	mov	cx,ax
	mov	dx,di
	mov	di,bx
	mov	bx,l0509
	sar	si,1
l1c51:	shl	bx,1
	sar	si,1
	cmp	si,0
	jnz	l1c51
	mov	si,l050d
	add	si,bx
	push	ax
	mov	ax,l0509
	sub	si,ax
	pop	ax
l1c67:	sar	bx,1
	mov	ax,es:[si]
	xchg	ah,al
	cmp	dx,ax
	ja	l1c87
	jb	l1c92
	mov	bp,si
	inc	bp
	inc	bp
	mov	ax,es:[bp]
	xchg	ah,al
	cmp	di,ax
	ja	l1c87
	jb	l1c92
	jmp	short l1c9c
	nop

l1c87:	add	si,bx
	cmp	si,cx
	jna	l1c94
	mov	si,cx
	jmp	short l1c94
	nop

l1c92:	sub	si,bx
l1c94:	cmp	bx,l0509
	jge	l1c67
	sub	si,si
l1c9c:	pop	di
	mov	dx,si
	xchg	dh,dl
	mov	es:[di],dx
	pop	dx
	add	di,4
	jmp	l1b66

l1cab:	inc	l04e2
	mov	bp,l04e2
	mov	dl,l04e4
	mov	es:[bp],dl
	pop	di
	ret

;-------------------- P R I N T C H A R --------------------

printchar:
	jmp	pchar			;(V) print the character in p1

;-------------------- P R I N T N U M --------------------

printnum:	mov	bx,ax		;(V) print the num p1 in dec
	cmp	bx,0
	jnz	pnot0
	mov	ax,30h			;If zero, then print "0"
	jmp	pchar

pnot0:	jg	pnplus
	mov	ax,2dh			;If negative, print a minus sign
	call	pchar
	neg	bx			;and negate the number
pnplus:	sub	cx,cx
	jmp	short l1ce8
	nop

nextdig:mov	ax,bx			;Keep dividing by 10 until remainder
	mov	bp,10d			;is less than 10
	cwd
	idiv	bp
	push	dx
	inc	cx
	mov	bx,ax
l1ce8:	cmp	bx,10
	jge	nextdig
	mov	ax,bx
	jmp	short pnprt
	nop

pnlp:	pop	ax			;Keep popping off the answers from the
pnprt:	add	ax,'0'			; stack
	call	pchar
	dec	cx
	jge	pnlp
	ret

;-------------------- P R I N T 2 --------------------

print2:	call	cnvtadd2		;(V) prints message at address param1*2
	jmp	pcode

;-------------------- P R I N T --------------------

print:	call	cnvtadd			;(V) prints the message at param1
	jmp	pcode


phours:	mov	pmflag,0	;Prints the ax in hours format
	cmp	al,0ch
	jnge	am
	mov	pmflag,1
am:	cmp	al,0ch
	jng	before1pm
	sub	al,0ch
before1pm:	cmp	al,0
	jnz	l1d23
	mov	al,0ch
l1d23:	cmp	al,9
	jg	nospace
	push	ax
	mov	al,' '			;Leading space for numbers less than 9
	call	pchar
	pop	ax
nospace:call	printnum
	mov	al,':'	;3ah		;The colon after the hours
	jmp	pchar

pmins:	cmp	al,9			;Prints al as minutes with an am or pm
	jg	nolead0
	push	ax
	mov	al,'0'			;Leading zero for numbers less than 9
	call	pchar
	pop	ax
nolead0:call	printnum
	mov	al,' '
	call	pchar
	mov	al,'a'
	cmp	pmflag,0
	jz	printm
	mov	al,'p'
printm:	call	pchar
	mov	al,'m'
	jmp	pchar

;-------------------- P O B J --------------------

pobj:	call	compadd			;(V) prints the name of the object in 
	add	ax,7			; param1
	mov	bp,ax
	mov	ax,es:[bp]
	xchg	ah,al			;Turn around property address
	inc	ax			;Skip over the proplen/propnum byte
	call	cnvtadd
	jmp	pcode

;-------------------- I L P R I N T --------------------

ilprint:mov	ax,l05de	;(V) inline print. prints the message
	mov	bx,pc		; following instruction
	call	pcode
	mov	l05de,ax
	mov	pc,bx
	jmp	checkpc

;-------------------- I L P R I N T R E T --------------------

ilprtcr:call	ilprint			;(V) inline print and returns from
	call	newline			; subroutine
	jmp	rettrue

;-------------------- N E W L I N E --------------------

newline:jmp	crlf		;(V) prints a carriage return

;-------------------- C A L L --------------------

call:	nop
	mov	dx,ax
	mov	ax,l05e4
	cmp	ax,0
	jnz	l1da1
	sub	ax,ax
	jmp	pvarbyte

l1da1:	xchg	sp,di
	push	l05de
	xchg	sp,di
	xchg	sp,di
	push	pc
	xchg	sp,di
	mov	cx,lvarptr
	xchg	sp,di
	push	cx
	xchg	sp,di
	call	cnvtadd2
	mov	l05de,ax
	mov	pc,bx
	call	checkpc
	mov	lvarptr,di
	sub	lvarptr,2
	call	l1ea4
	mov	bx,ax
	mov	bp,offset l05e6
l1dd8:	dec	bx
	jnge	callx
	call	l1ee4
	dec	dx
	jng	l1ded
	xchg	sp,di
	push	[bp]
	xchg	sp,di
	add	bp,2
	jmp	short l1dd8

l1ded:	xchg	sp,di
	push	ax
	xchg	sp,di
	jmp	short l1dd8

callx:	ret

;-------------------- R E T U R N --------------------

return:	mov	di,lvarptr	;(V) Return from subroutine.
	xchg	sp,di
	pop	dx
	xchg	sp,di
	xchg	sp,di
	pop	lvarptr
	xchg	sp,di
	xchg	sp,di
	pop	pc
	xchg	sp,di
	xchg	sp,di
	pop	l05de
	xchg	sp,di
	push	ax
	call	checkpc
	pop	ax
	jmp	pvarbyte

;-------------------- R E T T R U E --------------------

rettrue:mov	ax,1			;(V) Returns a true to calling routine
	jmp	short return

;-------------------- R E T F A L S E --------------------

retfalse:
	sub	ax,ax			;(V) Returns a false to calling routine
	jmp	short return

;-------------------- J U M P --------------------

jump:	add	pc,ax		;(V) Relative jump by param1
	sub	pc,2
	jmp	checkpc

;-------------------- R E T T O S --------------------

rettos:	xchg	sp,di			;(V) Returns top of stack to the
	pop	ax			; calling routine
	xchg	sp,di
	jmp	short return

;-------------------- P O P N I L --------------------

popnil:	xchg	sp,di			;(V) Pops a value off stack & discards
	pop	dx			; it
	xchg	sp,di
	ret

;-------------------- N U L L --------------------

null:	ret				;(V) Null instruction

;-------------------- G E T B Y T E --------------------

getbyte:push	si			;Get byte (page ax, byte bx) into cl
	push	ax			;A page is 200h long
	cmp	ax,80h			;100h pages at 200h each = 20000h
					; therefore need two segs
	jl	infirstseg		;Pages 0 to 79 are in first seg

	mov	si,extraes		;80 through 0ffh are in second
	mov	es,si
infirstseg:
	mov	cl,9			;Multiply page number by 200h
	shl	ax,cl			;The high bit of page # will disappear
	or	ax,bx			;Put in the byte offset
	xchg	ax,bx
	mov	cl,es:[bx]		;Get the byte
	sub	ch,ch			;Zero the top byte
	mov	bx,ax
	mov	si,firstes		;Always keep es pointing to first seg
	mov	es,si
	pop	ax
	pop	si
	inc	bx			;Increment byte in page
	cmp	bx,0200h		;Did we go across a page?
	jnz	nocross
	sub	bx,bx			;If so, set byte # to 0 and inc page #
	inc	ax
nocross:ret


;-------------------- G E T W O R D --------------------

getword:push	dx			;Get next word from page ax,
					; byte bx into cx
	call	getbyte			;Getbyte gets next byte into cl
	push	cx
	call	getbyte
	pop	dx
	mov	ch,dl
	pop	dx
	ret


;

l1ea4:	push	si
	push	bx
	test	pcmoved,1
	jz	l1eb0
	call	checkpc
l1eb0:	mov	bx,pc
	add	bx,l05ec
	cmp	highaddrflg,0
	jz	l1ec5
	mov	si,extraes
	mov	es,si
l1ec5:	mov	al,es:[bx]
	push	ax
	mov	si,firstes
	mov	es,si
	inc	pc
	cmp	pc,0200h
	jnge	l1ede
	call	checkpc
l1ede:	pop	ax
	sub	ah,ah
	pop	bx
	pop	si
	ret

l1ee4:	push	bx
	call	l1ea4
	push	ax
	call	l1ea4
	pop	bx
	mov	ah,bl
	pop	bx
	ret

l1ef1:	dec	ax
	jnge	l1ee4
	jz	l1ea4
	call	l1ea4
	cmp	ax,0
	jnz	getvar
	xchg	sp,di
	pop	ax
	xchg	sp,di
	ret


;-------------------- G E T V A R -------------------

getvar:	cmp	ax,0
	jnz	gnottos
	mov	ax,ss:[di]		;Variable zero is defined as tos
	ret

gnottos:push	bp
	cmp	ax,10h			;Variables over 10h are global
	jge	gglovar
	dec	ax			;Dec because zero is already used as
	shl	ax,1			; the tos
	mov	bp,lvarptr		;Return the variable in ax
	sub	bp,ax
	mov	ax,[bp]
getvarx:pop	bp
	ret

gglovar:sub	ax,10h
	shl	ax,1
	add	ax,gvarptr
	mov	bp,ax
	mov	ax,es:word ptr [bp]
	xchg	ah,al			;Global vars have to be stored 
					; backwards because they're saved
	jmp	short getvarx


;-------------------- P U T V A R --------------------

putvar:	cmp	ax,0			;(V) puts param2 (bx) into
					; varaible param1 (ax)
	jnz	pnottos
	mov	ss:[di],bx
	ret

pnottos:cmp	ax,10h
	jge	pglovar
	push	bp
	dec	ax
	shl	ax,1
	mov	bp,lvarptr
	sub	bp,ax
	mov	[bp],bx
	pop	bp
	ret

pglovar:sub	ax,10h
	shl	ax,1
	add	ax,gvarptr
	xchg	ax,bx
	xchg	ah,al
	mov	es:[bx],ax
	ret


;-------------------- P A L V A R B Y T E --------------------

palvarbyte:
	sub	ah,ah			;Put al in var defined by next byte
	jmp	short pvarbyte
	nop


;-------------------- P V A R B Y T E --------------------

pvarbyte:
	mov	bx,ax			;Put ax in var defined by next byte
	call	l1ea4
	cmp	ax,0
	jnz	putvar
	xchg	sp,di
	push	bx
	xchg	sp,di
	ret


;-------------------- F A L S E --------------------

false:	sub	bx,bx
	jmp	short rettf
	nop

;-------------------- T R U E --------------------

true:	mov	bx,1
	jmp	short rettf
	nop

rettf:	call	l1ea4
	test	ax,80h
	jz	l1f8a
	inc	bx
l1f8a:	test	ax,40h
	jz	l1f95
	and	ax,0ff3fh
	jmp	short l1fa7
	nop

l1f95:	and	ax,0ff3fh
	mov	cx,ax
	call	l1ea4
	mov	ah,cl
	test	ax,2000h
	jz	l1fa7
	or	ax,0c000h
l1fa7:	dec	bx
	jz	l1fc0
	cmp	ax,0
	jnz	l1fb2
	jmp	retfalse

l1fb2:	dec	ax
	jnz	l1fb8
	jmp	rettrue

l1fb8:	dec	ax
	add	pc,ax
	jmp	checkpc

l1fc0:	ret


;-------------------- C N V T A D D --------------------

cnvtadd:mov	bx,ax			;Convert address in ax to page
	xchg	al,ah			; and byte in ax,bx
	shr	ax,1
	and	ax,7fh
	and	bx,01ffh
	ret

cnvtadd2:
	mov	bx,ax			;Like cnvtadd, but address is halved
	mov	al,ah			; first
	sub	ah,ah
	sub	bh,bh
	shl	bx,1
	ret


;------------------- C O M P A D D --------------------

compadd:mul	nine			;Multiply object by 9
	add	ax,orlptr		;Add the orlist pointer
	add	ax,35h			;Add 35h (why not?)
	ret

;-------------------- N E X T P R O P --------------------

nextprop:
	push	ax			;Skip to the next property
	push	cx
	mov	al,es:[bx]
	and	al,0e0h			;Top three bits are the prop length-2
	mov	cl,5			;Shift it down 5 bits
	shr	al,cl
	sub	ah,ah
	add	bx,ax
	add	bx,2
	pop	cx
	pop	ax
	ret

;-------------------- P C O D E --------------------

pcode:	push	si			;Print encoded text
	push	cx
	push	dx
	push	di
	push	bp
	sub	dx,dx			;Mode zero
	sub	di,di
l200e:	call	getword
	mov	si,cx			;Put coded word in si
	push	ax
	push	bx
	push	si
	mov	cx,3			;We can get three chars from a word
pcodelp:push	si
	mov	bp,cx
	mov	cl,5			;Shift the top five bits
	sar	si,cl			; to the bottom
	mov	cx,bp
	loop	pcodelp
	mov	cx,3
l2027:	pop	si
	and	si,11111b		;Get the bottom 5 bits
	cmp	dx,0			;If mode is greater than zero,
	jge	notspwrd		; not special word mode
	shl	si,1
	add	si,swrdptr
	add	si,l04e5
	mov	ax,es:[si]
	xchg	ah,al
	call	cnvtadd2
	call	pcode
	jmp	l20da

notspwrd:					;Not a special word
	cmp	dx,3				;Check for mode 3
	jnge	digpunct
	jnz	l2057
	xchg	dl,dh
	or	dx,si
	jmp	l20dc

l2057:	and	dx,3
	mov	bp,cx
	mov	cl,5
	shl	dx,cl
	mov	cx,bp
	or	dx,si
	mov	ax,dx
	jmp	short pcodep
	nop

digpunct:				;Digit/punctuation
	cmp	si,6			;Digit 6 is make-character
	jnge	makechar
	cmp	dx,2
	jnz	lookup
	cmp	si,7			;Digit 7 is a cr
	jz	pcrlf
	jg	lookup
	inc	dx
	jmp	short l20dc
	nop

pcrlf:	call	crlf
	jmp	short l20da
	nop

lookup:	mov	ax,dx			;multiply mode by 26 and
	mov	bp,1ah			; add character code
	mul	bp
	add	ax,si
	sub	ax,6
	mov	bx,offset asciicodes
	xlat	al			;Lookup the character
	jmp	short pcodep
	nop

makechar:
	cmp	si,0
	jnz	l20a3
	mov	ax,20h
	jmp	short pcodep
	nop

l20a3:	cmp	si,3
	jg	l20bc
	or	dx,8000h
	dec	si
	mov	bp,cx
	mov	cl,6
	shl	si,cl
	mov	cx,bp
	mov	l04e5,si
	jmp	short l20dc
	nop

l20bc:	sub	si,3
	cmp	dx,0
	jnz	l20c9
	mov	dx,si
	jmp	short l20dc
	nop

l20c9:	cmp	si,dx
	jz	l20cf
	sub	dx,dx
l20cf:	mov	di,dx
	jmp	short l20dc
	nop

l20d4:	jmp	l2027

pcodep:	call	pchar			;Pcode print
l20da:	mov	dx,di
l20dc:	loop	l20d4
	pop	si
	pop	bx
	pop	ax
	cmp	si,0
	jnge	l20e9
	jmp	l200e

l20e9:	pop	bp
	pop	di
	pop	dx
	pop	cx
	pop	si
	ret

l20ef:	cmp	ax,0
	jnz	l20f8
	mov	ax,3
	ret

l20f8:	push	bx
	mov	bx,offset asciicodes
l20fc:	inc	bx
	cmp	al,-1[bx]
	jz	l210d
	cmp	byte ptr [bx],0
	jnz	l20fc
	mov	ax,2
	jmp	short l211b
	nop

l210d:	sub	bx,offset asciicodes
	sub	ax,ax
l2113:	sub	bx,1ah
	jng	l211b
	inc	ax
	jmp	short l2113

l211b:	pop	bx
	ret

l211d:	push	bx
	mov	bx,offset asciicodes
l2121:	inc	bx
	cmp	al,-1[bx]
	jz	l2131
	cmp	byte ptr [bx],0
	jnz	l2121
	sub	ax,ax
	jmp	short l2141
	nop

l2131:	sub	bx,offset asciicodes-5
	mov	ax,bx
l2137:	cmp	ax,20h
	jnge	l2141
	sub	ax,1ah
	jmp	short l2137

l2141:	pop	bx
	ret

l2143:	push	si
	push	cx
	push	dx
	push	di
	push	bp
	mov	si,ax
	sub	di,di
	mov	cx,6
l214f:	inc	si
	mov	bl,-1[si]
	cmp	bl,0
	jnz	l2161
	mov	ax,5
l215b:	push	ax
	loop	l215b
	jmp	short l219a
	nop

l2161:	mov	ax,bx
	call	l20ef
	cmp	ax,0
	jz	l2172
	add	ax,3
	push	ax
	dec	cx
	jz	l219a
l2172:	mov	ax,bx
	call	l211d
	cmp	ax,0
	jnz	l2197
	mov	ax,6
	push	ax
	dec	cx
	jz	l219a
	mov	ax,bx
	mov	bp,cx
	mov	cl,5
	sar	ax,cl
	mov	cx,bp
	push	ax
	dec	cx
	jz	l219a
	and	bx,1fh
	mov	ax,bx
l2197:	push	ax
	loop	l214f
l219a:	mov	bp,sp
	mov	ax,0ah[bp]
	mov	cl,5
	shl	ax,cl
	or	ax,8[bp]
	shl	ax,cl
	or	ax,6[bp]
	mov	bx,4[bp]
	shl	bx,cl
	or	bx,2[bp]
	shl	bx,cl
	or	bx,[bp]
	or	bx,8000h
	add	sp,0ch
	pop	bp
	pop	di
	pop	dx
	pop	cx
	pop	si
	ret

pchar:	push	bp			;Print character in al
	mov	bp,obufptr		;Can the buffer hold some more chars ?
	cmp	bp,obufend
	jnz	putinbuff		;Yes, so whack it in the buffer
	push	ax			;No, dump the buffer then whack it in
	push	bx
	push	si
	mov	bx,obufend		;Start at the end of the line
	mov	si,offset outbuff
findspace:
	dec	bx			;And go backwards
	cmp	byte ptr [bx],' '	;Util we find a space
	jz	gotspace
	cmp	bx,si			;Have we reached the
					; beginning of the buffer?
	jnz	findspace
nowrap:	push	ax
	mov	ax,offset outbuff	;Print the whole buffer
					; - impossible to wrap
	call	pmsg
	pop	ax
	mov	obufptr,si		;Set the pointer to the start
	mov	bp,sp
	cmp	byte ptr 4[bp],20h
	jnz	l2227
	mov	word ptr 4[bp],0
	jmp	short l2227
	nop

gotspace:
	cmp	bx,si			;If space is at beginning of line,
					; no wrap
	jz	nowrap
	mov	byte ptr [bx],0		;Put an end marker where the space was
	push	ax
	mov	ax,offset outbuff	;Print up to the end marker
	call	pmsg
	pop	ax
	mov	ax,obufend
	inc	bx
copyobuff:
	cmp	bx,ax			;Copy remaining word to start of buffer
	jz	copydone
	mov	bp,ax
	mov	al,[bx]
	mov	[si],al
	mov	ax,bp
	inc	bx
	inc	si
	jmp	short copyobuff

copydone:
	mov	obufptr,si	;Set pointer to start of obuffer
l2227:	pop	si
	pop	bx
	pop	ax
	cmp	ax,0
	jz	l223a
putinbuff:
	mov	bp,obufptr	;Put the character in the buffer
	mov	[bp],al
	inc	obufptr
l223a:	pop	bp
	ret

crlf:	push	bx
	mov	bx,obufptr
	mov	byte ptr [bx],0
	mov	obufptr,offset outbuff
	pop	bx
	push	ax
	mov	ax,offset outbuff
	call	pmsg
	pop	ax
	ret

l22f4:	mov	bx,offset outbuff		; Set up length of output
	mov	cl,scrnlrx			;  buffer
	sub	ch,ch
	add	bx,cx
	dec	bx
	mov	obufend,bx
	mov	byte ptr [bx],0			; Put a zero on the end
	mov	bx,offset bartable		; Get the address of statbar
	cmp	scotim,0	
	jz	l233c
	add	bx,8				; Skip 4 entries if nec
l233c:	cmp	cx,37h				; Screen > 55 wide?
	jnge	setbar				; No, do 40 col statbar
	mov	ax,3ch
	sub	cx,80d				; 80 decimal
	mov	si,4h
	jmp	short l2355
	nop

setbar:	mov	ax,0fh
	sub	cx,28h
	sub	si,si
l2355:	sub	ax,cx
	add	ax,[bx+si]
	mov	bx,2[bx+si]
	test	cx,cx
	jg	l2363
	add	6[bx],cx
l2363:	add	0ch[bx],cx
	add	0eh[bx],cx
	add	14h[bx],cx
	add	16h[bx],cx
	mov	barptr,ax
	mov	barbuff,bx
	call	screeninit
	ret

begin2:	call	chkdos			;Check DOS version & look at cmd line
	sub	ax,ax
	sub	bx,bx
	call	readpg1
	mov	error,1
	cmp	byte ptr es:[0],3	;First byte must be 03
	jnz	badvers
	test	byte ptr es:[1],1	;And bit 0 of second byte must be off
	jz	gameok
badvers:call	scroll
	mov	ax,offset fatal		;"Fatal error"
	call	pmsg
	mov	ax,offset wrngver	;"Wrong game or version"
	call	pmsg
	jmp	endgame

gameok:	test	byte ptr es:[1],2	;Bit 1 of byte 1 = score or time
	jz	sco
	inc	scotim
sco:	mov	ax,es:[2]
	xchg	ah,al
	mov	l04f7,ax
	mov	ax,es:[4]
	xchg	ah,al
	test	ax,1ffh
	jz	l23f3
	and	ax,0fe00h
	add	ax,200h
l23f3:	mov	cx,ax
	mov	bp,cx
	mov	cl,9
	sar	bp,cl
	mov	cx,bp
	mov	pagea,cx
	mov	ax,80h
	sub	ax,cx
	shl	ax,1
	shl	ax,1
	mov	pageb,ax
	dec	cx
	mov	cx,7fh
	mov	ax,1h
	mov	datbuf,1
	call	readdat
	mov	cx,7fh
	mov	datbuf,80h
	mov	ax,80h
	call	readdat
	jnz	l2444
	mov	cx,1
	mov	ax,0ffh
	mov	datbuf,0ffh
	call	readdat
l2444:	mov	datbuf,0
l245d:	mov	ax,es:[8]		;Vocab address
	xchg	ah,al
	mov	vocabptr,ax
	mov	ax,es:[0ah]		;Orlist pointer
	xchg	ah,al
	mov	orlptr,ax
	mov	ax,es:[0ch]		;Global variable pointer
	xchg	ah,al
	mov	gvarptr,ax
	mov	ax,es:[18h]		;Special word pointer
	xchg	ah,al
	mov	swrdptr,ax
	mov	ax,es:[0eh]
	xchg	ah,al
	test	ax,1ffh
	jz	l248f
	add	ax,200h
l248f:	mov	cl,9				;Multiply by 200h
	sar	ax,cl
	and	ax,7fh
	mov	l0505,ax
	mov	bx,offset l05b0
	mov	si,vocabptr
	mov	cl,es:[si]
	sub	ch,ch
	inc	si
l24a6:	mov	al,es:[si]
	mov	[bx],al
	inc	bx
	inc	si
	loop	l24a6
	mov	l0507,bx
	mov	bp,offset l04ed
l24b6:	mov	al,[bp]
	mov	[bx],al
	inc	bx
	inc	bp
	cmp	al,0
	jnz	l24b6
	mov	al,es:[si]
	sub	ah,ah
	mov	l0509,ax
	inc	si
	mov	ax,es:[si]
	xchg	ah,al
	mov	l050b,ax
	add	si,2
	mov	l050d,si
	mov	si,pagea
	mov	cl,9
	shl	si,cl
	mov	datoffset,si
	call	systime
	jmp	short l2545
	nop

startgame:
	call	clopdat
	mov	linecount,0
	sub	ax,ax
	mov	datofstflg,0
	mov	highaddrflg,0
	mov	datbuf,0
	push	datoffset
	mov	datoffset,0
	mov	cx,l0505
	call	readdat
	pop	datoffset
	mov	ah,noprinter
	xor	al,al
	mov	es:[10h],ax
	or	byte ptr es:[1],20h
	mov	x0y1,0100h	;x0y1 is the coords of the top lhs of screen (not statbar)
	mov	l0601,0
	mov	l0603,0
	jmp	short gotrom
	nop

l2545:	call	l22f4
gotrom:	call	cls
	mov	sp,offset stack
	mov	di,offset begin
	mov	obufptr,offset outbuff
	mov	lvarptr,di
	sub	lvarptr,2
	mov	ax,es:[6]
	xchg	ah,al
	call	cnvtadd
	mov	l05de,ax
	mov	pc,bx
	call	checkpc
	jmp	short reentry
	nop

reentry:call	l1ea4
	mov	dx,ax
	cmp	ax,80h
	jnge	twoprm
	cmp	ax,0b0h
	jge	re2
	jmp	oneprm

re2:	cmp	ax,0c0h
	jg	extra
	jmp	noprm

extra:	and	ax,3fh
	shl	ax,1
	mov	bp,ax
	mov	si,vectors2[bp]
	cmp	si,0
	jnz	l25a3
	jmp	illop

l25a3:	call	l1ea4
	mov	cx,4
l25a9:	push	ax
	sar	ax,1
	sar	ax,1
	loop	l25a9
	mov	cx,4
	sub	dx,dx
	mov	bx,offset l05e4
l25b8:	pop	ax
	and	ax,3
	cmp	ax,3
	jz	l25cf
	call	l1ef1
	mov	[bx],ax
	add	bx,2
	inc	dx
	loop	l25b8
	jmp	short l25d4
	nop

l25cf:	dec	cx
	shl	cx,1
	add	sp,cx
l25d4:	xchg	cx,dx
	mov	ax,cx
	cmp	byte ptr [si],90h
	jz	l25f8
	dec	cx
	jnge	l25f8
	jz	l25f5
	sub	cx,2
	jnge	l25f1
	jz	l25ed
	mov	dx,l05ea
l25ed:	mov	cx,l05e8
l25f1:	mov	bx,l05e6
l25f5:	mov	ax,l05e4
l25f8:	jmp	callvect

twoprm:	and	ax,1fh
	shl	ax,1
	mov	bp,ax
	mov	si,vectors2[bp]
	cmp	si,0
	jz	illop
	mov	ax,1
	test	dx,40h
	jz	l2615
	inc	ax
l2615:	call	l1ef1
	push	ax
	mov	ax,1
	test	dx,20h
	jz	l2623
	inc	ax
l2623:	call	l1ef1
	mov	bx,ax
	pop	ax
	cmp	byte ptr [si],90h
	jnz	callvect
	mov	l05e4,ax
	mov	l05e6,bx
	mov	ax,2
	jmp	short callvect
	nop

oneprm:	and	dx,0fh
	shl	dx,1
	mov	bp,dx
	mov	si,vectors1[bp]
	cmp	si,0
	jz	illop
	sar	ax,1
	sar	ax,1
	sar	ax,1
	sar	ax,1
	and	ax,3
	call	l1ef1
	jmp	short callvect
	nop

noprm:	and	ax,0fh
	shl	ax,1
	mov	bp,ax
	mov	si,vectors0[bp]
	cmp	si,0
	jnz	callvect
illop:	call	scroll
	mov	ax,offset fatal
	call	pmsg
	mov	ax,offset illegop
	call	pmsg
	jmp	endgame

callvect:
	call	si
	jmp	reentry

checkpc:push	si
	push	bp
	push	bx
	push	cx
	push	dx
	sub	ax,ax
	mov	bx,l05de
	mov	bh,bl
	sub	bl,bl
	shl	bx,1
	adc	ax,0 
	mov	si,pc
	xchg	ax,si
	cwd
	xchg	ax,si
	add	bx,si
	adc	ax,dx
	mov	dx,bx
	and	dx,01ffh
	mov	pc,dx
	mov	cl,9
	sar	bx,cl
	and	bx,7fh
	test	ax,1
	jz	l26cd
	or	bx,80h 
	mov	highaddrflg,1
	jmp	short l26d9
	nop

l26cd:	mov	highaddrflg,0
l26d9:	mov	l05de,bx
	test	pcmoved,1
	jnz	l26ea
	cmp	bx,paging2
	jz	l2753
l26ea:	mov	paging2,bx
	mov	ax,paging1
	cmp	ax,0
	jz	l2707
	mov	bp,ax
	mov	cl,l05f2
	mov	[bp],cl
	mov	cx,l05f3
	mov	1[bp],cx
	inc	ax
l2707:
l2739:	mov	cl,9
	shl	bx,cl
l2749:	mov	paging1,0
l274f:	mov	l05ec,bx
l2753:	mov	pcmoved,0
	pop	dx
	pop	cx
	pop	bx
	pop	bp
	pop	si
	ret

chkdos:	mov	ah,30h			;Check dos version
	int	21h
	cmp	al,2
	jge	dosok
	call	scroll
	mov	ax,offset fatal
	call	pmsg
	mov	ax,offset dosver	;"Wrong dos version"
	call	pmsg
	jmp	endgame

dosok:	mov	ah,19h			;Get default disk drive
	int	21h
	mov	datdrive,al		;Set up data file drive and save file drive
	mov	savdrive,al
	call	cmdline			;Check the user's command line

opendat:mov	ah,3dh			;Open file
	mov	al,0
	mov	dx,offset datname
	int	21h
	jnc	datopnd
	jmp	datntfnd

datopnd:mov	dathandle,ax
	mov	bx,ax
	xor	cx,cx
	xor	dx,dx
	mov	ah,42h			;Move file pointer
	mov	al,2			;Relative to end of file
	int	21h
	mov	cl,4			;Divide least sig half by 16
	shr	ax,cl
	test	dx,dx			;Is there a most significant half?
	jz	nomostsig
	or	ah,10h			;10000/10=1000h
					; therefore or ah with 10h
nomostsig:
	mov	cl,5			;ah now has size of file in segments
	shr	ax,cl			;Dividing by another 20h gives
					; number of 200h pages in file
	mov	pagesinfile,ax
	xor	cx,cx
	mov	dx,4			;Fourth byte
	mov	ah,42h			;Move file pointer
	mov	al,0			;Relative to front
	int	21h
	mov	ah,3fh			;Read file
	mov	cx,2			;Two bytes
	mov	dx,offset datlen
	int	21h
	mov	ax,datlen
	xchg	ah,al			;Turn bytes 4 & 5 around the right way
	test	ax,1ffh			;Does the file end on a page boundary?
	jz	endsonpage
	and	ax,0fe00h		;If not, mask out the byte in page
	add	ax,200h			; and round up to the next page
endsonpage:
	mov	cl,9			;Divide by 200h to get number of pages
	sar	ax,cl			; in ax
	mov	dx,ax			;Store number of pages in file in dx
	mov	bx,2			;Get the segment of end of alloc block
	mov	bx,cs:[bx]		; from psp
	mov	ax,cs			;Subtract this segment
	sub	bx,ax
	mov	cl,4
	mov	ax,offset endprog	;Work out number of segments in this
	shr	ax,cl			; program
	inc	ax			;Round up
	and	ax,0fe0h		;Round up some more
	add	ax,20h			;And more again
	sub	bx,ax			;Subtract legth of prog (in segs) from
					; avail memory (in segs)
	test	switches,4		;check for /k switch
	jz	nokswitch
	cmp	bx,memory
	jna	nokswitch
	mov	bx,memory
nokswitch:
	cmp	bx,0600h		;We want 6k vacant
	jnb	enoughmem
	call	scroll
	mov	ax,offset fatal		;"Fatal error: "
	call	pmsg
	mov	ax,offset nomemory	;"Insufficient memory to play game"
	call	pmsg
	jmp	endgame

enoughmem:				;Convert free mem in segs into
	mov	cl,5			; free mem in pages
	shr	bx,cl
	sub	bx,dx			;Subtract game file length in pages
					; from free mem in pages
	dec	bx			;Round down
	cmp	bx,80h			;Is there less than 80 pages left?
	jnge	less
	dec	bx			;I assume we need the extra pages for
					; something...
	cmp	bx,0ffh			;More than 0ffh pages?
	jng	less
	mov	alldatin,1
	mov	bx,0ffh
less:	push	bx
	add	bx,dx
	cmp	bx,pagesinfile
	pop	bx
	jna	less2
	mov	alldatin,1
less2:	mov	freepages,bx
	shl	bx,1
	shl	bx,1
	inc	bx
	add	bx,offset endprog
	mov	cx,4			;Convert endprog to segments
	shr	bx,cl
	mov	ax,ds
	add	bx,ax
	add	bx,1
	mov	firstes,bx		;Set up segments
	add	bx,1000h
	mov	extraes,bx
	call	setuptable
	ret

datntfnd:
	call	scroll
	mov	ax,offset fatal		;"Fatal error: "
	call	pmsg
	mov	ax,offset datnf		;"Game file not found"
	call	pmsg
	jmp	endgame

setuptable:
	push	si	;sets up table of entry fe 00 00 00 of length # free pages
	push	di
	push	ax
	push	bx
	push	cx
	mov	di,offset endprog
	mov	cx,freepages
	mov	ax,ds
	mov	es,ax
	cld
pagelp:	mov	si,offset l05d5
	push	cx
	mov	cx,4
	rep movsb
	pop	cx
	loop	pagelp
	mov	[di],0ffffh
	mov	bx,firstes
	mov	es,bx
	pop	cx
	pop	bx
	pop	ax
	pop	di
	pop	si
	ret

clopdat:push	dx
	mov	dl,datdrive
	mov	ah,0eh
	int	21h
	mov	ah,3eh			;Close file
	mov	bx,dathandle
	int	21h
l2a16:	mov	ah,3dh			;Open file
	mov	al,0
	mov	dx,offset datname
	int	21h
	jnb	l2a2e
	push	ax
	mov	ax,offset insdat	;"Insert game disk then strike any key
					;  ..."
	call	pmsg
	pop	ax
	call	keyin
	jmp	short l2a16

l2a2e:	mov	dathandle,ax
	mov	dl,savdrive
	mov	ah,0eh	;set default disk drive to save drive
	int	21h
	pop	dx
	ret

l2a3b:	cld
	push	si
	push	dx
	mov	bp,sp
	mov	si,ax			;si now points to "COMPAQ" or "IBM" etc
cploop:	cmp	byte ptr [si],'$'	;Are we at the end of our string ?
	jz	gotit
	cmpsb
	jnz	nomatch
	dec	dx
	loop	cploop
	jmp	short nomatch2
	nop

nomatch:mov	si,ax
	mov	dx,[bp]
	loop	cploop
nomatch2:
	stc
	pop	dx
	pop	si
	ret

gotit:	test	dx,dx
	jnz	nomatch2
	clc
	pop	dx
	pop	si
	ret

cmdline:cld				;Look on the command line
	mov	si,80h
	lodsb
	test	al,al
	jnz	cmdthere
l2a6e:	ret				;There were no commands given

cmdthere:
	dec	al
	xor	dx,dx
	mov	dl,al
	add	dx,82h
	inc	si
cmdlp:	cmp	si,dx
	lodsb
	jz	l2a6e
	cmp	al,'/'			;Look for the switch character
	jnz	cmdlp
	lodsb				;Get character
	and	al,5fh			;Upper case-er-ise it
	cmp	al,'M'
	jnz	notm
	or	switches,1
	jmp	short cmdlp

notm:	cmp	al,'G'			;/g<gamefilename>
	jnz	notg
	mov	di,offset datname
l2aa8:	movsb
	cmp	dx,si
	jnz	l2aa8
	mov	al,0
	stosb
	ret

notg:	cmp	al,'C'			;Colour
	jnz	notc
	or	switches,2
	jmp	short cmdlp

notc:	cmp	al,'K'
	jnz	notk
	mov	bx,0
l2ac3:	cmp	dx,si
	jnz	l2ad7
l2ac7:	or	switches,4
	mov	cl,6
	shl	bx,cl
	mov	memory,bx
	dec	si
	jmp	short cmdlp

l2ad7:	lodsb
	cmp	al,0
	jz	l2ac7
	cmp	al,' '
	jz	l2ac7
	cmp	al,'/'
	jz	l2ac7
	xor	ah,ah
	aaa
	xchg	ax,bx
	push	dx
	mul	ten				; Location contains ten
	add	bx,ax
	pop	dx
	jmp	short l2ac3

notk:	cmp	al,'P'				;Printer switch
	jz	l2af8
	jmp	short cmdlp

l2af8:	push	dx
	mov	dx,0
	mov	ah,1
	int	17h
	pop	dx
	jmp	cmdlp

cls:	push	ax
	push	cx
	push	di
	push	es
	mov	ax,screen_seg
	mov	es,ax
	mov	di,0
	mov	cx,80*24
	mov	ah,attrib
	mov	al,' '
	rep	stosw
	pop	es
	pop	di
	pop	cx
	pop	ax
	ret

readpg1:push	cx
	mov	cx,1
	call	readdat
	pop	cx
	ret

readdat:mov	readwrite,0	;Read in page cx
	push	ax
	mov	ax,dathandle
	mov	dat2handle,ax
	pop	ax
	push	bp
	push	dx
	push	bx
	push	si
	mov	dx,cx			;Convert cx in pages to cx,dx
	mov	cx,9			; offset in file
	shl	dx,cl
	shl	ax,cl
	mov	cx,0
	adc	cx,0			;Get a 1 or 0 in the most
	mov	bx,dat2handle		; significant half of offset
	mov	si,dx
	test	nomoveptr,1
	jz	dontmove
	mov	dx,ax			;Least significant half of offset
	mov	ah,42h			;Move file pointer
	mov	al,0			; from beginning of file
	int	21h
dontmove:
	mov	dx,datbuf
nodatofst:
	mov	cx,si
	mov	ah,3fh			;Read file or device
	cmp	readwrite,0
	jz	dofile
	mov	ah,40h			;Write file or device
dofile:
l2bbc:	cmp	dx,80h
	jnge	l2bd0
	sub	dx,80h
l2bc6:	push	ds
	mov	si,extraes
	mov	ds,si
	jmp	short l2bd5
	nop

l2bd0:	push	ds
	mov	si,es
	mov	ds,si
l2bd5:	push	cx
	mov	cl,9
	shl	dx,cl
	pop	cx
	int	21h
	cmp	ax,cx
	pop	ds
	mov	nomoveptr,1
l2be5:	pop	si
	pop	bx
	pop	dx
	pop	bp
	ret

	push	ax
	mov	ax,dathandle
	cmp	dat2handle,ax
	jz	datreaderr
	stc
	jmp	short l2be5

datreaderr:
	call	scroll
	mov	ax,offset fatal		;"Fatal error: "
	call	pmsg
	mov	ax,offset datnr		;"Game file read error"
	call	pmsg
	jmp	endgame

keyin:	push	cx
	push	dx
	cmp	keytoggle,0
	jnz	l2c17
	mov	keytoggle,1
l2c17:	mov	ah,7			;Unfiltered character input without
	int	21h			;echo
	sub	ah,ah
	pop	dx
	pop	cx
	ret

mspchar:push	ax			;Print character via MS-DOS
	push	bx
	push	cx
	push	dx
	push	bp
	push	ax

	cmp	al,0dh				;CR
	je	mspcr
	cmp	al,0ah				;LF
	je	msplf
	push	es
	mov	bx,screen_seg
	mov	es,bx
	mov	ah,attrib
	mov	bx,cursor_pos
	mov	es:[bx],ax
	inc	cursor_pos
	inc	cursor_pos
	pop	es

mspdone:pop	ax
	test	noprinter,1
	jz	l2c3e
	cmp	script,1
	jz	l2c3e
	call	lpchar
l2c3e:	pop	bp
	pop	dx
	pop	cx
	pop	bx
	pop	ax
	ret

mspcr:	mov	cursor_pos,screen_bottom
	jmp	short mspdone
msplf:	call	scroll
	jmp	short mspdone

scroll:	push	ax			;Scroll screen up. Check if we can use
	push	bx			; BIOS to do window scroll
	push	cx
	push	dx
	push	bp
	test	l0601,1
	jnz	norom

	push	si
	push	di
	push	ds
	push	es

	cld				;Go forwards
	mov	ax,screen_seg
	mov	ds,ax			;Source is screen
	mov	es,ax			;Destination is screen
	mov	si,80*4			;Source is third line
	mov	di,80*2			;Destination is second line
	mov	cx,80*23		;24-1 = 23 move ups
	rep	movsw			;Scroll up

	mov	ah,cs:attrib		;Text attribute
	mov	al,' '			;Space
	mov	di,80*24*2		;Starting position for bottom line
	mov	cx,80			;Width of bottom line
	rep	stosw			;Clear bottom line

	pop	es
	pop	ds
	pop	di
	pop	si

norom:	mov	ah,6			;Direct console i/o
	mov	dl,0dh
	int	21h
	test	l0601,1
	jnz	notmore
	inc	linecount
	mov	al,scrnlry
	sub	ah,ah
	dec	ax
	mov	dx,x0y1
	xchg	dh,dl
	sub	al,dl
	cmp	linecount,ax
	jnge	notmore
	mov	linecount,0
	mov	script,1
	push	ax
	mov	ax,offset more		;"** MORE **"
	call	pmsg
	pop	ax
	call	keyin
	push	ax
	mov	ax,offset spaces9	;Clear the ** MORE ** message
	call	pmsg
	pop	ax
	mov	script,0
notmore:test	noprinter,1
	jz	l2cd5
	call	lpcrlf
l2cd5:	pop	bp
	pop	dx
	pop	cx
	pop	bx
	pop	ax
	ret

printbar:					; Prints the status bar
	push	si
	push	di
	push	es
	mov	ax,screen_seg			; Directly onto screen
	mov	es,ax
	mov	si,barptr			; Source is the sbar pointer
	mov	di,0				; Destination is first line
	mov	ah,sbattrib			; Stat-bar attribute
pbarlp:	lodsb					; Load the byte from buffer
	cmp	al,'$'				; End of message pointer
	je	pbarx
	stosw					; Store char and attribute
	jmp	short pbarlp
pbarx:	pop	es
	pop	di
	pop	si
	ret

ansii:	mov	cl,[bx]
	sub	ch,ch
	cmp	cl,0
	jz	l2d18
l2d0d:	inc	bx
	mov	dl,[bx]
	mov	ah,6			;Direct console i/o
	push	bx
	int	21h
	pop	bx
	loop	l2d0d
l2d18:	ret

screeninit:
	call	cls
	mov	cursor_pos,screen_bottom	;Put cursor at right spot
	call	cursor_off
	ret

pmsg:	cmp	error,1
	jnz	l2d54
	push	ax
	mov	ax,es:[10h]
	xchg	ah,al
	mov	noprinter,al
	pop	ax
l2d54:	push	bx
	mov	bx,ax
pmsglp:	mov	al,[bx]
	cmp	al,0
	jz	pmsgnlx
	cmp	al,80h
	jz	pmsgx
	call	mspchar
	inc	bx
	jmp	short pmsglp

pmsgnlx:call	scroll
	mov	cursor_pos,screen_bottom	;Reset cursor position
pmsgx:	pop	bx
	ret

systime:push	cx
	push	dx
	mov	ah,2ch			;Get system time
	int	21h
	mov	hourmin,cx
	mov	sechund,dx
	pop	dx
	pop	cx
	ret

endgame:call	scroll			;Exit to operating system
	mov	ah,2			;Set cursor position
	mov	dh,24			;Bottom line
	mov	dl,0			;First column
	mov	bh,0			;Page zero
	int	10h			;Put cursor at bottom of screen
	mov	ah,4ch
	int	21h

endprog	equ	$

infocom	endp

cseg	ends

	end	infocom
