/* File: infocom.h */

/* Some pseudo type declarations */
#define		true		1
#define		false		0

typedef		char		Boolean;
typedef		int		(*ProcPtr)();

/*
 * Machine dependent definitions
 */
#define		byte		unsigned char	/* 8 bit storage element */
#define		word		unsigned short	/* 16 bit storage element */
#define		long_word	unsigned long	/* 32 bit storage element */

/*
 * Define this if your C Compiler does function parameter checking a la
 * the ANSI Draft C Standard.  Currently, I only know of the Microsoft C
 * Compiler version 3.00 and above which implements this feature.
 */
#define	LINT_ARGS

/*
 * Define this only if your C Compiler does not support the void type
 */
/*#define	void	int*/

/*
 * Define this if your system/C Compiler does not pass the name of the
 * command through argv[0].  This is a problem endemic on CP/M systems and
 * most MS-DOS C Compilers (expect Microsoft C Compiler version 3.00 and
 * above.  On such systems, the value of argv[0] in main() is usually NULL
 * or points to something incredibly dumb.
 */
/*#define	NOARGV0*/

/*
 * A separator character is a character that seperates the filename proper
 * from the file environment.  For example, in Unix, a separator character
 * is the '/' used to separate the components of a path name.  In MSDOS, the
 * equivalent character is the ugly backslash '\\',  In CPM, files have no
 * directory component but may have a drive letter prepended.  Other
 * operating systems may or may not have seperator characters, so we define
 * the separator character to be something innocuous (like a newline).
 *
 * The separator character is currently only used in just one section of the
 * code: the program name extractor in main() strips off the path from the
 * the first argument (command name) on the command line.
 */
#ifdef CPM
#define		SEPARATOR	':'	/* Path separator */
#endif
#ifdef UNIX
#define		SEPARATOR	'/'	/* Path separator */
#endif
#ifdef MSDOS
#define		SEPARATOR	'\\'	/* Path separator */
#endif
#ifndef	SEPARATOR
#define		SEPARATOR	'\n'	/* safe innocuous separator */
					/* I wouldn't mind a space, except */
					/* for the fact that nasty */
					/* Macintosh's allows spaces to */
					/* be part of the filename */
					/* christie */
#endif

/* Character Definitions */

#define		back_space		0x08
#define		local_vars		0x10
#define		prt_buff_size		80
#define		status_buff_size	0x3A

/* Error Codes */

#define		err_memory		0x00
#define		err_opcode		0x15
#define		err_header		0x16
#define		err_put_prop		0x17
#define		err_next_prop		0x18

/* Status Codes */

#define		init_game		0x00
#define		play_game		0x01
#define		restart_game		0x02
#define		load_game		0x03
#define		quit_game		0x04

/* Stack size in bytes */

#define		stack_size	0x200
#define		block_size	0x200
#define		max_mem		0xFFFF

/*
 *	Problem : We want size of object to be 9 bytes, but the
 *	complier will only make it an integral number of WORDS.
 */

#define		obj_size	9
#define		obj_offset	0x35

typedef struct
{
	byte	attributes[4];
	byte	location;
	byte	link;
	byte	holds;
	byte	prop_ptr[2];
} object;

typedef byte	*property;

typedef struct
{
	byte	page;
	byte	count_hi;
	word	count_lo;
} pg_table;

typedef struct
{
	byte	z_code_version;
	byte	score_or_time;
	word	release;
	word	resident_bytes;
	word	start;
	word	vocab;
	word	object_list;
	word	globals;
	word	save_bytes;
	word	script_status;
	char	serial_no[6];
	word	common_word;
	word	verify_length;
	word	verify_checksum;
	word	padding[17];
} header;

object		*obj_addr();
word		find_mode();
word		convert();
byte		get_byte();
word		get_word();
byte		next_byte();
word		next_word();
word		load_var();
word		load();
byte		*read_line();
byte		*fetch_page();
pg_table	*get_LRU_page();

char		read_char();
int		print_char();
int		put_status();
int		open_file();

/* Standard C Routines */

char		*malloc();
