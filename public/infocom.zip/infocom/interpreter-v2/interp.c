/* File: interp.c */

#include	"infocom.h"

interp ()
{
	extern word		status ;
	extern word		save_blocks ;
	extern word		pc_page ;
	extern word		pc_offset ;
	extern word		*stack_base ;
	extern word		*stack_var_ptr ;
	extern word		*stack ;
	extern byte		*base_ptr ;
	extern byte		*p_buff_strt ;
	extern byte		*p_buff_ptr ;
	extern header	data_head ;

	word			opcode ;

	while ( status != quit_game )
	{
		if (( status == restart_game ) || ( status == init_game ))
		{
			if ( status == restart_game )
				load_page ( 0,save_blocks,base_ptr ) ;
			stack_var_ptr = stack_base ;
			stack = --stack_var_ptr ;
			p_buff_ptr = p_buff_strt ;
			pc_page = data_head.start / block_size ;
			pc_offset = data_head.start % block_size ;
			fix_pc () ;
			status = play_game ;
		}

		opcode = next_byte () ;
		if ( opcode < 0x80 )
		{
			operand2 ( opcode ) ;
			continue ;
		}
		if ( opcode < 0xB0 )
		{
			operand1 ( opcode ) ;
			continue ;
		}
		if ( opcode >= 0xC0 )
		{
			operand3 ( opcode ) ;
			continue ;
		}

		switch ( opcode & 0x0F )
		{
			case 0x00 :	ret_true () ;
						break ;
			case 0x01 :	ret_false () ;
						break ;
			case 0x02 :	wrt () ;
						break ;
			case 0x03 :	writeln () ;
						break ;
			case 0x04 :	null () ;
						break ;
			case 0x05 :	save () ;
						break ;
			case 0x06 :	restore () ;
						break ;
			case 0x07 :	restart () ;
						break ;
			case 0x08 :	rts () ;
						break ;
			case 0x09 :	pop_stack () ;
						break ;
			case 0x0A :	quit () ;
						break ;
			case 0x0B :	new_line () ;
						break ;
			case 0x0C :	show_score () ;
						break ;
			case 0x0D :	verify () ;
						break ;
			default  :	error ( err_opcode ) ;
		}
	}
}

operand1 ( opcode )
word	opcode ;
{
	word	param1 ;

	param1 = load (( opcode >> 4 ) & 0x03 ) ;
	switch ( opcode & 0x0F )
	{
		case 0x00 :	cp_zero ( param1 ) ;
					break ;
		case 0x01 :	get_link ( param1 ) ;
					break ;
		case 0x02 :	get_holds ( param1 ) ;
					break ;
		case 0x03 :	get_loc ( param1 ) ;
					break ;
		case 0x04 :	get_p_len ( param1 ) ;
					break ;
		case 0x05 :	inc_var ( param1 ) ;
					break ;
		case 0x06 :	dec_var ( param1 ) ;
					break ;
		case 0x07 :	print1 ( param1 ) ;
					break ;
		case 0x08 :	error ( err_opcode ) ;
					break ;
		case 0x09 :	remove_obj ( param1 ) ;
					break ;
		case 0x0A :	p_obj ( param1 ) ;
					break ;
		case 0x0B :	rtn ( param1 ) ;
					break ;
		case 0x0C :	jump ( param1 ) ;
					break ;
		case 0x0D :	print2 ( param1 ) ;
					break ;
		case 0x0E :	get_var ( param1 ) ;
					break ;
		case 0x0F :	not ( param1 ) ;
					break ;
	}
}

operand2 ( opcode )
word	opcode ;
{
	word	param1 ;
	word	param2 ;
	word	num_params ;
	int		mode ;

	mode = 1 ;
	if ( opcode & 0x40 )
		++mode ;
	param1 = load ( mode ) ;
	mode = 1 ;
	if ( opcode & 0x20 )
		++mode ;
	param2 = load ( mode ) ;
	num_params = 2 ;
	execute ( (opcode & 0x1F),num_params,param1,param2,0,0 ) ;
}

operand3 ( opcode )
word	opcode ;
{
	word	param1		= 0 ;
	word	param2		= 0 ;
	word	param3		= 0 ;
	word	param4		= 0 ;
	word	num_params ;
	byte	modes ;
	int		addr_mode ;

	modes = next_byte () ;
	num_params = 0 ;
	addr_mode = ( modes >> 6 ) & 0x03 ;
	if ( addr_mode != 3 )
	{
		++num_params ;
		param1 = load ( addr_mode ) ;
		addr_mode = ( modes >> 4 ) & 0x03 ;
		if ( addr_mode != 3 )
		{
			++num_params ;
			param2 = load ( addr_mode ) ;
			addr_mode = ( modes >> 2 ) & 0x03 ;
			if ( addr_mode != 3 )
			{
				++num_params ;
				param3 = load ( addr_mode ) ;
				addr_mode = modes & 0x03 ;
				if ( addr_mode != 3 )
				{
					++num_params ;
					param4 = load ( addr_mode ) ;
				}
			}
		}
	}
	execute ( (opcode & 0x3F),num_params,param1,param2,param3,param4 ) ;
}

execute ( opcode,num_params,param1,param2,param3,param4 )
word	opcode,num_params,param1,param2,param3,param4 ;
{
	switch ( opcode )
	{
		case 0x01 :	compare ( param1,param2,param3,param4,num_params ) ;
					break ;
		case 0x02 :	LTE ( param1,param2 ) ;
					break ;
		case 0x03 :	GTE ( param1,param2 ) ;
					break ;
		case 0x04 :	dec_chk ( param1,param2 ) ;
					break ;
		case 0x05 :	inc_chk ( param1,param2 ) ;
					break ;
		case 0x06 :	check_loc ( param1,param2 ) ;
					break ;
		case 0x07 :	bit ( param1,param2 ) ;
					break ;
		case 0x08 :	or ( param1,param2 ) ;
					break ;
		case 0x09 :	and ( param1,param2 ) ;
					break ;
		case 0x0A :	test_attr ( param1,param2 ) ;
					break ;
		case 0x0B :	set_attr ( param1,param2 ) ;
					break ;
		case 0x0C :	clr_attr ( param1,param2 ) ;
					break ;
		case 0x0D :	put_var ( param1,param2 ) ;
					break ;
		case 0x0E :	transfer ( param1,param2 ) ;
					break ;
		case 0x0F :	load_word_array ( param1,param2 ) ;
					break ;
		case 0x10 :	load_byte_array ( param1,param2 ) ;
					break ;
		case 0x11 :	getprop ( param1,param2 ) ;
					break ;
		case 0x12 :	get_prop_addr ( param1,param2 ) ;
					break ;
		case 0x13 :	get_next_prop ( param1,param2 ) ;
					break ;
		case 0x14 :	plus ( param1,param2 ) ;
					break ;
		case 0x15 :	minus ( param1,param2 ) ;
					break ;
		case 0x16 :	times ( param1,param2 ) ;
					break ;
		case 0x17 :	divide ( param1,param2 ) ;
					break ;
		case 0x18 :	mod ( param1,param2 ) ;
					break ;

		case 0x20 :	gosub ( param1,param2,param3,param4,num_params ) ;
					break ;
		case 0x21 :	save_word_array ( param1,param2,param3 ) ;
					break ;
		case 0x22 :	save_byte_array ( param1,param2,param3 ) ;
					break ;
		case 0x23 :	put_prop ( param1,param2,param3 ) ;
					break ;
		case 0x24 :	input ( param1,param2 ) ;
					break ;
		case 0x25 :	print_char ( param1 ) ;
					break ;
		case 0x26 :	print_num ( param1 ) ;
					break ;
		case 0x27 :	random ( param1 ) ;
					break ;
		case 0x28 :	push ( param1 ) ;
					break ;
		case 0x29 :	pop ( param1 ) ;
					break ;

		default  :	error ( err_opcode ) ;
	}
}
