/* File: file.c */

#include	<stdio.h>
#include	"infocom.h"
#ifdef	MSC
#include	<memory.h>
#include	<string.h>
#endif

#define		name_size	10

char	name[name_size + 1] ;
FILE	*game_file;

read_header ( head )
header	*head ;
{
	word	swabtmp[8];

	/* Read the Data File Header */

	if ( fseek ( game_file,0L,0 ) < 0 )
	{
		printf ( "Failed to Seek Start of File\n" ) ;
		quit () ;
	}
	else
	{
		if ( fread ( head,sizeof(header),1,game_file ) != 1 )
		{
			printf ( "Failed to read File Header\n" ) ;
			quit () ;
		}
		else
		{
			if (( head -> z_code_version != 0x03 ) ||
										( head -> score_or_time & 0x01 ))
				error ( err_header ) ;
		}
	}
	swab(&head->release, swabtmp, sizeof(word) * 8);
	memcpy(&head->release, swabtmp, sizeof(word) * 8);
	swab(&head->common_word, swabtmp, sizeof(word) * 3);
	memcpy(&head->common_word, swabtmp, sizeof(word) * 3);
}

int
open_file ( filename )
char	*filename ;
{
	/* Open a File for Reading */

	game_file = fopen ( filename,"r" ) ;
	if ( game_file == (FILE *)0 )
		return ( false ) ;
	return ( true ) ;
}

close_file ()
{
	/* Close an Open File */

	if ( fclose ( game_file ) )
		printf ( "Cannot Close Game File\n" ) ;
}

load_page ( block,num_blocks,ptr )
word	block ;
word	num_blocks ;
byte	*ptr ;
{
	long	offset ;

	/*
		Read "num_block" blocks from Game File,
		starting with block "block", at the
		location pointed to by "ptr".
	*/

	offset = (long) block * block_size ;
	if ( fseek ( game_file,offset,0 ) < 0 )
	{
		printf ( "Failed to Seek required Blocks\n" ) ;
		quit () ;
	}
	else
	{
		if ( fread (ptr,block_size,num_blocks,game_file) != num_blocks )
		{
			printf ( "Failed to Read Blocks from File\n" ) ;
			quit () ;
		}
	}
}

filename ()
{
	char	ch ;
	int		i ;

	echo ( "Filename: " ) ;
	i = 0 ;
	while (( ch = read_char () ) != '\n' )
	{
		/* Handle backspaces */

		if (( ch == back_space ) && ( i != 0 ))
			--i ;

		/* Convert Uppercase to Lowercase */

		if (( ch >= 'A' ) && ( ch <= 'Z' ))
			ch = ch - 'A' + 'a' ;

		/* Handle Alpha-numeric Characters */

		if (( ch >= 'a' ) && ( ch <= 'z' ) && ( i < name_size ))
			name[i++] = ch ;
		if (( ch >= '0' ) && ( ch <= '9' ) && ( i < name_size ))
			name[i++] = ch ;

		/* Handle Pathname Characters */

		if ((( ch == '/' ) || ( ch == ':' )) && ( i < name_size ))
			name[i++] = ch ;
	}
	name[i] = '\0' ;
	if ( i == 0 )
	{
		echo ( "Bad Filename. Try Again...\n" ) ;
		filename () ;
	}
}

save ()
{
	extern byte		*base_ptr ;
	extern word		save_blocks ;

	FILE	*save_file ;

	/*
		Save a Game.

		It is not necessary to save the stack, the
		stack pointers, or the program counter.
	*/

	filename () ;
	save_file = fopen ( name,"w" ) ;
	if ( save_file == (FILE *)0 )
	{
		ret_value ( false ) ;
		return ;
	}
	if (fwrite(base_ptr,block_size,save_blocks,save_file) != save_blocks)
	{
		ret_value ( false ) ;
		return ;
	}
	if ( fclose ( save_file ) )
	{
		ret_value ( false ) ;
		return ;
	}
	ret_value ( true ) ;
}

Boolean
check ( info )
header	*info ;
{
	extern header	data_head ;

	if ( info -> z_code_version != data_head.z_code_version )
		return ( false ) ;
	if ( info -> score_or_time != data_head.score_or_time )
		return ( false ) ;
	if ( info -> release != data_head.release )
		return ( false ) ;
	if ( info -> verify_length != data_head.verify_length )
		return ( false ) ;
	if ( info -> verify_checksum != data_head.verify_checksum )
		return ( false ) ;
	return ( true ) ;
}

restore ()
{
	extern byte		*base_ptr ;
	extern word		save_blocks ;

	FILE	*save_file ;

	/* Restore a Saved Game */

	filename () ;
	save_file = fopen ( name,"r" ) ;
	if ( save_file == (FILE *)0 )
	{
		ret_value ( false ) ;
		return ;
	}
	if (fread(base_ptr,block_size,save_blocks,save_file) != save_blocks)
	{
		ret_value ( false ) ;
		return ;
	}
	if ( fclose ( save_file ) )
	{
		ret_value ( false ) ;
		return ;
	}
	if ( check((header *)base_ptr) == false )
	{
		echo ( "Wrong Game or Version ...\nRestarting ...\n" ) ;
		restart () ;
	}
	ret_value ( true ) ;
}
	
