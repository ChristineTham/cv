/* File: io.c */

#include	"infocom.h"
#include	"stdio.h"

print_buffer ( buff_end )
byte	*buff_end ;
{
	extern byte		*p_buff_strt ;

	byte			*ptr ;

	ptr = p_buff_strt ;
	while ( ptr != buff_end )
		putchar ( *ptr++ ) ;
}

print_status ()
{
	extern byte		*s_buff_strt ;

	byte			*ptr ;
	byte			i ;

	/* First byte of buffer is the buffer size */

	ptr = s_buff_strt ;
	for ( i = *ptr++ ; i > 0 ; i-- )
		putchar ( *ptr++ ) ;
	putchar ( '\n' ) ;
}

echo ( s )
char	*s ;
{
	printf ( "%s",s ) ;
}

char
read_char ()
{
	return ( getchar() ) ;
}

allocate()
{
	extern byte		*base_ptr ;
	extern byte		*base_end ;
	extern word		status ;

	unsigned		size ;

	size = max_mem ;
	while ((size != 0)&&((base_ptr =(byte *)malloc (size)) ==(byte *)0))
		size -= 0x0400 ;
	free ( base_ptr ) ;
	size -= 0x6400 ;
	if ( size < 0x6000 )
	{
		error ( err_memory ) ;
		echo ( "Not enough memory." ) ;
		quit () ;
	}
	else
	{
		base_ptr = (byte *)malloc ( size ) ;
		base_end = base_ptr + size ;
	}
}

deallocate ()
{
	extern byte		*base_ptr ;

	if ( base_ptr != (byte *)0 )
		free ( base_ptr ) ;
}

seed_random ()
{
	extern word		random1 ;
	extern word		random2 ;

	random1 = 0xFFFF ;
	random2 = 0xFFFF ;
}
