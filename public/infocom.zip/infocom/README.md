# Infocom

The **InfoTaskForce** Z-Machine interpreter, and the reverse-engineering work
behind it.

InfoTaskForce was a group of five University of Sydney students — David Beazley,
George Janczuk, Russell Hoare, Peter Lisle and Chris Tham — who in 1987 took
Infocom's virtual machine apart and wrote the first portable Z-Machine
interpreter. The `(C)opyright 1987 InfoTaskforce` notice on these files is the
group's, and one of the five is the author of this site. The story is told in
[Reverse engineering Infocom games](/cv/article/infotaskforce/).

Recovered from `CHRISTIE.ARJ`, a December 1992 archive wrapping a **May 1990**
snapshot — so this captures the interpreter mid-life, two years before version
4.01 was released in September 1992. The verbatim extraction is in
`../christie/`.

## Layout

| Here | From | What it is |
| :-- | :-- | :-- |
| `interpreter-v1/` | `christie/infocom/` | earlier C tree; UNIX only |
| `interpreter-v2/` | `christie/infocom2/` | portable C tree, MS-DOS build, and the disassemblies |
| `infotrce.com` | `christie/infotrce.com` | DOS executable identifying itself as `INFOTRACE: Trace Infocom adventures v0.0001` |

The two trees are separate versions, not a copy: all seventeen files they share
differ.

## Which tree is which

`interpreter-v1` carries a `term.c` that `interpreter-v2` lacks, compiled only
when `TERMCAP` is defined — UNIX terminal handling and nothing else. Its
conditionals are `DEBUG`, `ALOCALL`, `TIMESEED`.

`interpreter-v2` is the portability work. It is the tree that carries `UNIX`,
`MSDOS` and `CPM` conditionals, and it ships two Microsoft C makefiles for
MS-DOS — `Makefile` and a debug variant `Makefile.deb` — driving `link`,
`mapsym` and `binmode.obj`. Both are headed `christie`, as is `infocom.h`. This
matches the account in the article: the MS-DOS port was done with the Microsoft C
compiler on an IBM XT clone, alongside keeping the C portable across several
UNIX systems.

## The disassemblies

`interpreter-v2` also holds x86 disassemblies of Infocom's own PC interpreters,
each headed with a dated log of the work:

- `inf.asm` — IBM Standard executor (new). Disassembly started 3 February 1987,
  reassembly started 23 February, attempted 13 March, **accomplished 16 April
  1987**.
- `ballyhoo.asm` — byte-for-byte identical to `inf.asm`; the same disassembly
  kept under the name of a game that shipped with that executor.
- `amfv.asm` — IBM **Plus Series** executor, disassembly completed 11 May 1987.
  The Plus series ran the larger story files, of which *A Mind Forever Voyaging*
  was one.
- `infocom.mac` — macro definitions, headed with an epigraph from Galileo's
  recantation.

These dates sit just before the first portable interpreter compiled and ran on
25 May 1987. Note that they are disassemblies of the **IBM PC** executors, in
8086 assembly; the published account describes reverse engineering the **CP/M
Z80** interpreter. Both were evidently taken apart.

No Infocom story files are included, and none were in the archive.
